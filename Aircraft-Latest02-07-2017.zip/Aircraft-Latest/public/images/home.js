 $(document).ready(function () {
	 
	 
	 $("#loginId").click(function(){
		 
		$("#home").hide();
		
		$("#mainPageDispaly").show();
		 
	 });
	 
	 
	 $("#homecontainer" ).highcharts( {
        title: {
            text: ""
        },
		  
        tooltip: {
            enabled: false
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: "pointer",
                dataLabels: {
                    enabled: true,
                    distance: -75,
                    color: "white"
                }
            },
            series: {
                allowPointSelect: true,
                point: {
                    events: {
                        select: function() {}
                    }
                }
            }
        },
        series: [ {
            type: "pie",
            data: [
                {
                    name: "Structures<br>.Flight Segmentation<br>.Regression Analysis<br>.Cluster Analysis<br>.Rainflow Analysis",
                    color: "#3b62a0",
                    y: 40,
					 sliced: true,
					selected: true,
					events: {
                                    click: function() {
                                            //location.href = this.options.url;
											
											$("#mainPageDispaly").hide();poc1ID
											$("#headerTabId").show();
											
                                        }
                                }
					   
					
                },
                {
                    name: "Engine<br>.EGT Analysis<br>.shutdowns",
                    color: "#3b62a0",
                    y: 30
                },
                {
                    name: "Avionics<br>.Fly By Wire performance<br>.Nav Aids performance",
                    color: "#6485ba",
                    y: 30
                },
                {
                    name: "Hydraulics<br>.Particle Analysis<br>.Heat Analysis",
                    color: "#6485ba",
                    y: 20
                },
                {
                    name: "Brakes<br>.Wear prediction",
                    color: "#6485ba",
                    y: 20
                }
            ]
        } ]
    } );
	 

	 
	 
 });