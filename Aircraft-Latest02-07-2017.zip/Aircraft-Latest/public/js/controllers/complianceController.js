
app.controller('complianceController', function($scope, $filter, $http, $rootScope,$state,Auth,$timeout,constants,
		toaster,$cookies,$cookieStore, WorkFlow,Compliance, supplier) {
           $scope.loader=true;
           $rootScope.complianceDone = false; 
		   $scope.supplierInfo = {};

	Auth.getRoles().then(function(roles){ 
    	if(!WorkFlow.getRequestId()){

    		toaster.pop('error', "No Open Task found !", "Request Id is retrieving as null");
			
			if (Auth.isSupplierRole(roles.roles)){
	       		$state.go('supplierHome');
	    	}else{
	        	$state.go('homePage');
	    	}
	    	return;
	    }

	    if (Auth.isSupplierRole(roles.roles)){
	       	$state.go('supplierHome');
	    }

	}, function(data){
    	$scope.loader=false;
    });
    
/*		
           //$rootScope.complianceDone = false;    	 
           if($rootScope.compliance!=''||$rootScope.compliance!=null||$rootScope.compliance!=undefined){
	    	Compliance.getComplianceDetails().then(function(data) {
	    		 $rootScope.compliance = data;
	    	}, function(data) {
	    		$scope.loader=false;
	    		toaster.pop('error', "Compliance API Failed");
	      	});
           }
	$scope.is3TG =false;
		$scope.isGovFacing = false;
		$scope.supplierInfo = {};
		$scope.supplierInfo.conflictOfInterests=false;
		$scope.supplierInfo.provideGovernment="no";
		$scope.supplierInfo.smelterOrRefiner="no";
		$scope.supplierInfo.defaultQuestionnaire = 1;
		$scope.supplierInfo.questGELogo = false;
      $scope.supplierInfo.questDigitalComp = false;
      $scope.supplierInfo.questSmelOrRef = false;	
      $scope.showHideRelationship = false; */
	  

	 /* 
	 $scope.compliance =  {
		  "infoSecurity": {
			"enabled": true,
			"mandatory": true
		  },
		  "conflictOfInterests": {
			"enabled": true,
			"mandatory": true
		  },
		  "conflictOfInterestsComment": {
			"enabled": true,
			"mandatory": true
		  },
		  "onboardingRedFlag": {
			"enabled": true,
			"mandatory": true
		  },
		  "providesDigitalComponentForGE": {
			"enabled": true,
			"mandatory": true
		  },
		  "isTTTGProvider": {
			"enabled": true,
			"mandatory": true
		  },
		  "isTTTGProductProvider": {
			"enabled": true,
			"mandatory": true
		  },
		  "supplierInteractsWithGovernmentForGE": {
			"enabled": true,
			"mandatory": true
		  },
		  "supplierASPFunction": {
			"enabled": true,
			"mandatory": true
		  },
		  "supplierASPFunctionBusinessPurpose": {
			"enabled": true,
			"mandatory": true
		  },
		  "donationPurpose": {
			"enabled": true,
			"mandatory": true
		  },
		  "donationProvidesBenefitsToGE": {
			"enabled": true,
			"mandatory": true
		  },
		  "isUsingGETrademark": {
			"enabled": true,
			"mandatory": true
		  },
		  "laborServicesPurpose": {
			"enabled": true,
			"mandatory": true
		  }
		}*/
		
      $scope.save = function(supplierInfo, next) {
    		$scope.submitted = true;
		  if(supplierInfo.conflictOfInterests==true) {
			  if(supplierInfo.relationshipData==""||supplierInfo.relationshipData==undefined){
				  toaster.pop('error', "Explain the relationship", "Please answer all the mandatory question");	
				  return
			  }
		  }
		  if(supplierInfo.onboardingRedFlag==true){
		  	 if(supplierInfo.onboardingRedFlagComment==""||supplierInfo .onboardingRedFlagComment==undefined){
		  	 	toaster.pop('error', "Describe the concern", "Please answer all the mandatory question");	
				return;
		  	 }
		  }
		  if(supplierInfo.donationProvidesBenefitsToGE==true){
		  	if(supplierInfo.donationProvidesBenefitsToGEComment==""||supplierInfo.donationProvidesBenefitsToGEComment==undefined){
		  		toaster.pop('error', "Please Explain", "Please answer all the mandatory question");	
				return;
		  	}
		  }
		  if(supplierInfo.isSupplierInteractsWithGovernmentForGE==true){
		  	if(supplierInfo.functionPerform==undefined || supplierInfo.functionPerform==""){
				toaster.pop('error', "Select the function", "Please answer all the mandatory question");	
				return;
			}
		  }
                  if(supplierInfo.isSupplierInteractsWithGovernmentForGE==true){
		  	if(supplierInfo.supplierASPFunctionBusinessPurpose==undefined || supplierInfo.supplierASPFunctionBusinessPurpose==""){
				toaster.pop('error', "Please provide business purpose", "Please answer all the mandatory question");	
				return;
			}
		  }
		  if(supplierInfo.conflictOfInterests==null && $scope.compliance.conflictOfInterests.mandatory == true && $scope.compliance.conflictOfInterests.enabled == true){
			  toaster.pop('error', "conflict Of Interests", "Please answer all the mandatory question");	
				return;
		  }
		  if(supplierInfo.defaultQuestionnaire==null && $scope.compliance.infoSecurity.mandatory == true && $scope.compliance.infoSecurity.enabled == true){
			  toaster.pop('error', "Please select supplier details", "Please answer all the mandatory question");	
				return;
		  }
		  if(supplierInfo.onboardingRedFlag==null && $scope.compliance.onboardingRedFlag.mandatory == true && $scope.compliance.onboardingRedFlag.enabled == true){
			  toaster.pop('error', "On Boarding Red Flag", "Please answer all the mandatory question");	
				return;
		  }
		  if(supplierInfo.providesDigitalComponentForGE==null && $scope.compliance.providesDigitalComponentForGE.mandatory == true && $scope.compliance.providesDigitalComponentForGE.enabled == true){
			  toaster.pop('error', "Provides Digital Component For GE", "Please answer all the mandatory question");	
				return;
		  }
		  if(supplierInfo.isTTTGProvider==null && $scope.compliance.isTTTGProvider.mandatory == true && $scope.compliance.isTTTGProvider.enabled == true){
			  toaster.pop('error', "Is TTTG Provider", "Please answer all the mandatory question");	
				return;
		  }if(supplierInfo.isTTTGProductProvider==null && $scope.compliance.isTTTGProductProvider.mandatory == true && $scope.compliance.isTTTGProductProvider.enabled == true){
			  toaster.pop('error', "Is TTTG Product Provider", "Please answer all the mandatory question");	
				return;
		  }
                  if(supplierInfo.isSupplierInteractsWithGovernmentForGE==null && $scope.compliance.isSupplierInteractsWithGovernmentForGE.mandatory == true && $scope.compliance.isSupplierInteractsWithGovernmentForGE.enabled == true){
			  toaster.pop('error', "Is Supplier Interacts With Government For GE", "Please answer all the mandatory question");	
				return;
		  }

		  if(supplierInfo.donationDoneAtTheForeignOfficialRequest==null && $scope.compliance.donationDoneAtTheForeignOfficialRequest.mandatory == true && $scope.compliance.donationDoneAtTheForeignOfficialRequest.enabled == true){
			  toaster.pop('error', "Donation Done At The Foreign Official Request", "Please answer all the mandatory question");	
				return;
		  }
		  if(supplierInfo.donationProvidesBenefitsToGE==null && $scope.compliance.donationProvidesBenefitsToGE.mandatory == true && $scope.compliance.donationProvidesBenefitsToGE.enabled == true){
			  toaster.pop('error', "Donation Provides Benefits To GE", "Please answer all the mandatory question");	
				return;
		  }
		  if(supplierInfo.isUsingGETrademark==null && $scope.compliance.isUsingGETrademark.mandatory == true && $scope.compliance.isUsingGETrademark.enabled == true){
			  toaster.pop('error', "GE Trademark", "Please answer all the mandatory question");	
				return;
		  }
		  if(supplierInfo.laborServicesPurpose==null && $scope.compliance.laborServicesPurpose.mandatory == true && $scope.compliance.laborServicesPurpose.enabled == true){
			  toaster.pop('error', "Labour Service Purpose", "Please answer all the mandatory question");	
				return;
		  }
		  
		  if(supplierInfo.laborServicesPurpose==true){
			  supplierInfo.laborServicesPurpose = 'GE'
		  }
		  if(supplierInfo.laborServicesPurpose==false){
			  supplierInfo.laborServicesPurpose = 'CUSTOMER' 
		  }
                  
			
			/*
		  if(supplierInfo.provideGovernment=="yes") {
			  if(supplierInfo.businessPurpose==""||supplierInfo.businessPurpose==undefined){
				  toaster.pop('error', "Business purpose field is missing", "Please fill all values");
				  return
			  }
		  } */
		  $scope.loader=true;
		  $rootScope.complianceDone = true;    	  
		  
		  $scope.freshCompliance=false;

			
		/*
		TODO:  REQUEST model Change for this page		
	    WfModel.dueDiligences = supplier.setDiligence(WfModel.dueDiligences, 'defaultQuestionnaire', supplierInfo.defaultQuestionnaire );
	    WfModel.dueDiligences = supplier.setDiligence(WfModel.dueDiligences, 'conflictOfInterests', supplierInfo.conflictOfInterests );
	    WfModel.dueDiligences = supplier.setDiligence(WfModel.dueDiligences, 'relationshipData', supplierInfo.relationshipData );
	    WfModel.dueDiligences = supplier.setDiligence(WfModel.dueDiligences, 'functionPerform', supplierInfo.functionPerform );
	    WfModel.dueDiligences = supplier.setDiligence(WfModel.dueDiligences, 'provideGovernment', supplierInfo.provideGovernment );
	    WfModel.dueDiligences = supplier.setDiligence(WfModel.dueDiligences, 'businessPurpose', supplierInfo.businessPurpose );
	    WfModel.dueDiligences = supplier.setDiligence(WfModel.dueDiligences, 'questGELogo', supplierInfo.questGELogo );
	    WfModel.dueDiligences = supplier.setDiligence(WfModel.dueDiligences, 'questDigitalComp', supplierInfo.questDigitalComp );
	    WfModel.dueDiligences = supplier.setDiligence(WfModel.dueDiligences, 'smelterOrRefiner', supplierInfo.smelterOrRefiner );
	    WfModel.dueDiligences = supplier.setDiligence(WfModel.dueDiligences, 'country3TG', supplierInfo.country3TG );
	    WfModel.dueDiligences = supplier.setDiligence(WfModel.dueDiligences, 'provideGovernment', supplierInfo.provideGovernment );
		*/
		
		
		// New models
		WfModel.dueDiligence = (WfModel.dueDiligence==null)?{}:WfModel.dueDiligence;
		
		WfModel.dueDiligence.infoSecurity = supplierInfo.defaultQuestionnaire;
		WfModel.dueDiligence.conflictOfInterests  = supplierInfo.conflictOfInterests;  
		WfModel.dueDiligence.conflictOfInterestsComment = supplierInfo.relationshipData;
		WfModel.dueDiligence.onboardingSupplierRedFlag = supplierInfo.onboardingRedFlag;
		WfModel.dueDiligence.onboardingSupplierRedFlagComment = supplierInfo.onboardingRedFlagComment;
		WfModel.dueDiligence.donationProvidesBenefitsToGEComment = supplierInfo.donationProvidesBenefitsToGEComment;
		WfModel.dueDiligence.donationPurpose = supplierInfo.donationPurpose; 
		WfModel.dueDiligence.providesDigitalComponentForGE = supplierInfo.providesDigitalComponentForGE;
		WfModel.dueDiligence.isTTTGProvider  = supplierInfo.isTTTGProvider;
		WfModel.dueDiligence.isTTTGProductProvider   = supplierInfo.isTTTGProductProvider;
		WfModel.dueDiligence.supplierInteractsWithGovernmentForGE    = supplierInfo.isSupplierInteractsWithGovernmentForGE;
		WfModel.dueDiligence.supplierASPFunction     = false; // id from ref data
		WfModel.dueDiligence.supplierASPFunctionBusinessPurpose      = supplierInfo.supplierASPFunctionBusinessPurpose; 
		WfModel.dueDiligence.supplierASPFunctionId = supplierInfo.functionPerform;
		WfModel.dueDiligence.donationDoneAtTheForeignOfficialRequest  = supplierInfo.donationDoneAtTheForeignOfficialRequest; 
		WfModel.dueDiligence.donationProvidesBenefitsToGE  = supplierInfo.donationProvidesBenefitsToGE; 
		WfModel.dueDiligence.isUsingGETrademark   = supplierInfo.isUsingGETrademark; 
		WfModel.dueDiligence.laborServicesPurpose    = supplierInfo.laborServicesPurpose;  // customer/GE
		WorkFlow.setVariablesV2(WfModel).then(function(data) {
			  $scope.loader=false;
		  		if(next){
		  			$state.go('poSettings');
		  		}
			toaster.pop('success', "Saved successfully");		
		},function(data){
			$scope.loader=false;
			toaster.pop('error','Workflow Api', "Server not Responding");
		});
		
		
  		

  	}
      
      
      
      $scope.prevForCompliance=function(){
    	
    	  $state.go('businessInfo');
      }
	  
	var WfModel = {};
	Compliance.getComplianceRules().then(function(data) {
				$scope.loader = false;		
				$scope.compliance = data.data;
				if($scope.compliance.length <= 0){
					$scope.showButtons = false;
				}else{
					$scope.showButtons = true;
				}
				
				 
				 
			  WorkFlow.getVariablesV2().then(function(workflowData) {	

						WfModel = workflowData.data;
						$rootScope.complianceDone = false;  
						if(workflowData.data) {
														
							$scope.supplierInfo.defaultQuestionnaire = WfModel.dueDiligence.infoSecurity;
							$scope.supplierInfo.conflictOfInterests = WfModel.dueDiligence.conflictOfInterests;  
							$scope.supplierInfo.relationshipData = WfModel.dueDiligence.conflictOfInterestsComment;  
							$scope.supplierInfo.onboardingRedFlag = WfModel.dueDiligence.onboardingSupplierRedFlag;  			
							$scope.supplierInfo.onboardingRedFlagComment = WfModel.dueDiligence.onboardingSupplierRedFlagComment;
							$scope.supplierInfo.providesDigitalComponentForGE = WfModel.dueDiligence.providesDigitalComponentForGE;  
							$scope.supplierInfo.isTTTGProvider = WfModel.dueDiligence.isTTTGProvider;  
							$scope.supplierInfo.isTTTGProductProvider = WfModel.dueDiligence.isTTTGProductProvider; 

							
							$scope.supplierInfo.isSupplierInteractsWithGovernmentForGE = WfModel.dueDiligence.supplierInteractsWithGovernmentForGE;
							$scope.supplierInfo.functionPerform = parseInt(WfModel.dueDiligence.supplierASPFunctionId);
							
							$scope.supplierInfo.supplierASPFunctionBusinessPurpose = WfModel.dueDiligence.supplierASPFunctionBusinessPurpose;				
							//WfModel.dueDiligence.supplierASPFunction     = false; // id from ref data
							
							
							$scope.supplierInfo.donationPurpose = WfModel.dueDiligence.donationPurpose;				
							$scope.supplierInfo.donationDoneAtTheForeignOfficialRequest = WfModel.dueDiligence.donationDoneAtTheForeignOfficialRequest;
							$scope.supplierInfo.donationProvidesBenefitsToGE = WfModel.dueDiligence.donationProvidesBenefitsToGE;				
							$scope.supplierInfo.donationProvidesBenefitsToGEComment = WfModel.dueDiligence.donationProvidesBenefitsToGEComment;
							
							$scope.supplierInfo.isUsingGETrademark = WfModel.dueDiligence.isUsingGETrademark;
							$scope.supplierInfo.laborServicesPurpose = (WfModel.dueDiligence.laborServicesPurpose=='GE')?true:false;	
                                                        
							
							
									
							/*
						
							$scope.supplierInfo.defaultQuestionnaire = supplier.getDiligence(WfModel.dueDiligences, 'defaultQuestionnaire');									
							$scope.supplierInfo.conflictOfInterests = supplier.getDiligence(WfModel.dueDiligences, 'conflictOfInterests');									
							$scope.supplierInfo.functionPerform = supplier.getDiligence(WfModel.dueDiligences, 'functionPerform');									
							$scope.supplierInfo.provideGovernment = supplier.getDiligence(WfModel.dueDiligences, 'provideGovernment');									
							$scope.supplierInfo.businessPurpose = supplier.getDiligence(WfModel.dueDiligences, 'businessPurpose');									
							$scope.supplierInfo.relationshipData = supplier.getDiligence(WfModel.dueDiligences, 'relationshipData');									
							$scope.supplierInfo.questGELogo = supplier.getDiligence(WfModel.dueDiligences, 'questGELogo');									
							$scope.supplierInfo.questDigitalComp = supplier.getDiligence(WfModel.dueDiligences, 'questDigitalComp');									
							$scope.supplierInfo.smelterOrRefiner = supplier.getDiligence(WfModel.dueDiligences, 'smelterOrRefiner');									
							$scope.supplierInfo.country3TG = supplier.getDiligence(WfModel.dueDiligences, 'country3TG');									
							$scope.supplierInfo.provideGovernment = supplier.getDiligence(WfModel.dueDiligences, 'provideGovernment');									
							
							
							   $rootScope.history=true;				   
							   if($scope.supplierInfo.relationshipData!=undefined){
								$scope.conflictText=true;
							   }
							   else{
								   $scope.conflictText=false;  
							   }
							   if($scope.supplierInfo.smelterOrRefiner=="yes"){
							   $scope.countryFor3TG=true
							   }
							   
							   if($scope.supplierInfo.provideGovernment=="yes"){
							   $scope.businessPurpose=true
							   }
							   
							   if(!$scope.supplierInfo.smelterOrRefiner){
								   $scope.supplierInfo.smelterOrRefiner="no";
							   }
							   if(!$scope.supplierInfo.conflictOfInterests){
								   $scope.supplierInfo.conflictOfInterests=false
							   }
							   if(!$scope.supplierInfo.provideGovernment){
								   $scope.supplierInfo.provideGovernment="no"
							   }
							   if(!$scope.supplierInfo.questGELogo){
								   $scope.supplierInfo.questGELogo=false
							   }
							   if(!$scope.supplierInfo.questDigitalComp){
								   $scope.supplierInfo.questDigitalComp=false;
							   }
							   
							   */
							 //$rootScope.complianceDone = true;
							 $rootScope.businessInfoDone = true;
							$rootScope.supplierInfoDone = true;  
							$scope.loader =false;
						}

					}, function(data) {
						$scope.loader=false;
						$rootScope.complianceDone = false;	   
				  });
				 
			}, function(data) {				
				$scope.loader=false;
				toaster.pop('error', "Compliance API Failed");
	});
      
     
	
	
      
/*
    
           $('#myFormSmelter input').on('change', function() {
        	   $scope.loader=true;
		   var radioValue = $('input[name="radio_smelter"]:checked').val(); 
		   if(radioValue=='yes'){
			   $scope.is3TG =true;
		    	var data={
		    			"commodityFamilyId": $cookieStore.get("commodityFamilyId"), 
		    		    "is3TG" :$scope.is3TG,
		    		    "isGovFacing": $scope.isGovFacing
		    		}
		    	console.log("smelter",data);
		    	Compliance.smelterOrGovernment(data).then(function(data) {
		    		$scope.loader=false;
		    		$rootScope.compliance = data;
		    		if(data.businessPurpose==true){
		    			$scope.businessPurpose=true;
		    		}
		    		else{$scope.businessPurpose=false;}
		    		if(data.conflictOfInterests==true){
		    			$scope.conflictOfInterests=true;	
		    		}
		    		else{$scope.conflictOfInterests=false;}
		    		if(data.countryFor3TG==true){
		    			$scope.countryFor3TG=true;
		    		}
		    		else{$scope.countryFor3TG=false;}
		    		if(data.functionPerform==true){
		    			$scope.functionPerform=true;
		    		}
		    		else{$scope.functionPerform=false}
		    		if(data.infoSecurity==true){
		    			$scope.infoSecurity=true;
		    		}
		    		else{$scope.infoSecurity=false}
		    		if(data.packagingManufacturer==true){
		    			$scope.packagingManufacturer=true;
		    		}
		    		else{$scope.packagingManufacturer=false}
		    		if(data.provideDigitalComponent==true){
		    			$scope.provideDigitalComponent=true;
		    		}
		    		else{$scope.provideDigitalComponent=false;}
		    		if(data.provideGovernment==true){
		    			$scope.provideGovernment=true;	
		    		}
		    		else{$scope.provideGovernment=false;}
		    		if(data.smelterOrRefiner==true){
		    			$scope.smelterOrRefiner=true;
		    		}
		    		else{$scope.smelterOrRefiner=false;}

		    	  	
		    	}, function(data) {
		    		$scope.loader=false;
		      	});
		   }
		   if(radioValue=='no'){
			   $scope.is3TG =false;
		    	var data={
		    			"commodityFamilyId": $cookieStore.get("commodityFamilyId"), 
		    		    "is3TG" :$scope.is3TG,
		    		    "isGovFacing": $scope.isGovFacing
		    		}
		    	console.log("smelter",data);
		    	Compliance.smelterOrGovernment(data).then(function(data) {
		    		$scope.loader=false;
		    		$rootScope.compliance = data;
		    		if(data.businessPurpose==true){
		    			$scope.businessPurpose=true;
		    		}
		    		else{$scope.businessPurpose=false;}
		    		if(data.conflictOfInterests==true){
		    			$scope.conflictOfInterests=true;	
		    		}
		    		else{$scope.conflictOfInterests=false;}
		    		if(data.countryFor3TG==true){
		    			$scope.countryFor3TG=true;
		    		}
		    		else{$scope.countryFor3TG=false;}
		    		if(data.functionPerform==true){
		    			$scope.functionPerform=true;
		    		}
		    		else{$scope.functionPerform=false}
		    		if(data.infoSecurity==true){
		    			$scope.infoSecurity=true;
		    		}
		    		else{$scope.infoSecurity=false}
		    		if(data.packagingManufacturer==true){
		    			$scope.packagingManufacturer=true;
		    		}
		    		else{$scope.packagingManufacturer=false}
		    		if(data.provideDigitalComponent==true){
		    			$scope.provideDigitalComponent=true;
		    		}
		    		else{$scope.provideDigitalComponent=false;}
		    		if(data.provideGovernment==true){
		    			$scope.provideGovernment=true;	
		    		}
		    		else{$scope.provideGovernment=false;}
		    		if(data.smelterOrRefiner==true){
		    			$scope.smelterOrRefiner=true;
		    		}
		    		else{$scope.smelterOrRefiner=false;}

		    	  	
		    	}, function(data) {
		    		$scope.loader=false;
		      	});
			   
			  
		   }
		   
	});
	
	
	$('#myFormGovtFacing input').on('change', function() {
		$scope.loader=true;
		   var radioValue = $('input[name="myRadio_gov"]:checked').val(); 
		   if(radioValue=='yes'){
			   $scope.isGovFacing =true;
		    	var data={
		    		    "commodityId": $cookieStore.get("commodityId"), 
		    		    "is3TG" :$scope.is3TG,

		    		    "isGovFacing": $scope.isGovFacing
		    		}
		    	console.log("myFormGovtFacing",data);
		    	Compliance.smelterOrGovernment(data).then(function(data) {
		    		$scope.loader=false;
		    		$rootScope.compliance = data;
		    		if(data.businessPurpose==true){
		    			$scope.businessPurpose=true;
		    		}
		    		else{$scope.businessPurpose=false;}
		    		if(data.conflictOfInterests==true){
		    			$scope.conflictOfInterests=true;	
		    		}
		    		else{$scope.conflictOfInterests=false;}
		    		if(data.countryFor3TG==true){
		    			$scope.countryFor3TG=true;
		    		}
		    		else{$scope.countryFor3TG=false;}
		    		if(data.functionPerform==true){
		    			$scope.functionPerform=true;
		    		}
		    		else{$scope.functionPerform=false}
		    		if(data.infoSecurity==true){
		    			$scope.infoSecurity=true;
		    		}
		    		else{$scope.infoSecurity=false}
		    		if(data.packagingManufacturer==true){
		    			$scope.packagingManufacturer=true;
		    		}
		    		else{$scope.packagingManufacturer=false}
		    		if(data.provideDigitalComponent==true){
		    			$scope.provideDigitalComponent=true;
		    		}
		    		else{$scope.provideDigitalComponent=false;}
		    		if(data.provideGovernment==true){
		    			$scope.provideGovernment=true;	
		    		}
		    		else{$scope.provideGovernment=false;}
		    		if(data.smelterOrRefiner==true){
		    			$scope.smelterOrRefiner=true;
		    		}
		    		else{$scope.smelterOrRefiner=false;}

		    	  	
		    	}, function(data) {
		    		$scope.loader=false;
		      	});
		   }
		   if(radioValue=='no'){
			   $scope.isGovFacing =false;
		    	var data={
		    		    "commodityId": $cookieStore.get("commodityId"), 
		    		    "is3TG" :$scope.is3TG,
		    		    "isGovFacing": $scope.isGovFacing
		    		}
		    	console.log("myFormGovtFacing",data);
		    	Compliance.smelterOrGovernment(data).then(function(data) {
		    		$scope.loader=false;
		    		$rootScope.compliance = data;
		    		if(data.businessPurpose==true){
		    			$scope.businessPurpose=true;
		    		}
		    		else{$scope.businessPurpose=false;}
		    		if(data.conflictOfInterests==true){
		    			$scope.conflictOfInterests=true;	
		    		}
		    		else{$scope.conflictOfInterests=false;}
		    		if(data.countryFor3TG==true){
		    			$scope.countryFor3TG=true;
		    		}
		    		else{$scope.countryFor3TG=false;}
		    		if(data.functionPerform==true){
		    			$scope.functionPerform=true;
		    		}
		    		else{$scope.functionPerform=false}
		    		if(data.infoSecurity==true){
		    			$scope.infoSecurity=true;
		    		}
		    		else{$scope.infoSecurity=false}
		    		if(data.packagingManufacturer==true){
		    			$scope.packagingManufacturer=true;
		    		}
		    		else{$scope.packagingManufacturer=false}
		    		if(data.provideDigitalComponent==true){
		    			$scope.provideDigitalComponent=true;
		    		}
		    		else{$scope.provideDigitalComponent=false;}
		    		if(data.provideGovernment==true){
		    			$scope.provideGovernment=true;	
		    		}
		    		else{$scope.provideGovernment=false;}
		    		if(data.smelterOrRefiner==true){
		    			$scope.smelterOrRefiner=true;
		    		}
		    		else{$scope.smelterOrRefiner=false;}

		    	  	
		    	}, function(data) {
		    		$scope.loader=false;
		      	});
			   
			  
		   }
	});*/
   
	Compliance.getPerform().then(function(data) {
		$scope.performFunctions = data;
	  	
	}, function(data) {
		$scope.loader=false;
		toaster.pop('error', "Functions API Failed");
  	});
	
	
	
    
	
});