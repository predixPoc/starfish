app.controller('onboardingProfileAddress', function($scope, $filter, $http, $rootScope, constants,
    $state, Auth, $timeout, toaster, $cookies, $cookieStore, $q, WorkFlow, supplier) {

    // XXX: remove
    // $cookieStore.put("requestId", 501726);
    // XXX: remove

    $scope.loader = true;
    $scope.supplierInfo = {};
    $scope.supplierInfo.legalentitiy = {};
    if (!WorkFlow.getRequestId()) {
//    if (WorkFlow.getRequestId()) {
        toaster.pop('error', "No Open Task found !", "Request Id is retrieving as null");
        //   $state.go('supplierHome');
        return;
    }

    supplier.getAddressRule(WorkFlow.getRequestId()).then(function(data) {
        $scope.addressRule = data;
    }, function() {
        toaster.pop('error', "Address Rule", "server not responding");
    });
	
	$scope.stateChange = function(item, states) {
		angular.forEach(states, function(value, index) {
		   if(value.id==item.stateId) {
			   debugger;
			  item.stateName = value.code; 
		   }
		});
	}
    // Get State List
    $scope.getStates = function(countryid, type, index) {
        $scope.loader = true;
        if(countryid == undefined){
            $scope.loader = false;
            $scope.stateList = [];
            return;
        }
        var countryData = $filter('filter')($scope.countryList, {
            id: countryid
        });
        if (countryData && countryData.length > 0) {
            var countryCode = countryData[0].code;
            supplier.getStatesList(countryCode).then(function(data) {
                // $scope.loader = false;
                if (!$scope.stateList) {
                    $scope.stateList = [];
                    // $scope.loader = false;
                }
                if (type === 'legal') {
                    $scope.stateList.legal = {};
                    $scope.stateList.legal.fieldLabel = data[0].authorityName;
                    $scope.stateList.legal.states = data[0].subdivisions;
                } else if (type === 'of') {
                    if (!$scope.stateList.of) {
                        $scope.stateList.of = []
                    }
                    $scope.stateList.of[index] = {};
                    $scope.stateList.of[index].fieldLabel = data[0].authorityName;
                    $scope.stateList.of[index].states = data[0].subdivisions;
                } else if (type === 'ma') {
                    if (!$scope.stateList.ma) {
                        $scope.stateList.ma = []
                    }
                    $scope.stateList.ma[index] = {};    
                    $scope.stateList.ma[index].fieldLabel = data[0].authorityName;
                    $scope.stateList.ma[index].states = data[0].subdivisions;
                } else if (type === 'sh') {
                    if (!$scope.stateList.sh) {
                        $scope.stateList.sh = []
                    }
                    $scope.stateList.sh[index] = {};    
                    $scope.stateList.sh[index].fieldLabel = data[0].authorityName;
                    $scope.stateList.sh[index].states = data[0].subdivisions;
                }
                $scope.loader = false;
            }, function() {
                $scope.loader = false;
                toaster.pop('error', "State list", "server not responding");
            });
        }
    }

    // Add Address
    $scope.addAddress = function(addressType) {
        if (addressType == 'orderFulfilment') {
            if (!$scope.supplierInfo.orderFulfilmentAddress) {
                $scope.supplierInfo.orderFulfilmentAddress = [];
            }
            $scope.supplierInfo.orderFulfilmentAddress.push({});
        } else if (addressType == 'manufacturing') {
            if (!$scope.supplierInfo.manufacturingAddress) {
                $scope.supplierInfo.manufacturingAddress = [];
            }
            $scope.supplierInfo.manufacturingAddress.push({});
        } else if (addressType == 'alternateShip') {
            if (!$scope.supplierInfo.alternateShip) {
                $scope.supplierInfo.alternateShip = [];
            }
            $scope.supplierInfo.alternateShip.push({});
        }
    };

    // Delete Address
    $scope.deleteAddress = function(addressType, address) {		
        if (addressType == 'orderFulfilment') {
            var index = $scope.supplierInfo.orderFulfilmentAddress.indexOf(address)
            $scope.supplierInfo.orderFulfilmentAddress.splice(index, 1);
            if($scope.supplierInfo.orderFulfilmentAddress.length < 1){
                $scope.supplierInfo.orderFulfilmentAddress = undefined;
            }
			$scope.stateList.of[index].fieldLabel = 'States';
            $scope.stateList.of[index].states = '';
            
        } else if (addressType == 'alternateShip') {
            var index = $scope.supplierInfo.alternateShip.indexOf(address)
            $scope.supplierInfo.alternateShip.splice(index, 1);
			$scope.stateList.sh[index].fieldLabel = 'States';
            $scope.stateList.sh[index].states = '';
        } else if (addressType == 'manufacturing') {
            var index = $scope.supplierInfo.manufacturingAddress.indexOf(address)
            $scope.supplierInfo.manufacturingAddress.splice(index, 1);
			$scope.stateList.ma[index].fieldLabel = 'states';
            $scope.stateList.ma[index].states = '';
        }
    };

    // Back Button
    $scope.prev = function() {
        $state.go('supplierProfileCompany');
    }

    var  checkEmail = function(email){
        var regExp = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return regExp.test(email);
    }
    // Save Button
    $scope.saveAndNext = function(supplierInfo, next, supplierForm) {
        $scope.loader = true;
        // if(!$scope.supplierInfo.legalAsOf && $scope.supplierInfo.orderFulfilmentAddress == undefined){
        //     toaster.pop("error",  "ORDER FULLFILLING ADDRESS", "Please check or add orderFulfilment address");
        //     $scope.loader = false;
        //     return;
        // }
        // if (form) {
            $scope.submitted = true;
            if(supplierForm.$invalid) {
                toaster.pop('error', "ENTITY ADDRESS PAGE", "Please fill all mandatory fields"); 
                $scope.loader = false;  
                return;
            }
//            if(supplierForm.alternateShip.$invalid) {
//                toaster.pop('error', "Alternate Ship", "Please fill all mandatory fields"); 
//                $scope.loader = false;  
//                return;
//            }
            if(!$scope.supplierInfo.legalAsOf && $scope.supplierInfo.orderFulfilmentAddress == undefined ){
                toaster.pop("error",  "ORDER FULFILMENT ADDRESS", "Please check or add order fulfilment address");
                $scope.loader = false;
                return;
            }

            // if($scope.supplierInfo.orderFulfilmentAddress.length <= 0){
            //     toaster.pop("error",  "ORDER FULLFILLING ADDRESS", "Please check or add order fulfillment address");
            //     $scope.loader = false;
            //     return;
            // }
            if (!WfModel.supplier) {
                WfModel.supplier = {};
            }
            WfModel.supplier.addresses = []

            // Add Legal Address to WfModel Address List
            var legalAddressTypes = [];
            legalAddressTypes.push("LEGAL");
            if ($scope.supplierInfo.legalAsOf) {
                legalAddressTypes.push("ORDER_FULLFILLING");
            }
            if ($scope.supplierInfo.legalAsMa) {
                legalAddressTypes.push("MANUFACTURING");
            }

            //$scope.supplierInfo.legalentitiy.stateName = $scope.supplierInfo.legalentitiy.stateName.subdivisionName;
            
            WfModel.supplier.addresses.push({
                "addressTypes": legalAddressTypes,
                "location": $scope.supplierInfo.legalentitiy,

            });
            

            // Add Legal Address to WfModel Address List
            if ($scope.supplierInfo.orderFulfilmentAddress) {
                angular.forEach($scope.supplierInfo.orderFulfilmentAddress, function(address, index) {
                    //address.stateName = address.stateName.subdivisionName;
                    var remittanceEmailAddress = address.remittance;
                    var emailsForRemittanceAddress = remittanceEmailAddress.split(";");
                    var invEmails = "";
                    for(i = 0; i <= (emailsForRemittanceAddress.length - 1); i++){
                        if(checkEmail(emailsForRemittanceAddress[i])){
                            $scope.emailForRemittance = emailsForRemittanceAddress;
                        }else{
                            invEmails += emailsForRemittanceAddress[i] + "\n";
                        }
                    }
                    if(invEmails != ""){
                        toaster.pop('error', "Invalid emails:\n" + invEmails);
                    }
                    WfModel.supplier.addresses.push({
                        "addressTypes": [
                            "ORDER_FULLFILLING"
                        ],
                        "emailForPurchaseOrders": address.email,
                        "location": address,
                        "alternateName": address.alternateName,
                        "emailForRemittance":address.remittance
                    });
                });
            }

            // Add Legal Address to WfModel Address List
            if ($scope.supplierInfo.manufacturingAddress) {
                angular.forEach($scope.supplierInfo.manufacturingAddress, function(address, index) {
                    //address.stateName = address.stateName.subdivisionName;
                    WfModel.supplier.addresses.push({
                        "addressTypes": [
                            "MANUFACTURING"
                        ],
                        "emailForPurchaseOrders": address.email,
                        "location": address,
                        "alternateName": address.alternateName
                    });
                });
            }
            // Add alternateShip Address to WfModel Address List
            if ($scope.supplierInfo.alternateShip) {
                angular.forEach($scope.supplierInfo.alternateShip, function(address, index) {
                    //address.stateName = address.stateName.subdivisionName;
                    WfModel.supplier.addresses.push({
                        "addressTypes": [
                            "SHIP_FROM_ALT"
                        ],
                        "emailForPurchaseOrders": address.email,
                        "location": address,
                        "alternateName": address.alternateName
                    });
                });
            }

            WorkFlow.setVariablesV2(WfModel).then(function(data) {
                $scope.loader = false;
                $rootScope.supplierProfileAddressDone = true;
                toaster.pop('success', "Saved successfully");
                if (next) {
                    $state.go('supplierProfileBank');
                }
            }, function(data) {
                $scope.loader = false;
                toaster.pop('error', "Workflow Api failed","Server not responding");
            });
        // } else {
        //     $scope.loader = false;
        // }
    }

    var WfModel = {};
    $scope.initialize = function() {
        WorkFlow.getVariablesV2().then(function(workflowData) {

            WfModel = workflowData.data;
            if (workflowData.data.supplier && workflowData.data.supplier.addresses && workflowData.data.supplier.addresses.length > 0) {
                angular.forEach(workflowData.data.supplier.addresses, function(address, index) {
                    if (address.addressTypes.indexOf("LEGAL") != -1) {
                        $scope.supplierInfo.legalentitiy = address.location;
                        $scope.supplierInfo.legalentitiy.countryId = parseInt(address.location.countryId);
                        $scope.supplierInfo.legalentitiy.stateId = parseInt(address.location.stateId);
                        $scope.getStates(address.location.countryId, 'legal');
                        if (address.addressTypes.indexOf("ORDER_FULLFILLING") != -1) {
                            $scope.supplierInfo.legalAsOf = true;
                        }
                        if (address.addressTypes.indexOf("MANUFACTURING") != -1) {
                            $scope.supplierInfo.legalAsMa = true;

                        }
                    } else {
                        if (address.addressTypes.indexOf("ORDER_FULLFILLING") != -1 && address.addressTypes.indexOf("LEGAL") == -1) {
                            if (!$scope.supplierInfo.orderFulfilmentAddress) {
                                $scope.supplierInfo.orderFulfilmentAddress = [];
                            }
                            var index = $scope.supplierInfo.orderFulfilmentAddress.push(address.location);
                            $scope.supplierInfo.orderFulfilmentAddress[index - 1].countryId = parseInt(address.location.countryId);
                            $scope.supplierInfo.orderFulfilmentAddress[index - 1].stateId = parseInt(address.location.stateId);
                            $scope.supplierInfo.orderFulfilmentAddress[index - 1].email = address.emailForPurchaseOrders;
                            $scope.supplierInfo.orderFulfilmentAddress[index - 1].remittance = address.emailForRemittance;
                            $scope.supplierInfo.orderFulfilmentAddress[index - 1].alternateName = address.alternateName;
                            $scope.getStates(address.location.countryId, 'of', index - 1);
                        } else if (address.addressTypes.indexOf("MANUFACTURING") != -1 && address.addressTypes.indexOf("LEGAL") == -1) {
                            if (!$scope.supplierInfo.manufacturingAddress) {
                                $scope.supplierInfo.manufacturingAddress = [];
                            }
                            var index = $scope.supplierInfo.manufacturingAddress.push(address.location);
                            $scope.supplierInfo.manufacturingAddress[index - 1].countryId = parseInt(address.location.countryId);
                            $scope.supplierInfo.manufacturingAddress[index - 1].stateId = parseInt(address.location.stateId);
                            $scope.supplierInfo.manufacturingAddress[index - 1].email = address.emailForPurchaseOrders;
                            $scope.supplierInfo.manufacturingAddress[index - 1].alternateName = address.alternateName;
                            $scope.getStates(address.location.countryId, 'ma', index - 1);
                        }else if (address.addressTypes.indexOf("SHIP_FROM_ALT") != -1 && address.addressTypes.indexOf("LEGAL") == -1) {
                            if (!$scope.supplierInfo.alternateShip) {
                                $scope.supplierInfo.alternateShip = [];
                            }
                            var index = $scope.supplierInfo.alternateShip.push(address.location);
                            $scope.supplierInfo.alternateShip[index - 1].countryId = parseInt(address.location.countryId);
                            $scope.supplierInfo.alternateShip[index - 1].stateId = parseInt(address.location.stateId);
                            $scope.supplierInfo.alternateShip[index - 1].email = address.emailForPurchaseOrders;
                            $scope.supplierInfo.alternateShip[index - 1].alternateName = address.alternateName;
                            $scope.getStates(address.location.countryId, 'sh', index - 1);
                        }
                    }
                });
            }
            $scope.loader = false;
        }, function(data) {
            $scope.loader = false;
        });
    }
    // Get Country List
    supplier.getCountryList().then(function(data) {
        $scope.countryList = data;
        $scope.initialize();
    }, function() {
        $scope.loader = false;
        toaster.pop('error', "Country list", "server not responding");
    });
});
