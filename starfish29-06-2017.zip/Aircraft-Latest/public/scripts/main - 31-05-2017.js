var flightIdFromService;
var flightIdval;
var poc3JsonData;
var poc3NewArray;
var airborneDtoList;
var groundDtoList;
var dynamicFlightIdForPoc3;
var pocDatatable;
var totalFlightDataList;
var multipleArrayPoc3=[];
var pressureAltitudeArray;
var airspeedArray;
var multiParamsDataArrayPoc3;
var chartTitlesArrayPoc3;
var takeoffTime;
var landingTime;
var clusterFlightId;
var clusterData;
var verticalAccelartion;
var clusterArray1;
var clusterArray2;
var clusterArray3;
var clusterArray4;
var clusterArray5;
var fireFlightMaxRange = '';
var cargoFlightMaxRange='';
var yasixToRangeMax = '';
var graphJsonData;
var jsonObj;
var testData;
var testDataMultiple;
var charts;
var flightId ;
var xaxis;
var yaxis ;
var title;
var scatterText;
var graphData2;
var flightIdOuter;
var minelapseTimeOuter;
var maxelapseTimeOuter;
var sumoObj;
var yaxisArray;
var xaxisArray;
var scatterArray1;
var testDataMultipleLineGraph;
var multipleArrayChartData;
var chartCategories12;
var multiLineArrayAxis;
var chartTitlesArray;
var textTitleSingleGraph;
var dynamicFlightId
var avg=0;
var yaxisArraySingleParameter ;
var  xaxisArraySingleParameter;
var yaxisArrayGarph2;
var xaxisArrayGraph2;
var scatterArrayGraph1;
var xaxisStaticRangeScale;
var yaxisStaticRangeScale;
var xaxiscrossdata={};
var crossParameterRangeSelectionXaxis;
var crossParameterRangeSelectionYaxis;
var multiYaxisArray;
var multiYaxisArray1;
var multiYaxisArray2;
var multiplexaxisArray;
var chartCategories11;
//Regression Analysis : start
var jsonDatapoc5;

//Regression Analysis : end
var commonFlightId;

var i_multiData=0;


var clusterChartLeft;
var clusterChartRight;

var responseJsonDataForFlight;
var myArrayNew;
var flightDataDataTable;

var oTable;

var graphJsonDataArray;

var chart1SingleChart;

var singleparameterChart;


 $(document).ready(function () {/*******Start of Document Ready Function******************/
 $('.SlectBox4').SumoSelect();

 	$(".signImage").click(function () {

    $signImage = $(this);
    $content1 = $signImage.next();
    $content1.slideToggle(500, function () {
		alert("ddd");
        $signImage.text(function () {
            return $content1.is(":visible") ? "- Filter Parameters" : "+ Filter Parameters";
        });
    });

});
 //$(".loadingChart5").css("visibility", "visible");
 //$("#prepareDataSetId").hide();
 //$("#searchBoxIdDate").hide();
// $("#dateRangeId").hide();
//$("#dateRangeId").hide();
	//showDataTable(response);
  myArrayNew =[
                { "sTitle": "Flight Id", "mData": "flightId" },
				{ "sTitle": "Elapsed Time ", "mData": "elapsedTime" },
				{ "sTitle": "Record Type", "mData": "recordType" },
                { "sTitle": "Air Speed", "mData": "airspeed" },
				{ "sTitle": "Pressure Altitude", "mData": "pressureAltitude" },
				{ "sTitle": "Vertical Acceleration", "mData": "verticalAcceleration" },
                { "sTitle": "Roll Acceleration ", "mData": "rollAcceleration" },
				{ "sTitle": "Strain Gauge 1", "mData": "strainGauge1" },
				{ "sTitle": "Strain Gauge 2", "mData": "strainGauge2" },
				{ "sTitle": "Strain Gauge 3", "mData": "strainGauge3" },
				{ "sTitle": "Strain Gauge 4", "mData": "strainGauge4" },
				{ "sTitle": "Strain Gauge 5", "mData": "strainGauge5" },
				{ "sTitle": "Strain Gauge 6", "mData": "strainGauge6" },
				{ "sTitle": "Strain Gauge 7", "mData": "strainGauge7" },
				{ "sTitle": "Strain Gauge 8", "mData": "strainGauge8" },
				{ "sTitle": "Strain Gauge 9", "mData": "strainGauge9" },
				{ "sTitle": "StartDate", "mData": "startDate" },
                { "sTitle": "Elevator Position", "mData": "elevatorPosition" },
                { "sTitle": "Peak Valley Indicator ", "mData": "peakValleyIndicator" },
				{ "sTitle": "Flap Position", "mData": "flapPosition" },
                { "sTitle": "Fleet Id", "mData": "fleetId" },               
				{ "sTitle": "Left Aileron Position", "mData": "leftAileronPosition" },
                { "sTitle": "Retardant Door Open", "mData": "retardantDoorOpen" },
                { "sTitle": "Timestamp", "mData": "timestamp" },
                { "sTitle": "Retardant Tank Float", "mData": "retardantTankFloat" },
                { "sTitle": "Trigger Channel", "mData": "triggerChannel" },                
                { "sTitle": "Gear Up And Locked ", "mData": "gearUpAndLocked" },
				{ "sTitle": "Arm Retardant Tank Door", "mData": "armRetardantTankDoor" },        
                { "sTitle": "Beacon Start Stop Recording", "mData": "beaconStartStopRecording" }
                           
            ]; 
			
	//getFlightData();
	
	
	
	$("#searchFlightDataId").click(function(){
		 $(".loadingChart5").css("visibility", "visible");
		
		var tailNum= $("#tailNumId").val();
		var flightIdUrl="https://aircraft-svc-techmspace.run.aws-usw02-pr.ice.predix.io/view/getSelectedFlightsData";
		$.ajax({
			url:flightIdUrl+"/"+tailNum,
			type: "GET",
			headers : {
			'Content-Type' : 'application/json'
			},
			success: function(responseData) {
			responseJsonDataForFlight=responseData;
			showDataTable(responseJsonDataForFlight);
			$(".loadingChart5").css("visibility", "hidden");
			$("#prepareDataSetId").show();
			$("#yadcf-filter--invoicedataTable-from-date-16").val('06-26-2004');
		},

   error: function ( xhr, status, error) {
	   $(".loadingChart5").css("visibility", "hidden");
    console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
    }
    });	
		
		
	});
	
	
	
	
	$("#tailNumId").change(function(){
		var fighterCount=0;
		var cargoCount=0;
		var splitofTailNum= $("#tailNumId").val();
		
		var splitTail=splitofTailNum.toString().split(",");
		$('#aircraftType').find('option:not(:first)').remove();
		
		for(var i=0;i<splitTail.length;i++){
			if(splitTail[i]=='101' || splitTail[i]=='102' || splitTail[i]=='103'){
				
			fighterCount++;
			if(fighterCount==1){
				$('#aircraftType').append($('<option>', { 
						value: 1,
						text : 'Firefighter'
				}));	
			}
				
			
			} if(splitTail[i]=='201' || splitTail[i]=='202' || splitTail[i]=='203'){
				cargoCount++;
				if(cargoCount==1){
						$('#aircraftType').append($('<option>', { 
						value: 2,
						text : 'Cargo'
				}));
				}
			
			
			}
		
			if(splitTail[i]=='101'){
				$('#flightId').find('option:not(:first)').remove();
				$('#flightId').append($('<option>', { 
						value: 101,
						text : 'TM-101'
				}));
			}
			else if(splitTail[i]=='102'){
				//$('#flightId').find('option:not(:first)').remove();
				$('#flightId').append($('<option>', { 
						value: 102,
						text : 'TM-102'
				}));
			}
			else if(splitTail[i]=='103'){
				//$('#flightId').find('option:not(:first)').remove();
				$('#flightId').append($('<option>', { 
						value: 103,
						text : 'TM-103'
				}));
			}
		if(splitTail[i]=='201'){
				//$('#flightId').find('option:not(:first)').remove();
				$('#flightId').append($('<option>', { 
						value: 201,
						text : 'TM-201'
				}));
			}
			else if(splitTail[i]=='202'){
				//$('#flightId').find('option:not(:first)').remove();
				$('#flightId').append($('<option>', { 
						value: 202,
						text : 'TM-202'
				}));
			}
			else if(splitTail[i]=='203'){
				//$('#flightId').find('option:not(:first)').remove();
				$('#flightId').append($('<option>', { 
						value: 203,
						text : 'TM-203'
				}));
			}
			
		}
		
		
	});
	
	
	
	
	
	
	
 //cluster csv export start  
 $("#downloadLeftClusterCsv").click(function(){
	 var csvFilename=$("#flightId option:selected").text()+"_clusterData.csv";
	 exportCsv(clusterChartLeft,csvFilename,this);
	});
	
	 $("#downloadRightClusterCsv").click(function(){
	var csvFilename=$("#flightIdPoc4DivForCargoFlight option:selected").text()+"_clusterData.csv";
	 exportCsv(clusterChartRight,csvFilename,this);
	});
	
	
	
  //cluster csv export End
 
		  $(".greyBar").css("visibility", "visible");
		  $(".topDiv").css("visibility", "visible");
		  $(".homecontent").css("visibility", "hidden");
		  //$(".loadingChart5").css("visibility", "visible");
			//loadFlightId();
			$("#olsSummaryTable").hide();
			$("#regressionEqaution").hide();
			$("#flightTypeDiv").hide();
			
		   if (pocDatatable != null){
				pocDatatable.fnDestroy();
			}
		    $("#container6").hide();
			$("#airbornesegmentTableId").hide();
			$("#airtakeoff").html(0);
			$("#airtakeoffLanding").html(0);
			$("#airborneflightsegment").html(0);
		    $("#flightIdPoc3").val(0);
			
			
		
			
			
			
		
		$("#analyticId").click(function(){
		  $(".greyBar").css("visibility", "visible");
		  $(".topDiv").css("visibility", "visible");
		  $(".homecontent").css("visibility", "hidden");
		//  $(".loadingChart5").css("visibility", "visible");
			//loadFlightId();
		   if (pocDatatable != null){
				pocDatatable.fnDestroy();
			}
		    $("#container6").hide();
			$("#airbornesegmentTableId").hide();
			$("#airtakeoff").html(0);
			$("#airtakeoffLanding").html(0);
			$("#airborneflightsegment").html(0);
		    $("#flightIdPoc3").val(0);
	 })
	 
	 
	 $("#flightSegmentationTab").click(function(){
		$("#container6").html('');
		$("#segmentationId").val(0);
		$(".loadingChart5").css("visibility", "visible");
		//$(".taborder").css("visibility", "visible");
			if (pocDatatable != null){
			pocDatatable.fnDestroy();
			}
			var poc3FlightId=$("#flightId").val();
		 
			getjsonDataForPoc3(poc3FlightId);
		 
		 
	 });
	 
	 
	 
	 
	 
	 
		$("#flightId").change(function(){
			if($("#flightSegmentationTab").parent().hasClass("active")) {
				$("#container6").html('');
				$("#segmentationId").val(0);
				$(".loadingChart5").css("visibility", "visible");
				$(".taborder").css("visibility", "visible");
			if (pocDatatable != null){
			pocDatatable.fnDestroy();
			}
			flightIdval=$(this).val();
		 
			getjsonDataForPoc3(flightIdval);
		
		
      }

			
	else if($("#flightDataGraph").parent().hasClass("active") && $("#singleChartId").parent().hasClass("active")){ 
			//$("#singleChartId").click();
			$("#flightDataGraph").click();
    }
	
	else if($("#flightDataGraph").parent().hasClass("active") && $("#crossParameterId").parent().hasClass("active")){
			//$("#crossParameterId").click();     
			$("#flightDataGraph").click();			
    }
	
	else if($("#flightDataGraph").parent().hasClass("active") && $("#multiparameterId").parent().hasClass("active")){
		//$("#multiparameterId").click();
		$("#flightDataGraph").click();	
				                            
    }
	
	else if($("#flightDataGraph").parent().hasClass("active") && $("#stripChartId").parent().hasClass("active")){
				// $("#stripChartId").click();    
				$("#flightDataGraph").click();				
    }
	
    else if($("#clusterTab11").parent().hasClass("active")){
				//cluster changes : begin
				$("#clusterTab11").click();
				//cluster changes : end									   
			}
	else if($("#regressionTab11").parent().hasClass("active")){
			   //regression changes : begin
			  
			   
			   $("#regressionMultiData").change();
				$("#showRegressionData").click();	
				
				//regression changes : end				
		   }
	
		
	
}); 
	 
	 
	 
	 
	 $("#poc1IDclick").click(function(){
		 
		 var chart = $('#container1').highcharts();
	 });
	 
	 
$("#segmentationId").change(function(){
	 var segmentationId=$(this).val();
	 
	 if (pocDatatable != null){
			pocDatatable.fnDestroy();
	}
	 if(segmentationId=='0'){
		refreshPOC3Table(airborneDtoList);
	 }else if(segmentationId=='1'){
		refreshPOC3Table(groundDtoList);
	 }else{
	 }
});
	 
	 $('#container6').bind('mousemove touchmove touchstart', function (e) {
			 var chart, point, i, event;
            			 
			 for (i = 0; i < Highcharts.charts.length; i = i + 1) {
				 chart = Highcharts.charts[i];
				 if(chart=== undefined){
				 }else{
				 
				 
				 
				 event = chart.pointer.normalize(e.originalEvent); // Find coordinates within the chart
				 
				  event.chartX = (event.chartX+800) % 400;
				  
				 point = chart.series[0].searchPoint(event, true); // Get the hovered point				 
				 if (point) {
					point.highlight(e);
				 }
			 }
			 }
         });
         /**
         * Override the reset function, we don't need to hide the tooltips and crosshairs.
         */
         Highcharts.Pointer.prototype.reset = function () {
			return undefined;
         };
         
         /**
         * Highlight a point by showing tooltip, setting hover state and draw crosshair
         */
         Highcharts.Point.prototype.highlight = function (event) {
			 this.onMouseOver(); // Show the hover marker
			// this.series.chart.tooltip.refresh(this); // Show the tooltip
			 this.series.chart.xAxis[0].drawCrosshair(event, this); // Show the crosshair
         };
	 
	   poc3NewArray = [
                { "sTitle": "Flight Id", "mData": "flightId" },
                { "sTitle": "Air Speed", "mData": "airspeed" },
                { "sTitle": "Vertical Acceleration", "mData": "verticalAcceleration" },
                { "sTitle": "Roll Acceleration ", "mData": "rollAcceleration" },
				{ "sTitle": "Pressure Altitude", "mData": "pressureAltitude" },
				{ "sTitle": "Elapsed Time ", "mData": "elapsedTime" },
				{ "sTitle": "Strain Gauge 1", "mData": "strainGauge1" },
				{ "sTitle": "Strain Gauge 2", "mData": "strainGauge2" },
                { "sTitle": "Strain Gauge 3", "mData": "strainGauge3" },
				{ "sTitle": "Strain Gauge 4", "mData": "strainGauge4" },
				{ "sTitle": "Strain Gauge 5", "mData": "strainGauge5" },
				{ "sTitle": "Strain Gauge 6", "mData": "strainGauge6" },
				{ "sTitle": "Strain Gauge 7", "mData": "strainGauge7" },
				{ "sTitle": "Strain Gauge 8", "mData": "strainGauge8" },
				{ "sTitle": "Strain Gauge 9", "mData": "strainGauge9" },
						
            ]; 
	 
	 
	 
	  /**********Start of single Line Graph******************/
 
        
		$("#flightDataGraph").click(function(){
			if($("#aircraftType").val()=='0' && $("#flightId").val()=='0'){
				
			$("#aircraftType").val($("#aircraftType option:eq(1)").val());		
			$("#flightId").val($("#flightId option:eq(1)").val());			
		 var splitofTailNum= $("#tailNumId").val();
		
			var splitTail=splitofTailNum.toString().split(",");
			
			for(var i=0;i<splitTail.length;i++){
				
				if($("#aircraftType").val()=='1'){
				$("#flightId").val($("#flightId option:eq(1)").val());
					if(splitTail[i]=='101'){
				$('#flightId').find('option:not(:first)').remove();
				$('#flightId').append($('<option>', { 
						value: 101,
						text : 'TM-101'
				}));
			}
			else if(splitTail[i]=='102'){
				//$('#flightId').find('option:not(:first)').remove();
				$('#flightId').append($('<option>', { 
						value: 102,
						text : 'TM-102'
				}));
			}
			else if(splitTail[i]=='103'){
				//$('#flightId').find('option:not(:first)').remove();
				$('#flightId').append($('<option>', { 
						value: 103,
						text : 'TM-103'
				}));
			}
		
					
					
			}
				if($("#aircraftType").val()=='2'){
					
				$("#flightId").val($("#flightId option:eq(1)").val());
				if(splitTail[i]=='201'){
				$('#flightId').find('option:not(:first)').remove();
				$('#flightId').append($('<option>', { 
						value: 201,
						text : 'TM-201'
				}));
			}
			else if(splitTail[i]=='202'){
				//$('#flightId').find('option:not(:first)').remove();
				$('#flightId').append($('<option>', { 
						value: 202,
						text : 'TM-202'
				}));
			}
			else if(splitTail[i]=='203'){
				//$('#flightId').find('option:not(:first)').remove();
				$('#flightId').append($('<option>', { 
						value: 203,
						text : 'TM-203'
				}));
			}
					
				}
		 
		 
		 
		 
			}
		 
				
			/*$("#aircraftType").val($("#aircraftType option:eq(1)").val());
			//$("#flightId").val(0);
			//$("#flightId").val($("#flightId option:eq(1)").val());
			var splitofTailNum= $("#tailNumId").val();
			var splitTail=splitofTailNum.toString().split(",");
			
			for(var i=0;i<splitTail.length;i++){
				if($("#aircraftType").val()=='1'){
				$("#flightId").val($("#flightId option:eq(1)").val());
					if(splitTail[i]=='101'){
					$('#flightId').append($('<option>', { 
						value: 101,
						text : 'TM-101'
					}));
					}
				else if(splitTail[i]=='102'){
				//$('#flightId').find('option:not(:first)').remove();
				$('#flightId').append($('<option>', { 
						value: 102,
						text : 'TM-102'
				}));
			}
			else if(splitTail[i]=='103'){
				//$('#flightId').find('option:not(:first)').remove();
				$('#flightId').append($('<option>', { 
						value: 103,
						text : 'TM-103'
				}));
			}
		
					
					
			}
		
			if($("#aircraftType").val()=='2'){
					
					
				if(splitTail[i]=='201'){
				$('#flightId').find('option:not(:first)').remove();
				$('#flightId').append($('<option>', { 
						value: 201,
						text : 'TM-201'
				}));
			}
			else if(splitTail[i]=='202'){
				//$('#flightId').find('option:not(:first)').remove();
				$('#flightId').append($('<option>', { 
						value: 202,
						text : 'TM-202'
				}));
			}
			else if(splitTail[i]=='203'){
				//$('#flightId').find('option:not(:first)').remove();
				$('#flightId').append($('<option>', { 
						value: 203,
						text : 'TM-203'
				}));
			}
					
				}
		
				
			}*/
		// $("#aircraftType").change();
			}
			
			
			graphJsonDataArray=[];
			var flightIdVal=$("#flightId").val();
			$("#yaxisData").val('verticalAcceleration');			
			oTable = $('#invoicedataTable').DataTable();
			var flightArrayData = convertTableToArrayObject();
			var jsonFlightdata=JSON.stringify(flightArrayData);
			var jsonParsing = JSON.parse(jsonFlightdata);
			$.each(jsonParsing, function (idx, obj) {	
			if (obj.flightId == flightIdVal){
				graphJsonDataArray.push(obj);
			}
			
			
		});
			
			getYaxisData(graphJsonDataArray);
	
		
		if($("#crossParameterId").parent().hasClass("active")){
			$("#crossParameterId").click();
		}else if($("#multiparameterId").parent().hasClass("active")){
			$("#multiparameterId").click();
		}else if($("#stripChartId").parent().hasClass("active")){
			$("#stripChartId").click();
		}
	
		});
		
		function convertTableToArrayObject() {
			var flightData = [];
			var table = $('#invoicedataTable').DataTable();
			var data=table.rows({filter:'applied'}).data();
			for (var i = 0; i < data.length; i++) {
				flightData.push(data[i]);
			}
			return flightData;
		}
		
		
		
		
		$("#singleChartId").click(function(){
			
		if($("#flightId").val()=='0'){
		}else{
			
			
			 $("#linechartID").click();
		}
		});
		
		
		
		
		
 
     $("#yaxisData").change(function(){
		$("#container1").empty();
		$("#container1").show();
		$("#container2").hide();
		$("#singleParameterChart").show();
	
	if($("#flightId").val()==0){
		//jQuery("#errorVaildForFlightId").text('Please select FlightId.');
		//$("#radiochartId").hide();
		return false;
	}
	
	yaxisArraySingleParameter = [];
    xaxisArraySingleParameter = [];
    var textTitle;
	var yaxisText=$("#yaxisData option:selected").text();
			
			scatterArray1 = new Array(); 
			$("#radiochartId").show();
			var xaxisval;
			
			xaxisval=$("#elapseTime").val();
			
			if ($("#flightId").val() != 0 &&  xaxisval != 0 && $("#yaxisData").val() != 0) {
                    flightId = $("#flightId").val();
                    xaxis = xaxisval;
                    yaxis = $("#yaxisData").val();
                    myJsonString = JSON.stringify(graphJsonDataArray);
                    for (var i = 0; i < graphJsonDataArray.length; i++) {
						yaxisArraySingleParameter.push(parseFloat(graphJsonDataArray[i][yaxis]));
						xaxisArraySingleParameter.push(parseFloat(graphJsonDataArray[i][xaxis]));
						scatterArray1.push([parseFloat(graphJsonDataArray[i][xaxis]),parseFloat(graphJsonDataArray[i][yaxis])]);
					
                    }
					
                }
				chartData=[{ name: yaxis, type: 'line', data: yaxisArraySingleParameter}];
				textTitleSingleGraph="Elapsed Time Vs"+" "+yaxisText;
				scatterChartDraw(scatterArray1,yaxis,textTitleSingleGraph);
				
				setLineChart1(scatterArray1,yaxis,textTitleSingleGraph);
				
				
				
				
				
		});
		
	/*--------Radio Button For Scatter Chart-------------------------*/
		$("#linechartID").click(function (event) {
			var fromTextBoxsingleXaxis=$("#xaxisRangeFromSingleParameter").val();
			var toTextBoxsingleXaxis=$("#xaxisRangeToSingleParameter").val();
			var fromTextBoxsingleYaxis=$("#yaxisRangeFromSingleParameter").val();
			var toTextBoxsingleYaxis=$("#yaxisRangeToSingleParameter").val();
			var scaleXaxis=$("#xaxisScaleSingleParameter").val();
			var scaleYaxis=$("#yaxisScaleSingleParameter").val();
			
			
			
			
			$("#container2").hide();
			$("#container1").show();
			chartData=[{ name: yaxis, type: 'line', data: yaxisArray }];
			
			
			if(scaleXaxis!=="" && scaleYaxis!=""){
				setLineChart1AsperScale(scatterArray1,yaxis,textTitleSingleGraph,fromTextBoxsingleXaxis,toTextBoxsingleXaxis,fromTextBoxsingleYaxis,toTextBoxsingleYaxis,scaleXaxis,scaleYaxis);
			}else{
				setLineChart1(scatterArray1,yaxis,textTitleSingleGraph);
			}
			
		
			
		}); 
	
	
		$("#scatterchartID").click(function (event) {
		$("#container1").hide();
		$("#container2").show();
		//$(".container1").css("visibility", "hidden");
		//$(".container2").css("visibility", "visible");
			var xaxisScale;
			var yaxisscale;

			var fromTextBoxsingleXaxis=$("#xaxisRangeFromSingleParameter").val();
			var toTextBoxsingleXaxis=$("#xaxisRangeToSingleParameter").val();
			var fromTextBoxsingleYaxis=$("#yaxisRangeFromSingleParameter").val();
			var toTextBoxsingleYaxis=$("#yaxisRangeToSingleParameter").val();
			var scaleXaxis=$("#xaxisScaleSingleParameter").val();
			var scaleYaxis=$("#yaxisScaleSingleParameter").val();
			if(scaleXaxis!=="" && scaleYaxis!=""){
				
			scatterChartDrawAsperScale(scatterArray1,yaxis,textTitleSingleGraph,fromTextBoxsingleXaxis,toTextBoxsingleXaxis,fromTextBoxsingleYaxis,toTextBoxsingleYaxis,scaleXaxis,scaleYaxis);
			}else{
				scatterChartDraw(scatterArray1,yaxis,textTitleSingleGraph);
			}
		}); 	
		
 	
		$("#showChartSingleParameter").click(function(){
			
			var fromTextBoxsingleXaxis=$("#xaxisRangeFromSingleParameter").val();
			var toTextBoxsingleXaxis=$("#xaxisRangeToSingleParameter").val();
			var fromTextBoxsingleYaxis=$("#yaxisRangeFromSingleParameter").val();
			var toTextBoxsingleYaxis=$("#yaxisRangeToSingleParameter").val();
			var scaleXaxis=$("#xaxisScaleSingleParameter").val();
			var scaleYaxis=$("#yaxisScaleSingleParameter").val();
			
			$("#singleParameterChart").show();
			if($("#flightId").val()==0){
				jQuery("#errorVaildForFlightId").text('Please select FlightId.');
				$("#radiochartId").hide();
				return false;
			}
	
			yaxisArray = [];
		    xaxisArray = [];
			var textTitle;
			var yaxisText=$("#yaxisData :selected").text();
			
			scatterArray1 = new Array(); 
			//$("#radiochartId").show();
			var xaxisval;
			
			   xaxisval=$("#elapseTime").val();
			
			if ($("#flightId").val() != 0 &&  xaxisval != 0 && $("#yaxisData").val() != 0) {
                    flightId = $("#flightId").val();
                    xaxis = xaxisval;
                    yaxis = $("#yaxisData").val();
                    myJsonString = JSON.stringify(graphJsonDataArray);
                    for (var i = 0; i < graphJsonDataArray.length; i++) {
						yaxisArray.push(parseFloat(graphJsonDataArray[i][yaxis]));
						xaxisArray.push(parseFloat(graphJsonDataArray[i][xaxis]));
						scatterArray1.push([parseFloat(graphJsonDataArray[i][xaxis]),parseFloat(graphJsonDataArray[i][yaxis])]);
                    }
					
                }
				chartData=[{ name: yaxis, type: 'line', data: yaxisArray}];
				textTitleSingleGraph="Elapsed Time Vs"+" "+yaxisText;
				
				if($("input[name='chart']:checked").val()=='LineChart'){
						setLineChart1AsperScale(scatterArray1,yaxis,textTitleSingleGraph,fromTextBoxsingleXaxis,toTextBoxsingleXaxis,fromTextBoxsingleYaxis,toTextBoxsingleYaxis,scaleXaxis,scaleYaxis);
				}else{
					
						scatterChartDrawAsperScale(scatterArray1,yaxis,textTitleSingleGraph,fromTextBoxsingleXaxis,toTextBoxsingleXaxis,fromTextBoxsingleYaxis,toTextBoxsingleYaxis,scaleXaxis,scaleYaxis);
				}
			
			
		});
		$("#resetSingleParameter").click(function(){

	if($("input[name='chart']:checked").val()=='LineChart'){
		setLineChart1(scatterArray1,yaxis,textTitleSingleGraph);
	}else if($("input[name='chart']:checked").val()=='ScatterChart'){
		scatterChartDraw(scatterArray1,yaxis,textTitleSingleGraph);
	}else{
		
	}
});
 /*******End of single Line Graph******************/
	 
	 
	 /*******Start of CrossParameter Line Graph******************/ 
	 
	 $("#crossParameterId").click(function(){
	    $("#container4").empty();
	
		 if($("#flightId").val()=='0'){
		}else{
			//$(".loadingChart5").css("visibility", "visible");
			var flightIdVal=$("#flightId").val();
			$("#xaxisDatagraph2").val('verticalAcceleration');
			$("#yaxisDataGraph2").val('strainGauge1');
			getMaxElapseTimeForFlightId(flightIdVal);
		}
	 });
	 
	 $("#xaxisDatagraph2").change(function(){
			validateData();
			if($("#xaxisDatagraph2").val()=='0'){
				//$("#container4").hide();
			}else{
			jQuery("#errorVaildxaxis").text('');
			jQuery("#errorValidateparameter").text('');
			jQuery("#errorelapseTime").text('');
			flightIdOuter=$("#flightId").val();
			
			$("#yaxisDataGraph2").val(0);
			//$("#container4").hide();
			var xaxisid=$("#xaxisDatagraph2").val();
			var yaxisId=$("#yaxisDataGraph2").val();
			//getScatterChartForGraph2(flightIdOuter,minelapseTimeOuter,maxelapseTimeOuter,xaxisid,yaxisId);
			
			}
	});
	 
	 $("#yaxisDataGraph2").change(function(){
		$("#crossParameterChart").show();
		if($("#flightIdGraph2").val()=='0'){
			jQuery("#errorFlightIdForMultiparameter").text("FlightId can not be blank");
			$("#yaxisDataGraph2").val(0);
			$("#xaxisDatagraph2").val(0);
			  return false;
		}
		if($("#yaxisDataGraph2").val()=='0'){
			 $("#container4").hide();
			  return false;
		}
		if($("#xaxisDataGraph2").val()=='0'){
			 $("#container4").hide();
			  return false;
		}
		if($("#xaxisDatagraph2").val()==$("#yaxisDataGraph2").val()){
			    jQuery("#errorVaildyaxis").text('Same parameter not allowed;please select another parameter');
				 $("#container4").hide();
				 return false;
		}
			validateData();
			yaxisArrayGarph2 = [];
			xaxisArrayGraph2 = [];
			 var flightId;
			 var minelapseTime;
			 var maxelapseTime;
			 scatterArrayGraph1 = new Array(); 
			 var xaxisid;
			 var yaxisid;
			 var textTitle;
			 var xaxixgraph2Text;
			 var yaxisgraph2Text;
			 
				//var textTitle;
			 var	xaxisRangeFrom;
		     var xaxisRangeTo;
			 var yaxisRangeFrom;
			 var yaxisRangeTo;
			 var xaxisScale;
			 var yaxisscale;
			 
			flightId=$("#flightId").val();
			minelapseTime=$("#minelapseTime").val();
			maxelapseTime=$("#maxelapseTime").val();
			xaxisid=$("#xaxisDatagraph2").val();
			yaxisid=$("#yaxisDataGraph2").val();
			xaxixgraph2Text=$("#xaxisDatagraph2 :selected").text();
			yaxisgraph2Text=$("#yaxisDataGraph2 :selected").text();
			textTitle=xaxixgraph2Text+" "+"vs"+" "+yaxisgraph2Text;
			for (var i = 0; i < graphJsonDataArray.length; i++) {
					yaxisArrayGarph2.push(parseFloat(graphJsonDataArray[i][yaxisid]));
					xaxisArrayGraph2.push(parseFloat(graphJsonDataArray[i][xaxisid]));
					scatterArrayGraph1.push([parseFloat(graphJsonDataArray[i][xaxisid]),parseFloat(graphJsonDataArray[i][yaxisid])]);
            }
			$("#container4").show();
			scatterchartForGraph2(scatterArrayGraph1,xaxisid,yaxisid,textTitle);
				
			 
			
			
	 
});
	 
	 $("#showChartCrossParameter").click(function (event) {	
		if($("#flightIdGraph2").val()=='0'){
			jQuery("#errorFlightIdForMultiparameter").text("FlightId can not be blank");
			$("#yaxisDataGraph2").val(0);
			$("#xaxisDatagraph2").val(0);
			  return false;
			}
	
			if($("#yaxisDataGraph2").val()=='0'){
			 $("#container4").hide();
			  return false;
			}
			if($("#xaxisDataGraph2").val()=='0'){
			 $("#container4").hide();
			  return false;
			}
			if($("#xaxisDatagraph2").val()==$("#yaxisDataGraph2").val()){
			    jQuery("#errorVaildyaxis").text('Same parameter not allowed;please select another parameter');
				 $("#container4").hide();
				 return false;
			}
			validateData();
			
			yaxisArrayGarph2 = [];
			xaxisArrayGraph2 = [];
			 var flightId;
			 var minelapseTime;
			 var maxelapseTime;
			 scatterArrayGraph1 = new Array(); 
			 var xaxisid;
			 var yaxisid;
			 var textTitle;
			 var xaxixgraph2Text;
			 var yaxisgraph2Text;
			 var xaxisRangeFrom;
			 var xaxisRangeTo;
			 
			  var yaxisRangeFrom;
			 var yaxisRangeTo;
			 
			 var xaxisScale;
			 var yaxisscale;
			 
			 
			flightId=$("#flightId").val();
			minelapseTime=$("#minelapseTime").val();
			maxelapseTime=$("#maxelapseTime").val();
			xaxisid=$("#xaxisDatagraph2").val();
			yaxisid=$("#yaxisDataGraph2").val();
			xaxixgraph2Text=$("#xaxisDatagraph2 :selected").text();
			yaxisgraph2Text=$("#yaxisDataGraph2 :selected").text();
			
			xaxisRangeFrom=$("#xaxisRangeFrom").val();
			xaxisRangeTo=$("#xaxisRangeTo").val();
			
			yaxisRangeFrom=$("#yaxisRangeFrom").val();
			yaxisRangeTo=$("#yaxisRangeTo").val();
			
			xaxisScale=$("#xaxisScale").val();
			yaxisscale=$("#yaxisScale").val();
			
		
			textTitle=xaxixgraph2Text+" "+"vs"+" "+yaxisgraph2Text;
			
			if(minelapseTime!=minelapseTimeOuter || maxelapseTime!=maxelapseTimeOuter){
		
			$(".loadingChart5").css("visibility", "visible");
			 var predixurl="https://aircraft-svc-techmspace.run.aws-usw02-pr.ice.predix.io/view/getFlightPlottingDataElapsedTime";
			 
			 $.ajax({
				url:predixurl+"/"+flightId+"/"+minelapseTime+"/"+maxelapseTime,
               type: "get", 
              success: function(responseData) {
			 
			 $(".loadingChart5").css("visibility", "hidden");	
				for (var i = 0; i < responseData.length; i++) {
					yaxisArrayGarph2.push(parseFloat(responseData[i][yaxisid]));
					xaxisArrayGraph2.push(parseFloat(responseData[i][xaxisid]));
					scatterArrayGraph1.push([parseFloat(responseData[i][xaxisid]),parseFloat(responseData[i][yaxisid])]);
              }
				$("#container4").show();
			if($("#xaxisRangeFrom").val()!="" && $("#xaxisRangeTo").val()!=""&& $("#yaxisRangeFrom").val()!="" && $("#yaxisRangeTo").val()!="" && $("#xaxisScale").val()!="" && $("#xaxisScale").val()!=""){
					
					scatterchartForGraph2ForScalling(scatterArrayGraph1,xaxisid,yaxisid,textTitle,xaxisRangeFrom,xaxisRangeTo,yaxisRangeFrom,yaxisRangeTo,xaxisScale,yaxisscale);
				}else{
					
					scatterchartForGraph2(scatterArrayGraph1,xaxisid,yaxisid,textTitle);
					
				}
				},
               error: function ( xhr, status, error) {
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				$("#loadingChart2").hide();
				}
				});
	
			}else{
			    for (var i = 0; i < graphData2.length; i++) {
					yaxisArrayGarph2.push(parseFloat(graphData2[i][yaxisid]));
					xaxisArrayGraph2.push(parseFloat(graphData2[i][xaxisid]));
					scatterArrayGraph1.push([parseFloat(graphData2[i][xaxisid]),parseFloat(graphData2[i][yaxisid])]);
               }
				$("#container4").show();
			   scatterchartForGraph2ForScalling(scatterArrayGraph1,xaxisid,yaxisid,textTitle,xaxisRangeFrom,xaxisRangeTo,yaxisRangeFrom,yaxisRangeTo,xaxisScale,yaxisscale);
			}		
			

		});
	 $("#ResetCrossParameter").click(function(){
		$("#xaxisRangeFrom").val('');
		$("#yaxisRangeFrom").val('');
		$("#xaxisScale").val('');
		$("#yaxisScale").val('');
		$("#xaxisRangeTo").val('');
		$("#yaxisRangeTo").val('');
	
		var xaxisid=$("#xaxisDatagraph2").val();
		var yaxisid=$("#yaxisDataGraph2").val();
		var textTitle=xaxisid+" "+"vs"+" "+yaxisid;
		scatterchartForGraph2(scatterArrayGraph1,xaxisid,yaxisid,textTitle);
		//scatterchartAfterReset(scatterArrayGraph1,xaxisid,yaxisid,textTitle);
});
	  /*******End of CrossParameter Graph******************/
	 
	  /*******Start of Multiparameter Graph*********************************************/
	  
	  $("#multiparameterId").click(function(){
		  $("#container3").empty();
		  $('.SlectBox').SumoSelect();
		  $('.SlectBox5').SumoSelect();
		  $("#multisnippetdiv").hide();
		if($("#flightId").val()=='0'){
		}else{
			//$(".loadingChart5").css("visibility", "visible");
			var flightIdVal=$("#flightId").val();
			$("#langOpt").val('pressureAltitude');
			$("#langOptRight").val('verticalAcceleration');	
			 getYaxisDataForMultiple(flightIdVal);
			 
			 
			 i_multiData++;
			 
			 var leftval=$("#langOpt").val();
		     var rightval=$("#langOptRight").val();
			 
			 if(i_multiData==1){
				$("#leftParameterMultiData").append('<b style="color:#1e62d0">'+leftval+'</b>'+"<br>"); 
				$("#rightParameterMultiData").append('<b style="color:#1e62d0">'+rightval+'</b>'+"<br>");
			 }
			 
			 
			 
			
			 
			}
	
	  });
	  
   $("#showChartMultiParam").click(function (event) {
	
	///$("#leftParameterMultiData").show();
	//$("#rightParameterMultiData").show();
	//$("#snippetForMultiparameter").show();
	
	multiYaxisArray=[];
	$.each(multiYaxisArray1, function(key,val){
		multiYaxisArray.push(val);
	});
	$.each(multiYaxisArray2, function(key,val){
		multiYaxisArray.push(val);
	});
	//console.log(multiYaxisArray);
	setMultipleLineChart(chartCategories11,multiYaxisArray);
	
	var splitdata;
	var leftsideData=$("#langOpt").val();
	splitdata=leftsideData.toString().split(",");
	$("#leftParameterMultiData").html('');

	for(var i=0;i<splitdata.length;i++){
		$("#leftParameterMultiData").append('<b style="color:#1e62d0">'+capitalizeFirstLetter(splitdata[i])+'</b>'+"<br>");
	}
	
	
	var splitdata2;
	var rightsideData=$("#langOptRight").val();
	splitdata2=rightsideData.toString().split(",");
	$("#rightParameterMultiData").html('');
	for(var j=0;j<splitdata2.length;j++){
		
		
		$("#rightParameterMultiData").append('<b style="color:#1e62d0">'+capitalizeFirstLetter(splitdata2[j])+'</b>'+"<br>");
	}
	
	
	
}); 
	  
	  
	  $("#langOpt").change(function(){
		//console.log("draw left graph");
		drawmultipleGraph($(this).val());
	});	
	
	$("#langOptRight").change(function(){
		//console.log("draw right graph");
		drawmultipleGraphRight($(this).val());
	});
	  
	  
	  
	  
	  
	  
	   /*******End of Multiparameter Graph**************************************************/
	 
	 
	 
	 /*******Start of Strip Chart Graph*********************************************/
	 
	 
	 
	 $("#stripChartId").click(function(){
	
		  $('.SlectBox1').SumoSelect();
		if($("#flightId").val()=='0'){
		}else{
			var flightIdVal=$("#flightId").val();
			   $("#selectdata").change();
				$("#showChart").click();
			}
	
	  });
	  
	  
	  
	  $("#selectdata").change(function(){
	var yaxisVal;
	var flightId;
	var yaxisVal;
	var arrayyaxis;
	var yaxisArray;
	if($(this).val()!=0){
	$("#container1").hide();
	$("#container2").hide();
	$("#container3").hide();
	var multipleYaxisArrya=[];
	var multiplexaxisArray = [];
	//chartCategories12;
	multipleArrayChartData=[];
	flightId = $("#flightId1").val();
	xaxis = $("#elapseTime1").val();
	yaxisVal=$("#selectdata").val();
	chartTitlesArray=[];
		if(yaxisVal != null){
			arrayyaxis=yaxisVal.toString().split(",");
			for(var i = 0; i < arrayyaxis.length; i++){	
				 yaxisArray = [];
				for (var j = 0; j < graphJsonDataArray.length; j++) {
					 yaxisArray.push([parseFloat(graphJsonDataArray[j].elapsedTime),parseFloat(graphJsonDataArray[j][arrayyaxis[i]])]);
				}
				multipleArrayChartData.push(yaxisArray);
				chartTitlesArray.push(arrayyaxis[i]);
		
			}	
			
		}		
	// chartCategories12 = multiplexaxisArray;	
	
	chartCategories12=multipleArrayChartData;
      $("#radiochartId").hide(); 
	  
	}else{
		$("#radiochartId").hide();
	}
	});
	
	
	
	 $("#showChart").click(function (event) {
		 $("#container5").empty();
		$("#container5").show();
		$("#stripChartForMultiSnippet").show();
		$("#stripChartForMulti").show();
		$('#container5').bind('mousemove touchmove touchstart', function (e) {
			 var chart, point, i, event;
            			 
			 for (i = 0; i < Highcharts.charts.length; i = i + 1) {
				 chart = Highcharts.charts[i];
				 if(chart=== undefined){
				 }else{
				
				 event = chart.pointer.normalize(e.originalEvent); // Find coordinates within the chart
				 
				  event.chartX = (event.chartX+600) % 400;
				 point = chart.series[0].searchPoint(event, true); // Get the hovered point				 
				 if (point) {
					point.highlight(e);
				 }
			 }
			 }
         });
         /**
         * Override the reset function, we don't need to hide the tooltips and crosshairs.
         */
         Highcharts.Pointer.prototype.reset = function () {
			return undefined;
         };
         
         /**
         * Highlight a point by showing tooltip, setting hover state and draw crosshair
         */
         Highcharts.Point.prototype.highlight = function (event) {
			 this.onMouseOver(); // Show the hover marker
			 //this.series.chart.tooltip.refresh(this); // Show the tooltip
			 this.series.chart.xAxis[0].drawCrosshair(event, this); // Show the crosshair
         };
		formMultipleChart(chartCategories12,multipleArrayChartData,chartTitlesArray);
}); 
	 
	 
	 
	 /*******End of Strip Chart Graph*********************************************/
	 /*******Start of Cluster Analysis******************/
	 $("#clusterTab11").click(function(){
		$("#container7").show();
		var radioButtonid=$('input[name=chartPoc4]:checked').val(); 
		clusterFlightId= $("#flightId").val();
			if(clusterFlightId=='0'){
				alert("please select FlightId");
			}else{
				$(".loadingChart5").css("visibility", "visible");
				$("#firefighterSpanId").html($("#flightId").find('option:selected').text());
				if(radioButtonid==4){
					loadclusterDataFor4clusterFireFighter(clusterFlightId,radioButtonid);
			
					}else if(radioButtonid==5){
						loadclusterDataFor5clusterFireFighter(clusterFlightId,radioButtonid);
				
					}else if(radioButtonid==3){
						var flightTypeData=['fireFighter','cargoFlight'];
						loadClusterData(clusterFlightId,radioButtonid,flightTypeData[0]);
					}
			}

	 });

	 	$("#flightIdPoc4DivForCargoFlight").change(function(){
			jQuery("#errorVaildcluster").text('');
			
			var radioButtonid=$('input[name=chartPoc4]:checked').val();
			var flightId1=$(this).val();
			
				if(flightId1 == 0){
				   // $("#loadingChart7").hide();
				//	$("#container8").hide();
				}else{
					$(".loadingChart5").css("visibility", "visible");
				   // $("#loadingChart7").show(); 
					$("#container8").show();
				
				   if(radioButtonid==4){
						 loadclusterDataFor4cargoFighter(flightId1,radioButtonid);
					}else if(radioButtonid==5){
						loadclusterDataFor5cargoFighter(flightId1,radioButtonid);
					}else if(radioButtonid==3){
						var flightTypeData=['fireFighter','cargoFlight'];						
						loadClusterData(flightId1,radioButtonid,flightTypeData[1]);			 
				}
				   
				}
		
		});
	 

	 jQuery("input[name='chartPoc4']").click(function() {
			var radioButtonid=$('input[name=chartPoc4]:checked').val();
			var fireFighterflighId=$("#flightId option:selected").val();
		    var cargoFlighId=$("#flightIdPoc4DivForCargoFlight option:selected").val();
	
			//$("#loadingChart7").show();
			$(".loadingChart5").css("visibility", "visible");
			if(radioButtonid==4){
		     loadclusterDataFor4clusterFireFighter(fireFighterflighId,radioButtonid);
			 if(cargoFlighId != 0){
				 loadclusterDataFor4cargoFighter(cargoFlighId,radioButtonid);
			 }			 
			}else if(radioButtonid==5){
				 loadclusterDataFor5clusterFireFighter(fireFighterflighId,radioButtonid);
				 if(cargoFlighId != 0){
					loadclusterDataFor5cargoFighter(cargoFlighId,radioButtonid);
				 }			     
			}else if(radioButtonid==3){
				var flightTypeData=['fireFighter','cargoFlight'];
				loadClusterData(fireFighterflighId,radioButtonid,flightTypeData[0]);
				if(cargoFlighId != 0){
					loadClusterData(cargoFlighId,radioButtonid,flightTypeData[1]);
				}				
			}
		
				
		});	 
	 /*******End of Cluster Analysis******************/
	 
	 /*******Start of Regression Analysis******************/
	 $("#regressionTab11").click(function(){
	
        $('.SlectBox2').SumoSelect();
		
		if(jsonDatapoc5!=undefined){
		$("#olsSummaryTable").show();
		$("#poc5tableid").show();
		$("#flightTypeDiv").show();
		}else{
		$("#olsSummaryTable").hide();
		$("#poc5tableid").hide();
		$("#flightTypeDiv").hide();
		
		}
		
		
		
		   if($("#flightId").val()=='0'){
			  
		   }else{
			   if(jsonDatapoc5==undefined){
					$("#regressionMultiData").change();
					$("#showRegressionData").click();  
				}
			}
		  
	});



$("#regressionMultiData").change(function(){
$("#errorVaildForRegression").html('');
$("#FireFighterflightId").val(0);
regressionParameterArray=new Array();
  var data1;
  var data2;
  var staringaugeinput;
  var equation;
  var eq_final;
  var finalEquation;
  var splitval;
  var  parameter =$("#regressionMultiData").val();
  	var radioButtonidForeqaution=$('input[name=straingaugeval]:checked').val();
	if(radioButtonidForeqaution=='strainGauge1'){
	strainGaugeEquation='S1';
	}else if(radioButtonidForeqaution=='strainGauge2'){
	
	strainGaugeEquation='S2';
	}else if(radioButtonidForeqaution=='strainGauge3'){
	
	strainGaugeEquation='S3';
	}
	else if(radioButtonidForeqaution=='strainGauge4'){
	
	strainGaugeEquation='S4';
	}else if(radioButtonidForeqaution=='strainGauge5'){
	
	strainGaugeEquation='S5';
	}else if(radioButtonidForeqaution=='strainGauge6'){
	
	strainGaugeEquation='S6';
	}else if(radioButtonidForeqaution=='strainGauge7'){
	
	strainGaugeEquation='S7';
	}else if(radioButtonidForeqaution=='strainGauge8'){
	
	strainGaugeEquation='S8';
	}else if(radioButtonidForeqaution=='strainGauge9'){
	
	strainGaugeEquation='S9';
	}
  
 
  
  if(parameter != null){
	    splitval=parameter.toString().split(",");
	for(var i=0;i<splitval.length;i++){
						if(i==0){
								equation='a'+[i+1]+'*'+splitval[i];
								}
								if(i==1){
                                $("#firefighterEquation").text(strainGaugeEquation+'= c+'+equation+'+a'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==2){
                                $("#firefighterEquation1").text('+a'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==3){
                                $("#firefighterEquation2").text('+a'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==4){
                                $("#firefighterEquation3").text('+a'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==5){
                                $("#firefighterEquation4").text('+a'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==6){
                                $("#firefighterEquation5").text('+a'+[i+1]+'*'+splitval[i]);
                                }
								 if(i==7){
                                $("#firefighterEquation6").text('+a'+[i+1]+'*'+splitval[i]);
                                }
								 if(i==8){
                                $("#firefighterEquation7").text('+a'+[i+1]+'*'+splitval[i]);
                                }
								if(i==9){
                                $("#firefighterEquation8").text('+a'+[i+1]+'*'+splitval[i]);
                                }
								
		
		
	}
	
				for(var i=0;i<splitval.length;i++){
							if(i==0){
								equation='b'+[i+1]+'*'+splitval[i];
								}
								if(i==1){
                                $("#cargofighterEquation").text(strainGaugeEquation+'= c+'+equation+'+b'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==2){
                                $("#cargofighterEquation1").text('+b'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==3){
                                $("#cargofighterEquation2").text('+b'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==4){
                                $("#cargofighterEquation3").text('+b'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==5){
                                $("#cargofighterEquation4").text('+b'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==6){
                                $("#cargofighterEquation5").text('+b'+[i+1]+'*'+splitval[i]);
                                }
								 if(i==7){
                                $("#cargofighterEquation6").text('+b'+[i+1]+'*'+splitval[i]);
                                }
								 if(i==8){
                                $("#cargofighterEquation7").text('+b'+[i+1]+'*'+splitval[i]);
                                }
								if(i==9){
                                $("#cargofighterEquation8").text('+b'+[i+1]+'*'+splitval[i]);
                                }
		
	}
	
	for(var i=0;i<splitval.length;i++){
	regressionParameterArray.push(splitval[i])
	}
	
  }
	
	if($("#FireFighterflightId").val()!=0){	
	loadFirefighterTable(jsonDatapoc5,regressionParameterArray);
	}
	/**if($("#FireFighterflightId").val()!=0){	
	loadcargoFlightTable(jsonDatapoc5,regressionParameterArray);
	}**/

});

$("#showRegressionData").click(function(){
jQuery("#errorforNumberRecords").text('');

$("#regressionfirefighterFlight").html($("#flightId").find('option:selected').text());
var parameterRegression=$("#regressionMultiData").val();
var flightid=$("#flightId").val();
var radioButtonid=$('input[name=straingaugeval]:checked').val();
//var noofRecords=$("#numberOfRecordes").val();

if(parameterRegression==null){
jQuery("#errorVaildForRegression").text('please eneter Regression input');
$("#FireFighterflightId").val(0);
return false;
}
else{
$(".loadingChart5").css("visibility", "visible");
getRegressionDynamicAnalysis(parameterRegression,flightid,radioButtonid,regressionParameterArray);
$("#tableDivForFireFighter").show();
$("#formulaFireFighterType").show();
}

//


var cargoregflightid=$("#cargoflightId").val();

if(parameterRegression==null){
jQuery("#errorVaildForRegression").text('please eneter Regression input');
$("#cargoflightId").val(0);
return false;
}
else if(cargoregflightid != 0){
$(".loadingChart5").css("visibility", "visible");
getRegressionDynamicCargoGlightAnalysis(parameterRegression,cargoregflightid,radioButtonid,regressionParameterArray)
$("#tableDivForCargoFlight").show();
$("#formulaForCargoType").show();

}
//

});
		

$("#cargoflightId").change(function(){
jQuery("#errorforNumberRecords").text('');
var parameterRegression=$("#regressionMultiData").val();
var flightid=$(this).val();
var radioButtonid=$('input[name=straingaugeval]:checked').val();

if(parameterRegression==null){
jQuery("#errorVaildForRegression").text('please eneter Regression input');
$("#cargoflightId").val(0);
}
else{
//$("#loadingChart8").show();
$(".loadingChart5").css("visibility", "visible");
getRegressionDynamicCargoGlightAnalysis(parameterRegression,flightid,radioButtonid,regressionParameterArray)
$("#tableDivForCargoFlight").show();
$("#formulaForCargoType").show();
}
});

	jQuery("input[name='straingaugeval']").click(function() {
			var splitval;
			var parameterRegression=$("#regressionMultiData").val();
			var radioButtonid=$('input[name=straingaugeval]:checked').val();
			var fireFighterflighId=$("#flightId").val();
		    var cargoFlighId=$("#cargoflightId option:selected").val();
	var radioButtonidForeqaution=$('input[name=straingaugeval]:checked').val();
	if(radioButtonidForeqaution=='strainGauge1'){
	strainGaugeEquation='S1';
	}else if(radioButtonidForeqaution=='strainGauge2'){
	strainGaugeEquation='S2';
	}else if(radioButtonidForeqaution=='strainGauge3'){
	strainGaugeEquation='S3';
	}
	else if(radioButtonidForeqaution=='strainGauge4'){
	strainGaugeEquation='S4';
	}else if(radioButtonidForeqaution=='strainGauge5'){
	strainGaugeEquation='S5';
	}else if(radioButtonidForeqaution=='strainGauge6'){
	strainGaugeEquation='S6';
	}else if(radioButtonidForeqaution=='strainGauge7'){
	strainGaugeEquation='S7';
	}else if(radioButtonidForeqaution=='strainGauge8'){
	strainGaugeEquation='S8';
	}else if(radioButtonidForeqaution=='strainGauge9'){
	strainGaugeEquation='S9';
	}
		
		     if(parameterRegression != null){
			splitval=parameterRegression.toString().split(",");
			for(var i=0;i<splitval.length;i++){
						if(i==0){
								equation='a'+[i+1]+'*'+splitval[i];
								}
								if(i==1){
                                $("#firefighterEquation").text(strainGaugeEquation+'= c+'+equation+'+a'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==2){
                                $("#firefighterEquation1").text('+a'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==3){
                                $("#firefighterEquation2").text('+a'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==4){
                                $("#firefighterEquation3").text('+a'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==5){
                                $("#firefighterEquation4").text('+a'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==6){
                                $("#firefighterEquation5").text('+a'+[i+1]+'*'+splitval[i]);
                                }
								 if(i==7){
                                $("#firefighterEquation6").text('+a'+[i+1]+'*'+splitval[i]);
                                }
								 if(i==8){
                                $("#firefighterEquation7").text('+a'+[i+1]+'*'+splitval[i]);
                                }
								if(i==9){
                                $("#firefighterEquation8").text('+a'+[i+1]+'*'+splitval[i]);
                                }
		
	}
	
				for(var i=0;i<splitval.length;i++){
							if(i==0){
								equation='b'+[i+1]+'*'+splitval[i];
								}
								if(i==1){
                                $("#cargofighterEquation").text(strainGaugeEquation+'= c+'+equation+'+b'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==2){
                                $("#cargofighterEquation1").text('+b'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==3){
                                $("#cargofighterEquation2").text('+b'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==4){
                                $("#cargofighterEquation3").text('+b'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==5){
                                $("#cargofighterEquation4").text('+b'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==6){
                                $("#cargofighterEquation5").text('+b'+[i+1]+'*'+splitval[i]);
                                }
								 if(i==7){
                                $("#cargofighterEquation6").text('+b'+[i+1]+'*'+splitval[i]);
                                }
								 if(i==8){
                                $("#cargofighterEquation7").text('+b'+[i+1]+'*'+splitval[i]);
                                }
								if(i==9){
                                $("#cargofighterEquation8").text('+b'+[i+1]+'*'+splitval[i]);
                                }
		
	}
	}			
			if(fireFighterflighId!='0'){
				$("#loadingChart8").show();
				getRegressionDynamicAnalysis(parameterRegression,fireFighterflighId,radioButtonid,regressionParameterArray);
			}
			if(cargoFlighId!='--select---'){
				$("#loadingChart8").show();
				getRegressionDynamicCargoGlightAnalysis(parameterRegression,cargoFlighId,radioButtonid,regressionParameterArray);
			}
		});	 
	 
	 /*******End of Regression Analysis******************/
	 $("#aircraftType").change(function() {
		 $("#flightId").val(0);
		  var splitofTailNum= $("#tailNumId").val();
		
			var splitTail=splitofTailNum.toString().split(",");
			
			for(var i=0;i<splitTail.length;i++){
				
			if($("#aircraftType").val()=='1'){
				//$("#flightId").val($("#flightId option:eq(1)").val());
					if(splitTail[i]=='101'){
				$('#flightId').find('option:not(:first)').remove();
				$('#flightId').append($('<option>', { 
						value: 101,
						text : 'TM-101'
				}));
			}
			else if(splitTail[i]=='102'){
				//$('#flightId').find('option:not(:first)').remove();
				$('#flightId').append($('<option>', { 
						value: 102,
						text : 'TM-102'
				}));
			}
			else if(splitTail[i]=='103'){
				//$('#flightId').find('option:not(:first)').remove();
				$('#flightId').append($('<option>', { 
						value: 103,
						text : 'TM-103'
				}));
			}	
					
			}
				if($("#aircraftType").val()=='2'){
					
				$("#flightId").val($("#flightId option:eq(1)").val());
				if(splitTail[i]=='201'){
				$('#flightId').find('option:not(:first)').remove();
				$('#flightId').append($('<option>', { 
						value: 201,
						text : 'TM-201'
				}));
			}
			else if(splitTail[i]=='202'){
				//$('#flightId').find('option:not(:first)').remove();
				$('#flightId').append($('<option>', { 
						value: 202,
						text : 'TM-202'
				}));
			}
			else if(splitTail[i]=='203'){
				//$('#flightId').find('option:not(:first)').remove();
				$('#flightId').append($('<option>', { 
						value: 203,
						text : 'TM-203'
				}));
			}
					
				}		 
			}
	 });
	 
	 
	$( function() {
	
   $("#datepicker1" ).datepicker();
	
	});

  $('#datepicker1').datepicker({
	
   changeMonth: true,
   changeYear: true,
   dateFormat: 'yy-mm-dd',
   yearRange: "2004:2017",
   onSelect: function(dateText,inst) {	
	var searcheDateID = $("#datepicker1").val();
   searcheDateID = dateFormatt(searcheDateID);
	if($("#datepicker1").val()!="" && $("#datepicker2").val()!=""){
		var fromDate= $("#datepicker1").val();
		
		var toDate= $("#datepicker2").val();
	
		getFlightIdFromDb(fromDate,toDate);
		$(".loadingChart5").css("visibility", "visible");
		
	}
	
	
}
	});
	
	
	$('#datepicker2').datepicker({
			changeMonth: true,
			changeYear: true,
			 dateFormat: 'yy-mm-dd',
			 defaultDate: new Date(), 
			onSelect: function(dateText,inst) {	
		var searcheToDateID = $("#datepicker2").val();
	  searcheToDateID = dateFormatt(searcheToDateID);
	 if($("#datepicker1").val()!="" && $("#datepicker2").val()!=""){
		
		var fromDate= $("#datepicker1").val();
		var toDate= $("#datepicker2").val();
		
		
		getFlightIdFromDb(fromDate,toDate);
		$(".loadingChart5").css("visibility", "visible");
		
	}

	}

	});
	
	var date= new Date();
	

	//$("#datepicker2").val($.datepicker.formatDate("yy-mm-dd",date));
	
	$("#datepicker1").val('2004-01-01');	

	 
	 
	 
 })/*******End of Document Ready Function******************/
 
 
     function dateFormatt(searcheDateID) {
		//alert(searcheDateID);
   
				//var s = '2016-04-30';
			var fields = searcheDateID.split("/");
			var datenew = fields[0];			
			var mon = fields[1];
			var yr = fields[2];
			var newDate=datenew+'-'+mon+'-'+yr;
			newDate = newDate.replace(/\b0(?=\d)/g, '')
			//console.log('newDate'+newDate)
			return newDate;
}
 function getFlightIdFromDb(fromDate,todate){

$('.SlectBox4').html('');
$('.SlectBox4')[0].sumo.reload();
var fromTime="00:00:00";
var toTime="00:00:00";
	var flightIdUrl="https://aircraft-svc-techmspace.run.aws-usw02-pr.ice.predix.io/view/getFlightsInDateRange2";
	$.ajax({
			url:flightIdUrl+"/"+fromDate+"/"+fromTime+"/"+todate+"/"+toTime,
			type: "GET",
			headers : {
			'Content-Type' : 'application/json'
			},
			success: function(responseData) {
			$(".loadingChart5").css("visibility", "hidden");
			$('.SlectBox4').SumoSelect();
			
			for (var i = 0; i < responseData.length; i++) {
					
				
		$('select.SlectBox4')[0].sumo.add(JSON.stringify(responseData[i].flightId),'TM-'+JSON.stringify(responseData[i].flightId));
			
				
           }
			
   },

   error: function ( xhr, status, error) {
    console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
    }
    });
	

}
 
 
 function loadFlightId(){
	var predixurl="https://aircraft-svc-techmspace.run.aws-usw02-pr.ice.predix.io/getFlightIds";
				$.ajax({
				url:predixurl,
                type: "get", //send it through post method
                success: function(responseData) {
					flightIdFromService=responseData;
				 $(".loadingChart5").css("visibility", "hidden");
				$('#flightId').find('option:not(:first)').remove();
			for (var i = 0; i < flightIdFromService.length; i++) {
					$('#flightId').append($('<option>', { 
						value: JSON.stringify(flightIdFromService[i].flightId),
						text : 'TM-'+JSON.stringify(flightIdFromService[i].flightId)
				}));
           }
				},
                error: function ( xhr, status, error) {
				$("#loadingChart5").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});

}
 //**********Start of FlightData Graph  function ***********************////
	function getYaxisData(jsonObject){
		//$("#container1").html(' ');
		$("#container1").empty();
		yaxis=$("#yaxisData").val();
		if($("#yaxisData").val()!='0'){
		yaxisArray = [];
		xaxisArray = [];
		scatterArray1 = new Array(); 
		for (var i = 0; i < jsonObject.length; i++) {
						yaxisArray.push(parseFloat(jsonObject[i][yaxis]));
						xaxisArray.push(parseFloat(jsonObject[i].elapsedTime));
						scatterArray1.push([parseFloat(jsonObject[i].elapsedTime),parseFloat(jsonObject[i][yaxis])]);
         }
		var yaxisText=$("#yaxisData option:selected").text();
		textTitleSingleGraph="Elapsed Time Vs"+" "+yaxisText;
					//setLineChart1(scatterArray1,yaxis,textTitleSingleGraph);
		 var fromTextBoxsingleXaxis=$("#xaxisRangeFromSingleParameter").val();
						var toTextBoxsingleXaxis=$("#xaxisRangeToSingleParameter").val();
						var fromTextBoxsingleYaxis=$("#yaxisRangeFromSingleParameter").val();
						var toTextBoxsingleYaxis=$("#yaxisRangeToSingleParameter").val();
						var scaleXaxis=$("#xaxisScaleSingleParameter").val();
						var scaleYaxis=$("#yaxisScaleSingleParameter").val();
				  if($("input[name='chart']:checked").val()=='LineChart'){
					  setLineChart1(scatterArray1,yaxis,textTitleSingleGraph); 
					  /*if($("#xaxisRangeFromSingleParameter").val()=='' && $("#yaxisRangeFromSingleParameter").val()==''){
						  $("#container1").empty();
						 setLineChart1(scatterArray1,yaxis,textTitleSingleGraph); 
					  }else{
						  setLineChart1AsperScale(scatterArray1,yaxis,textTitleSingleGraph,fromTextBoxsingleXaxis,toTextBoxsingleXaxis,fromTextBoxsingleYaxis,toTextBoxsingleYaxis,scaleXaxis,scaleYaxis);
					  }*/
					
					}else{
					   scatterChartDraw(scatterArray1,yaxis,textTitleSingleGraph);
					}
			
				}
				
				
				
				//},
 
               // error: function ( xhr, status, error) {
				//console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				//$("#loadingChart").hide();
				//}
 				//});
		
	} 

function setLineChart1(scatterArray1,yaxisval,texttitle){	  
  singleparameterChart = new Highcharts.Chart({
	chart: {
	renderTo: 'container1',
	type: 'line',
	zoomType: 'xy',
	//width:700
},
    title: {
        text: texttitle
    },
	
 yAxis: {
title: {
text: yaxisval
},
 //min: ymin,
 //max: ymax,
},

  xAxis: {
title: {
enabled: true,
text: 'Elapsed Time'
},
 //min: xmin,
// max: xmax,
labels:{
			format: '{value} sec'
},
startOnTick: true,
endOnTick: true,
showLastLabel: true
},
   plotOptions: {
	
        series: {
            point: {
                events: {
                    mouseOver: function () {
                        var chart = this.series.chart;
							captureData(this.x,this.y,yaxisval);
                    }
					
					
					
					
                }
            },
            events: {
                mouseOut: function () {
                    if (this.chart.lbl) {
                        this.chart.lbl.hide();
                    }
                }
            },
			marker: {           
			enabled: false,                                    
			symbol: 'circle',
			radius: 4,
			states: {
				hover: {
					enabled: true,
					fillColor: 'black',
					lineColor: 'red',
					lineWidth: 1
				}
			}
		}
        }
    },

    tooltip: {
        enabled: false
    },
series: [
{
showInLegend: false,       
data: scatterArray1
}
]


});
chart1SingleChart = $('#container1').highcharts();
var yxisMaxval = chart1SingleChart.yAxis[0].max; 
var yxisMinval = chart1SingleChart.yAxis[0].min; 
var xxisMinval = chart1SingleChart.xAxis[0].min; 
var xaxisMaxval = chart1SingleChart.xAxis[0].max; 



$("#xaxisRangeFromSingleParameter").val(parseFloat(xxisMinval));
$("#xaxisRangeToSingleParameter").val(parseFloat(xaxisMaxval));
			
$("#yaxisRangeFromSingleParameter").val(parseFloat(yxisMinval));
$("#yaxisRangeToSingleParameter").val(parseFloat(yxisMaxval));

$("#xaxisScaleSingleParameter").val(chart1SingleChart.xAxis[0].tickInterval);
$("#yaxisScaleSingleParameter").val(chart1SingleChart.yAxis[0].tickInterval);


}

function scatterChartDraw(scatterArray1,yaxisval,texttitle){
Highcharts.chart('container2', {
	chart: {
		type: 'scatter',
		zoomType: 'xy',
		width:700
		},
    title: {
        text: texttitle
    },
	
	 yAxis: {
title: {
text: yaxisval
},
// min: ymin,
// max: ymax,
},

 xAxis: {
title: {
enabled: true,
text: 'Elapsed Time'
},
// min: xmin,
// max: xmax,
labels:{
			format: '{value} sec'
},
startOnTick: true,
endOnTick: true,
showLastLabel: true
},
    plotOptions: {
        series: {
            point: {
                events: {
                    mouseOver: function () {
                        var chart = this.series.chart;
							captureData(this.x,this.y,yaxisval);
                    }
					
					
					
					
                }
            },
            events: {
                mouseOut: function () {
                    if (this.chart.lbl) {
                        this.chart.lbl.hide();
                    }
                }
            }
        },
		scatter: {
		  marker: {           
			enabled: true,                                     
			symbol: 'circle',
			radius: 4,
			states: {
				hover: {
					enabled: true,
					symbol: 'triangle',
					fillColor: 'black',
					lineColor: 'red',
					lineWidth: 1
				}
			}
		}
	}
    },

    tooltip: {
        enabled: false
    },
	series: [
{
	   marker: {
	enabled: false,
	symbol: 'circle',
	radius: 2,
	states: {
		hover: {
			fillColor: 'black',
			lineColor: 'red',
			lineWidth: 1
		}
	}
},
showInLegend:false,
name: texttitle,
data: scatterArray1
}
]
});
var chart2 = $('#container2').highcharts();
var yxisMaxval = chart2.yAxis[0].max; 
var yxisMinval = chart2.yAxis[0].min; 
var xxisMinval = chart2.xAxis[0].min; 
var xaxisMaxval = chart2.xAxis[0].max; 
$("#xaxisRangeFromSingleParameter").val(parseFloat(xxisMinval));
$("#xaxisRangeToSingleParameter").val(parseFloat(xaxisMaxval));
			
$("#yaxisRangeFromSingleParameter").val(parseFloat(yxisMinval));
$("#yaxisRangeToSingleParameter").val(parseFloat(yxisMaxval));
}

function captureData(x,y,yaxisVal){
	$("#singleParameterElapseTimeSnippet").html("Elaspsed Time:"+'<b style="color:red">'+x+'</b>');
	$("#singleParameterOtherParameterSnippet").html(yaxisVal+":"+'<b style="color:red">'+y+'</b>');
}

function scatterChartDrawAsperScale(scatterArray1,yaxisval,texttitle,fromTextBoxsingleXaxis,toTextBoxsingleXaxis,fromTextBoxsingleYaxis,toTextBoxsingleYaxis,scaleXaxis,scaleYaxis){
		
	 if(scaleXaxis=="" && scaleYaxis==""){
		 
		 singleParameterRangeSelectionXaxis={
			min: parseFloat(fromTextBoxsingleXaxis),
            max:  parseFloat(toTextBoxsingleXaxis),
			title: {
				enabled: true,
				text: 'Elapsed Time'
				},
				labels:{
			format: '{value} sec'
				},
			startOnTick: true,
			endOnTick: true,
			showLastLabel: true
			}
			singleParameterRangeSelectionYaxis={
			min: parseFloat(fromTextBoxsingleYaxis),
            max:  parseFloat(toTextBoxsingleYaxis),
			title: {
				text: yaxisval
			}
			}
			
	 }
	 
	 
	 if(fromTextBoxsingleXaxis!=="" && toTextBoxsingleXaxis!=="" && fromTextBoxsingleYaxis!==" " && toTextBoxsingleYaxis!=="" && scaleXaxis!=="" && scaleYaxis!==""){
		 
		 	singleParameterRangeSelectionXaxis={
			min: parseFloat(fromTextBoxsingleXaxis),
            max:  parseFloat(toTextBoxsingleXaxis),
		   tickInterval:  parseFloat(scaleXaxis),
			title: {
				enabled: true,
				text: 'Elapsed Time'
				},
				labels:{
			format: '{value} sec'
				},
			startOnTick: true,
			endOnTick: true,
			showLastLabel: true
			}
			singleParameterRangeSelectionYaxis={
			min: parseFloat(fromTextBoxsingleYaxis),
            max:  parseFloat(toTextBoxsingleYaxis),
			tickInterval:  parseFloat(scaleYaxis),
			title: {
				text: yaxisval
			}
			}
		 
	 }
	 
	 
	 
	  if(fromTextBoxsingleXaxis!=="" && toTextBoxsingleXaxis!=="" && fromTextBoxsingleYaxis!==" " && toTextBoxsingleYaxis!=="" && scaleXaxis=="" && scaleYaxis!==""){
		 
		 	singleParameterRangeSelectionXaxis={
			min: parseFloat(fromTextBoxsingleXaxis),
            max:  parseFloat(toTextBoxsingleXaxis),
		  // tickInterval:  parseInt(scaleXaxis),
			title: {
				enabled: true,
				text: 'Elapsed Time'
				},
				labels:{
			format: '{value} sec'
				},
			startOnTick: true,
			endOnTick: true,
			showLastLabel: true
			}
			singleParameterRangeSelectionYaxis={
			min: parseFloat(fromTextBoxsingleYaxis),
            max:  parseFloat(toTextBoxsingleYaxis),
			tickInterval:  parseFloat(scaleYaxis),
			title: {
				text: yaxisval
			}
			} 
		  
		  
	  }
	 
	  if(fromTextBoxsingleXaxis!=="" && toTextBoxsingleXaxis!=="" && fromTextBoxsingleYaxis!==" " && toTextBoxsingleYaxis!=="" && scaleXaxis!=="" && scaleYaxis==""){
		 
		 	singleParameterRangeSelectionXaxis={
			min: parseFloat(fromTextBoxsingleXaxis),
            max:  parseFloat(toTextBoxsingleXaxis),
		   tickInterval:  parseFloat(scaleXaxis),
			title: {
				enabled: true,
				text: 'Elapsed Time'
				},
				labels:{
			format: '{value} sec'
				},
			startOnTick: true,
			endOnTick: true,
			showLastLabel: true
			}
			singleParameterRangeSelectionYaxis={
			min: parseFloat(fromTextBoxsingleYaxis),
            max:  parseFloat(toTextBoxsingleYaxis),
			//tickInterval:  parseInt(scaleYaxis),
			title: {
				text: yaxisval
			}
			} 
		  
		  
	  }
	 

	Highcharts.chart('container2', {
	chart: {
	type: 'scatter',
	zoomType: 'xy'
},
    title: {
        text: texttitle
    },
	xAxis:singleParameterRangeSelectionXaxis,
	yAxis:singleParameterRangeSelectionYaxis,
    plotOptions: {
        series: {
            point: {
                events: {
                    mouseOver: function () {
                        var chart = this.series.chart;
							captureData(this.x,this.y,yaxisval);
                    }
					
					
					
					
                }
            },
            events: {
                mouseOut: function () {
                    if (this.chart.lbl) {
                        this.chart.lbl.hide();
                    }
                }
            }
        },
		scatter: {
		  marker: {           
			enabled: true,                                     
			symbol: 'circle',
			radius: 4,
			states: {
				hover: {
					enabled: true,
					symbol: 'triangle',
					fillColor: 'black',
					lineColor: 'red',
					lineWidth: 1
				}
			}
		}
	}
    },

    tooltip: {
        enabled: false
    },
series: [
{
//name: texttitle,
showInLegend:false,
data: scatterArray1
}
]
});
	
	
	
	
}
function setLineChart1AsperScale(scatterArray1,yaxisval,texttitle,fromTextBoxsingleXaxis,toTextBoxsingleXaxis,fromTextBoxsingleYaxis,toTextBoxsingleYaxis,scaleXaxis,scaleYaxis){	
	 if(scaleXaxis=="" && scaleYaxis==""){
			singleParameterRangeSelectionXaxis={
			min: parseFloat(fromTextBoxsingleXaxis),
            max:  parseFloat(toTextBoxsingleXaxis),
			title: {
				enabled: true,
				text: 'Elapsed Time'
				},
				labels:{
			format: '{value} sec'
				},
			startOnTick: true,
			endOnTick: true,
			showLastLabel: true
			}
			singleParameterRangeSelectionYaxis={
			min: parseFloat(chart.yAxis[0].min),
            max:  parseFloat(chart.yAxis[0].max),
			title: {
				text: yaxisval
			}
			}
			
	 }
	 
	 
	 if(fromTextBoxsingleXaxis!=="" && toTextBoxsingleXaxis!=="" && fromTextBoxsingleYaxis!==" " && toTextBoxsingleYaxis!=="" && scaleXaxis!=="" && scaleYaxis!==""){
		 
		 	singleParameterRangeSelectionXaxis={
			min: parseFloat(fromTextBoxsingleXaxis),
            max:  parseFloat(toTextBoxsingleXaxis),
		   tickInterval:  parseFloat(scaleXaxis),
			title: {
				enabled: true,
				text: 'Elapsed Time'
				},
				labels:{
			format: '{value} sec'
				},
			startOnTick: true,
			endOnTick: true,
			showLastLabel: true
			}
			singleParameterRangeSelectionYaxis={
			min: parseFloat(fromTextBoxsingleYaxis),
            max:  parseFloat(toTextBoxsingleYaxis),
			tickInterval:  parseFloat(scaleYaxis),
			title: {
				text: yaxisval
			}
			}
		 
	 }
	 
	 
	 
	  if(fromTextBoxsingleXaxis!=="" && toTextBoxsingleXaxis!=="" && fromTextBoxsingleYaxis!==" " && toTextBoxsingleYaxis!=="" && scaleXaxis=="" && scaleYaxis!==""){
		 
		 	singleParameterRangeSelectionXaxis={
			min: parseFloat(fromTextBoxsingleXaxis),
            max:  parseFloat(toTextBoxsingleXaxis),
		  // tickInterval:  parseInt(scaleXaxis),
			title: {
				enabled: true,
				text: 'Elapsed Time'
				},
				labels:{
			format: '{value} sec'
				},
			startOnTick: true,
			endOnTick: true,
			showLastLabel: true
			}
			singleParameterRangeSelectionYaxis={
			min: parseFloat(fromTextBoxsingleYaxis),
            max:  parseFloat(toTextBoxsingleYaxis),
			tickInterval:  parseFloat(scaleYaxis),
			title: {
				text: yaxisval
			}
			} 
		  
		  
	  }
	 
	  if(fromTextBoxsingleXaxis!=="" && toTextBoxsingleXaxis!=="" && fromTextBoxsingleYaxis!==" " && toTextBoxsingleYaxis!=="" && scaleXaxis!=="" && scaleYaxis==""){
		 
		 	singleParameterRangeSelectionXaxis={
			min: parseFloat(fromTextBoxsingleXaxis),
            max:  parseFloat(toTextBoxsingleXaxis),
		   tickInterval:  parseFloat(scaleXaxis),
			title: {
				enabled: true,
				text: 'Elapsed Time'
				},
				labels:{
			format: '{value} sec'
				},
			startOnTick: true,
			endOnTick: true,
			showLastLabel: true
			}
			singleParameterRangeSelectionYaxis={
			min: parseFloat(fromTextBoxsingleYaxis),
            max:  parseFloat(toTextBoxsingleYaxis),
			//tickInterval:  parseInt(scaleYaxis),
			title: {
				text: yaxisval
			}
			} 
		  
		  
	  }
	 

	Highcharts.chart('container1', {
	chart: {
	type: 'line',
	zoomType: 'xy'
},
    title: {
        text: texttitle
    },
	xAxis:singleParameterRangeSelectionXaxis,
	yAxis:singleParameterRangeSelectionYaxis,
    plotOptions: {
        series: {
            point: {
                events: {
                    mouseOver: function () {
                        var chart = this.series.chart;
							captureData(this.x,this.y,yaxisval);
                    }
					
					
					
					
                }
            },
            events: {
                mouseOut: function () {
                    if (this.chart.lbl) {
                        this.chart.lbl.hide();
                    }
                }
            },
			
			marker: {           
			enabled: false,                                    
			symbol: 'circle',
			radius: 4,
			states: {
				hover: {
					enabled: true,
					fillColor: 'black',
					lineColor: 'red',
					lineWidth: 1
				}
			}
		}
        }
    },

    tooltip: {
        enabled: false
    },
series: [
{
showInLegend:false,
data: scatterArray1
}
]
});
}



function getScatterChartForGraph2ForRendering(flightIdOuter,minelapseTimeOuter,maxelapseTimeOuter,xaxisvalue,yaxisValue){
			
				graphData2=graphJsonDataArray;
				$("#yaxisDataGraph2").show();
				$("#yaxisdivGraph2").show();
				$("#yaxisdatavalForGraph2").show();
				yaxisArrayGarph2=[];
				xaxisArrayGraph2=[];
				scatterArrayGraph1=[];
				var textTitle;
			    var	xaxisRangeFrom;
				var xaxisRangeTo;
				var yaxisRangeFrom;
				var yaxisRangeTo;
				var xaxisScale;
				var yaxisscale;
				
			if($("#flightIdGraph2").val()!='0' && $("#minelapseTime").val()!='' && $("#maxelapseTime").val()!='' && $("#xaxisDatagraph2").val()!='0' && $("#yaxisDataGraph2").val()!='0'){
				 for (var i = 0; i < graphData2.length; i++) {
					yaxisArrayGarph2.push(parseFloat(graphData2[i][yaxisValue]));
					xaxisArrayGraph2.push(parseFloat(graphData2[i][xaxisvalue]));
					scatterArrayGraph1.push([parseFloat(graphData2[i][xaxisvalue]),parseFloat(graphData2[i][yaxisValue])]);
				 }
				$("#container4").show();
				textTitle=xaxisvalue+" "+"vs"+" "+yaxisValue;
				
				scatterchartForGraph2(scatterArrayGraph1,xaxisvalue,yaxisValue,textTitle);
				
				}

	}
//**********End of FlightData Graph function************************////


///****************************Start of Cross Parameter Function***************************

 function getMaxElapseTimeForFlightId(flightIdVal){
			
				$("#maxelapseTime").val($("#yadcf-filter--invoicedataTable-max_tip-1").text());
				$("#minelapseTime").val($("#yadcf-filter--invoicedataTable-min_tip-1").text());
				$("#startelapsetimediv").show();
				$("#startelapsetimetext").show();
				$("#endelapsetimediv").show();
				$("#endelapsetimetext").show();
				$("#xaxisdivGraph2").show();
				$("#xaxisdatavalGraph2").show();
				
				$("#showChartCrossParameter").show();
				$("#ResetCrossParameter").show();
				
				
				
				var flightIdOuter=$("#flightId").val();
				 minelapseTimeOuter=$("#minelapseTime").val();
				 maxelapseTimeOuter=$("#maxelapseTime").val();
				
				
				var	xaxisRangeFrom=$("#xaxisRangeFrom").val();
				var xaxisRangeTo=$("#xaxisRangeTo").val();
			
				var yaxisRangeFrom=$("#yaxisRangeFrom").val();
				var yaxisRangeTo=$("#yaxisRangeTo").val();
			
				var xaxisScale=$("#xaxisScale").val();
				var yaxisscale=$("#yaxisScale").val();
					
				
				
				if($("#flightId").val()!='0' && $("#minelapseTime").val()!='' && $("#maxelapseTime").val()!='' && $("#xaxisDatagraph2").val()!='0' && $("#yaxisDataGraph2").val()!='0'){
						var xaxisvalue=$("#xaxisDatagraph2").val();
						var yaxisValue=$("#yaxisDataGraph2").val();
					
					
						getScatterChartForGraph2ForRendering(flightIdOuter,minelapseTimeOuter,maxelapseTimeOuter,xaxisvalue,yaxisValue);
				
				}
				
				
	
		
	}

function getScatterChartForGraph2(flightId,minelapseTime,maxelapseTime,textTitle,x,y){
	
			$(".loadingChart5").css("visibility", "visible");
			var predixurl="https://aircraft-svc-techmspace.run.aws-usw02-pr.ice.predix.io/view/getFlightPlottingDataElapsedTime";
				$.ajax({
				url:predixurl+"/"+flightId+"/"+minelapseTime+"/"+maxelapseTime,
                type: "get", 
                success: function(responseData) {
				//console.log("Chart Data"+JSON.stringify(responseData)); 
				graphData2=responseData;
				
				$(".loadingChart5").css("visibility", "hidden");
				$("#yaxisDataGraph2").show();
				$("#yaxisdivGraph2").show();
				$("#yaxisdatavalForGraph2").show();
		
				},
                error: function ( xhr, status, error) {
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				$("#loadingChart2").hide();
		
				}
				});
	
	}

function validateData(){
		
		if($("#flightIdGraph2").val()=='0'){
			jQuery("#errorFlightIdForMultiparameter").text("FlightId can not be blank");
			$("#yaxisDataGraph2").val(0);
			$("#xaxisDatagraph2").val(0);
			
			
		}else if($("#minelapseTime").val()==''){
				jQuery("#errorelapseTime").text("StartElapse Time can not be blank");
				$("#yaxisDataGraph2").val(0);
				$("#xaxisDatagraph2").val(0);
			   return false;
			}else if($("#maxelapseTime").val()==''){
				jQuery("#errorelapseTime").text("End Elapse Time can not be blank");
				$("#yaxisDataGraph2").val(0);
				$("#xaxisDatagraph2").val(0);
			   return false;
			}else if(parseInt($("#minelapseTime").val())>parseInt($("#maxelapseTime").val())){
			  jQuery("#errorelapseTime").text("Start Elapsed Time can not be greater than End Elapsed Time!");
			  $("#yaxisDataGraph2").val(0);
			  $("#xaxisDatagraph2").val(0);
			   return false;
			}else if($("#xaxisDatagraph2").val()=='0'){
			 jQuery("#errorVaildxaxis").text('Please select X-axis.');
			  $("#yaxisDataGraph2").val(0);
			  $("#xaxisDatagraph2").val(0);
			  return false;
			}
			else if($("#yaxisDataGraph2").val()=='0'){
			// jQuery("#errorVaildyaxis").text('Please select Y-axis.');
			  $("#yaxisDataGraph2").val(0);
			 $("#container4").hide();
			  return false;
			}
			else if($("#xaxisDatagraph2").val()==$("#yaxisDataGraph2").val()){
			    jQuery("#errorValidateparameter").text('Same parameter not allowed;please select another parameter');
				$("#yaxisDataGraph2").val(0);
				//$("#xaxisDatagraph2").val(0);
				 return false;
			}else{
			jQuery("#errorVaildxaxis").text('');
			jQuery("#errorVaildyaxis").text('');
			jQuery("#errorValidateparameter").text('');
			jQuery("#errorelapseTime").text('');
			jQuery("#errorFlightIdForMultiparameter").text('');
			
			}	
			
		}
		
		function scatterchartForGraph2(scatterArrayGraph1,xaxisid,yaxisid,textTitle){
Highcharts.chart('container4', {
	chart: {
		type: 'scatter',
		zoomType: 'xy'
		},
    title: {
        text: textTitle
    },
	 xAxis: {
	title: {
	enabled: true,
	text: xaxisid
	},

startOnTick: true,
endOnTick: true,
showLastLabel: true
},
	yAxis: {
title: {
text: yaxisid
}
},
    plotOptions: {
        series: {
            point: {
                events: {
                    mouseOver: function () {
                        var chart = this.series.chart;
							captureDataForCrossParameter(this.x,this.y,xaxisid,yaxisid);
                    }
					
					
					
					
                }
            },
        
        }
    },

    tooltip: {
        enabled: false
    },
	series: [
		{
			showInLegend:false,
		//name: textTitle,
		data: scatterArrayGraph1
		}
]
});

var chart1 = $('#container4').highcharts();
var yxisMaxval = chart1.yAxis[0].max; 
var yxisMinval = chart1.yAxis[0].min; 
var xxisMinval = chart1.xAxis[0].min; 
var xaxisMaxval = chart1.xAxis[0].max; 
$("#xaxisRangeFrom").val(parseFloat(xxisMinval));
$("#xaxisRangeTo").val(parseFloat(xaxisMaxval));			   
$("#yaxisRangeFrom").val(parseFloat(yxisMinval));
$("#yaxisRangeTo").val(parseFloat(yxisMaxval));	
$("#xaxisScale").val(chart1.xAxis[0].tickInterval);
$("#yaxisScale").val(chart1.yAxis[0].tickInterval);
 }
 
 function captureDataForCrossParameter(xval,yval,xaxisName,yaxisName){
	$("#crossParameterSnippet").html(xaxisName+":"+" "+'<b style="color:red">'+xval+'</b>');
	$("#crossParameterOtherSnippet").html(yaxisName+":"+" "+'<b style="color:red">'+yval+'</b>');
}

 function scatterchartForGraph2ForScalling(scatterArrayGraph1,xaxisid,yaxisid,textTitle,xaxisRangeFrom,xaxisRangeTo,yaxisRangeFrom,yaxisRangeTo,xaxisScale,yaxisscale){
	 

	if($("#xaxisRangeFrom").val()!=="" && $("#xaxisRangeTo").val()!=="" && $("#yaxisRangeFrom").val()!=="" && $("#yaxisRangeTo").val()!=="" && $("#xaxisScale").val()!=="" && $("#yaxisScale").val()!==""){
					
			crossParameterRangeSelectionXaxis={
			min: parseFloat(xaxisRangeFrom),
            max:  parseFloat(xaxisRangeTo),
			tickInterval:  parseFloat(xaxisScale),
			title: {
				enabled: true,
				text: xaxisid
				},
			startOnTick: true,
			endOnTick: true,
			showLastLabel: true
			}
			crossParameterRangeSelectionYaxis={
			min: parseFloat(yaxisRangeFrom),
            max:  parseFloat(yaxisRangeTo),
			tickInterval:  parseFloat(yaxisscale),
			title: {
				text: yaxisid
			}
			
			}			
				
				
				
	} 
	
	if($("#xaxisRangeFrom").val()!=="" && $("#xaxisRangeTo").val()!=="" && $("#yaxisRangeFrom").val()!=="" && $("#yaxisRangeTo").val()!=="" && $("#xaxisScale").val()=="" && $("#yaxisScale").val()==""){
					
			crossParameterRangeSelectionXaxis={
			min: parseFloat(xaxisRangeFrom),
            max:  parseFloat(xaxisRangeTo),
			//tickInterval:  parseFloat(xaxisScale),
			title: {
				enabled: true,
				text: xaxisid
				},
			startOnTick: true,
			endOnTick: true,
			showLastLabel: true
			}
			crossParameterRangeSelectionYaxis={
			min: parseFloat(yaxisRangeFrom),
            max:  parseFloat(yaxisRangeTo),
			//tickInterval:  parseFloat(yaxisscale),
			title: {
				text: yaxisid
			}
			
			}			
				
				
				
	} 
	
	if($("#xaxisRangeFrom").val()!=="" && $("#xaxisRangeTo").val()!=="" && $("#yaxisRangeFrom").val()!=="" && $("#yaxisRangeTo").val()!=="" && $("#xaxisScale").val()!="" && $("#yaxisScale").val()==""){
					
			crossParameterRangeSelectionXaxis={
			min: parseFloat(xaxisRangeFrom),
            max:  parseFloat(xaxisRangeTo),
			tickInterval:  parseFloat(xaxisScale),
			title: {
				enabled: true,
				text: xaxisid
				},
			startOnTick: true,
			endOnTick: true,
			showLastLabel: true
			}
			crossParameterRangeSelectionYaxis={
			min: parseFloat(yaxisRangeFrom),
            max:  parseFloat(yaxisRangeTo),
			//tickInterval:  parseFloat(yaxisscale),
			title: {
				text: yaxisid
			}
			
			}			
				
				
				
	} 
	
	if($("#xaxisRangeFrom").val()!=="" && $("#xaxisRangeTo").val()!=="" && $("#yaxisRangeFrom").val()!=="" && $("#yaxisRangeTo").val()!=="" && $("#xaxisScale").val()=="" && $("#yaxisScale").val()!=""){
					
			crossParameterRangeSelectionXaxis={
			min: parseFloat(xaxisRangeFrom),
            max:  parseFloat(xaxisRangeTo),
			//tickInterval:  parseFloat(xaxisScale),
			title: {
				enabled: true,
				text: xaxisid
				},
			startOnTick: true,
			endOnTick: true,
			showLastLabel: true
			}
			crossParameterRangeSelectionYaxis={
			min: parseFloat(yaxisRangeFrom),
            max:  parseFloat(yaxisRangeTo),
			tickInterval:  parseFloat(yaxisscale),
			title: {
				text: yaxisid
			}
			
			}			
				
				
				
	} 
	
	
	
	
	 
	 Highcharts.chart('container4', {
		 
		
		 
	chart: {
		type: 'scatter',
		zoomType: 'xy'
		},
    title: {
        text: textTitle
    },
	xAxis: crossParameterRangeSelectionXaxis,
	yAxis: crossParameterRangeSelectionYaxis,
    plotOptions: {
        series: {
            point: {
                events: {
                    mouseOver: function () {
                        var chart = this.series.chart;
							captureDataForCrossParameter(this.x,this.y,xaxisid,yaxisid);
                    }
					
					
					
					
                }
            },
        
        }
    },

    tooltip: {
        enabled: false
    },
	series: [
		{
		name: textTitle,
		data: scatterArrayGraph1
		}
]
});

 }	
function scatterchartAfterReset(scatterArrayGraph1,xaxisid,yaxisid,textTitle){
Highcharts.chart('container4', {
	chart: {
		type: 'scatter',
		zoomType: 'xy'
		},
    title: {
        text: textTitle
    },
	 xAxis: {
	title: {
	enabled: true,
	text: xaxisid
	},

startOnTick: true,
endOnTick: true,
showLastLabel: true
},
	yAxis: {
title: {
text: yaxisid
}
},
    plotOptions: {
        series: {
            point: {
                events: {
                    mouseOver: function () {
                        var chart = this.series.chart;
							captureDataForCrossParameter(this.x,this.y,xaxisid,yaxisid);
                    }
					
					
					
					
                }
            },
        
        }
    },

    tooltip: {
        enabled: false
    },
	series: [
		{
			showInLegend:false,
		//name: textTitle,
		data: scatterArrayGraph1
		}
]
});


 }
///*************************End of Cross Parameter Function************************************


//**************************Function Start From MultiData*********************************
function drawmultipleGraphRight(val){
	
	var yaxisVal;
	var flightId;
	var yaxisVal;
	var arrayyaxis;
	var parameterAvg=0;
	var thersHoldVal=250;
	var averageArrayPush=[];
	var arrayData;

	if(val!=0){
		multiYaxisArray1=[];
		 multiplexaxisArray = [];
		 chartCategories11;
	
		flightId = $("#flightId1").val();
		xaxis = $("#elapseTime1").val();
		yaxisVal=$("#langOptRight").val();
		if(yaxisVal != null){
			arrayyaxis=yaxisVal.toString().split(",");
			for(var i = 0; i < arrayyaxis.length; i++){	
				var yaxisArray = [];
				for (var j = 0; j < testDataMultiple.length; j++) {	
					yaxisArray.push([parseFloat(testDataMultiple[j].elapsedTime),parseFloat(testDataMultiple[j][arrayyaxis[i]])]);				
				}
				multiYaxisArray1.push({name: arrayyaxis[i], data: yaxisArray, yAxis: 1});	
			}	
		}
		
	 chartCategories11 = multiplexaxisArray;	
	
	}else{
			$("#radiochartId").hide();
	}	
	}

function drawmultipleGraph(val){
	
	var yaxisVal;
	var flightId;
	var yaxisVal;
	var arrayyaxis;
	var parameterAvg=0;
	var thersHoldVal=250;
	var averageArrayPush=[];
	var arrayData;

	if(val!=0){
		 multiYaxisArray2=[];
		 multiplexaxisArray = [];
		 chartCategories11;
	
		flightId = $("#flightId1").val();
		xaxis = $("#elapseTime1").val();
		yaxisVal=$("#langOpt").val();
		if(yaxisVal != null){
			arrayyaxis=yaxisVal.toString().split(",");
			for(var i = 0; i < arrayyaxis.length; i++){	
				var yaxisArray = [];
				for (var j = 0; j < testDataMultiple.length; j++) {
					yaxisArray.push([parseFloat(testDataMultiple[j].elapsedTime),parseFloat(testDataMultiple[j][arrayyaxis[i]])]);				
				}
				multiYaxisArray2.push({name: arrayyaxis[i], data: yaxisArray, yAxis: 0});
				//multiYaxisArray2.push({name: arrayyaxis[i], data: yaxisArray, yAxis: 0, color: Highcharts.getOptions().colors[i+15]});				
			}	
		}		
		
	 chartCategories11 = multiplexaxisArray;	
	//setMultipleLineChart(chartCategories11,multiYaxisArray2);  
	}else{
			$("#radiochartId").hide();
	}	
	}		

function getYaxisDataForMultiple(flightIdVal){
				testDataMultiple=graphJsonDataArray;
				$("#xaxisIdMulti").show();
				$("#xaxisdatavalMulti").show();
				$("#yaxisIdMulti").show();
				$("#yaxisdatavalMulti").show();
				
				if($("#flightId1").val()!='0' && $("#langOpt").val()!=null && $("#langOptRight").val()!=null){
					
					var multiYaxisArray;
					var multiYaxisArray1;
					var multiYaxisArray2;
					var multiplexaxisArray;
					var chartCategories11;
				
					var yaxisVal;
					var flightId;
						
					var arrayyaxis;
					var parameterAvg=0;
					var thersHoldVal=250;
					var averageArrayPush=[];
					var arrayData;

	
		 multiYaxisArray2=[];
		 multiplexaxisArray = [];
		 chartCategories11;
	
		flightId = $("#flightId1").val();
	
		yaxisVal=$("#langOpt").val();
		if(yaxisVal != null){
			arrayyaxis=yaxisVal.toString().split(",");
			for(var i = 0; i < arrayyaxis.length; i++){	
				var yaxisArray = [];
				for (var j = 0; j < testDataMultiple.length; j++) {
					yaxisArray.push([parseFloat(testDataMultiple[j].elapsedTime),parseFloat(testDataMultiple[j][arrayyaxis[i]])]);				
				}
				multiYaxisArray2.push({name: arrayyaxis[i], data: yaxisArray, yAxis: 0});
							
			}	
		}		
		
		chartCategories11 = multiplexaxisArray;	

		var yaxisVal2;
	   var arrayyaxisRight;			
			yaxisVal2=$("#langOptRight").val();
			multiYaxisArray1=[];
			if(yaxisVal2 != null){
			arrayyaxisRight=yaxisVal2.toString().split(",");
			for(var i = 0; i < arrayyaxisRight.length; i++){	
				var yaxisArray = [];
				for (var j = 0; j < testDataMultiple.length; j++) {	
					yaxisArray.push([parseFloat(testDataMultiple[j].elapsedTime),parseFloat(testDataMultiple[j][arrayyaxisRight[i]])]);				
				}
				multiYaxisArray1.push({name: arrayyaxisRight[i], data: yaxisArray, yAxis: 1});	
			}	
			}		
					
					
	$("#leftParameterMultiData").show();
	$("#rightParameterMultiData").show();
	
	multiYaxisArray=[];
	$.each(multiYaxisArray1, function(key,val){
		multiYaxisArray.push(val);
	});
	$.each(multiYaxisArray2, function(key,val){
		multiYaxisArray.push(val);
	});

	setMultipleLineChart(chartCategories11,multiYaxisArray);	
					
					
					
					
					
					
					
					
					
					
					
				}
				
				
				
				
				//},
 
               // error: function ( xhr, status, error) {
				//console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				//$("#loadingChart").hide();
		
				//}
				//});
				
	}
	
function setMultipleLineChart(chartCategories11,multipleYaxisArrya){
	$("#multisnippetdiv").show();
		$("#container3").show();
		Highcharts.chart('container3', {
		chart: {
			zoomType: 'xy'
			},
			title: {
			text: 'Elapse Time Vs Multiple Parameter'
		},
   xAxis: {
		title: {
		enabled: true,
		text: 'Elapsed Time'
		},
		labels: {
		format: '{value} sec'
		}
	},
	
	yAxis: [{ // Primary yAxis
      labels: {
         format: '',
         style: {
            color: Highcharts.getOptions().colors[0]
         }
      },
      title: {
         text: 'Y-Axis(L)',
         style: {
            color: Highcharts.getOptions().colors[0]
         }
      },
	  opposite: false
   }, { // Secondary yAxis
      title: {
         text: 'Y-Axis(R)',
         style: {
            color: Highcharts.getOptions().colors[0]
         }
      },
      labels: {       
         style: {
            color: Highcharts.getOptions().colors[0]
         }
      },
		opposite: true      
   }],
   
	tooltip: {
            formatter: function() {
				
				captureMultiParameterData(this.points);
				
               // var s = [];
              //  $.each(this.points, function(i, point) {
                  //  s.push('<span style="color:#D31B22;font-weight:bold;">'+ point.series.name +' : '+
                     //   point.y +'<span>');
              //  });
                
              //  return s.join('<br>');
            },
			borderWidth: 0,
            backgroundColor: 'none',
            pointFormat: '',
            headerFormat: '',
            shadow: false,
            style: { display: 'none'},                                 
            

            shared: true
        },
   
   
   
   /*plotOptions: {
					series: {
						point: {
						events: {
                    mouseOver: function () {
                        var chart = this.series.chart;
							//captureMultiParameterData('Ananta',this.y,multipleYaxisArrya,this.x);
							captureMultiParameterData(this.points);
							
                    }
					
					
					
					
                }
            },
           
        }
    },*/
    //tooltip: {
       // shared: true
   // },
    /*legend: {
        layout: 'vertical',
        align: 'left',
        x: 80,
        verticalAlign: 'top',
        y: 55,
        floating: true
        //backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'
    },*/
    series: multipleYaxisArrya
	});
	}
	
	function captureMultiParameterData(points){
		
	$("#snippetForMultiparameter").show();
				var s = [];
                $("#snippetForMultiparameterspan").html('');
                $.each(points, function(i, point) {
				    $("#snippetForMultiparameterspan").append('<span style="color:#1e62d0;font-weight:bold;">'+point.series.name+' : '+'</span>'+'<span style="color:red;font-weight:bold;">'+point.y+'<span>'+"<br>");	


										
				
                });
                
             
	
	
	}
	
	function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

///********************************Function End From MultiData******************************

//*******************************Function Start from Strip chart*********************

	function formMultipleChart(chartCategories11,multipleYaxisArrya,chartTitlesArray){
		$("#container5").show();
			$.each(multipleYaxisArrya, function (i, dataset) { 
					var chartTitle = chartTitlesArray[i];
					$('<div class="chart" style="width:400px;float:left;">').appendTo('#container5').highcharts({
						chart: {
							marginLeft: 40, 
							spacingTop: 20,
							spacingBottom: 20,
							type: 'line',
							zoomType: 'xy',
							//height:400
						},
						title: {
							text: chartTitle,
							align: 'left',
							margin: 0,
							x: 30
						},
						credits: {
							enabled: false
						},
						legend: {
							enabled: false
						},
						xAxis: {
							crosshair: true,
							events: {
								setExtremes: syncExtremes
							},
							title: {
								enabled: true,
								text: 'Elapsed Time'
							},
							labels: {
								format: '{value} sec'
							}
						},
						yAxis: {
							title: {
								text: null
							}
						},
						tooltip: {
                        positioner: function () {
                            return {
                                x: this.chart.chartWidth - this.label.width, // right aligned
                                y: -1 // align to title
                            };
                        },
                        borderWidth: 0,
                        backgroundColor: 'none',
                        pointFormat: '{point.y}',
                        headerFormat: '',
                        shadow: false,
                        style: {
                            fontSize: '18px'
                        },
                        valueDecimals: dataset.valueDecimals
					},
						
						
					/*plotOptions: {
					series: {
						point: {
						events: {
						mouseOver: function () {
							var chart = this.series.chart;
							captureStripChartData(chartTitle,this.y,chartTitlesArray,this.x);
							
                    }
					
					
					
					
                }
            },
           
        }
    },*/

						series: [{
							data: dataset,
							name: chartTitle,
							color: Highcharts.getOptions().colors[i],
							fillOpacity: 0.3
						}]
					});
					
					
				});
							
	}

function getYaxisDataForMultiLineGraph(flightIdVal){
	
				//var predixurl="https://aircraft-svc-techmspace.run.aws-usw02-pr.ice.predix.io/view/getFlightPlottingData";
				//$.ajax({
				//url:predixurl+"/"+flightIdVal,
                //type: "get", //send it through post method
                //success: function(responseData) {
					
				testDataMultipleLineGraph=graphJsonData;
				//$(".loadingChart5").css("visibility", "hidden");
				$("#xaxisIdMultiLine").show();
				$("#yaxisIdMultiLine").show();
				$("#xaxisdatavalMultiLine").show();
				$("#yaxisdatavalMultiLine").show();
				$("#showchartIdForMultiLine").show();		
				$("#container5").hide();
				
				if($("#flightId").val()!=0 && $("#selectdata").val()!=null){
						var yaxisVal;
						var flightId;
						var yaxisVal;
						var arrayyaxis;
						var yaxisArray;
					$("#container5").empty();
					$("#container1").hide();
					$("#container2").hide();
					$("#container3").hide();
					var multipleYaxisArrya=[];
					var multiplexaxisArray = [];
					chartCategories12;
					multipleArrayChartData=[];
					flightId = $("#flightId1").val();
					xaxis = $("#elapseTime1").val();
					yaxisVal=$("#selectdata").val();
					chartTitlesArray=[];
				if(yaxisVal != null){
				arrayyaxis=yaxisVal.toString().split(",");
				for(var i = 0; i < arrayyaxis.length; i++){	
				 yaxisArray = [];
				for (var j = 0; j < testDataMultipleLineGraph.length; j++) {
					 yaxisArray.push([parseFloat(testDataMultipleLineGraph[j].elapsedTime),parseFloat(testDataMultipleLineGraph[j][arrayyaxis[i]])]);
					}
						multipleArrayChartData.push(yaxisArray);
						chartTitlesArray.push(arrayyaxis[i]);
					}	
				}		
				chartCategories12 = multiplexaxisArray;	
				
				
					$('#container5').bind('mousemove touchmove touchstart', function (e) {
						var chart, point, i, event;
            			 
			 for (i = 0; i < Highcharts.charts.length; i = i + 1) {
				 chart = Highcharts.charts[i];
				 if(chart=== undefined){
				 }else{
				
				 event = chart.pointer.normalize(e.originalEvent); // Find coordinates within the chart
				 point = chart.series[0].searchPoint(event, true); // Get the hovered point				 
				 if (point) {
					point.highlight(e);
				 }
			 }
			 }
         });
         /**
         * Override the reset function, we don't need to hide the tooltips and crosshairs.
         */
         Highcharts.Pointer.prototype.reset = function () {
			return undefined;
         };
         
         /**
         * Highlight a point by showing tooltip, setting hover state and draw crosshair
         */
         Highcharts.Point.prototype.highlight = function (event) {
			 this.onMouseOver(); // Show the hover marker
			 //this.series.chart.tooltip.refresh(this); // Show the tooltip
			 this.series.chart.xAxis[0].drawCrosshair(event, this); // Show the crosshair
         };
			formMultipleChart(chartCategories12,multipleArrayChartData,chartTitlesArray);
				
				
				
					
					
				}
				
				
				
				
			//	},
                //error: function ( xhr, status, error) {
				//console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				//$("#loadingChart4").hide();
				//}
				//});
				
	}


///******************************Function End Strip Chart*****************************




	 
//**********Start of Flight Segmentation Graph function ***********************////
function getjsonDataForPoc3(flightIdVal){
	
 	var predixurl="https://aircraft-svc-techmspace.run.aws-usw02-pr.ice.predix.io/view/getFlightSegments4";
				$.ajax({
				url:predixurl+"/"+flightIdVal,
                type: "get", 
                success: function(responseData) {
				poc3JsonData=responseData;
				$(".loadingChart5").css("visibility", "hidden");
				$("#flightSegmentationTimeDetails").css("visibility", "visible");
				$("#flightSegmentationTableDetails").css("visibility", "visible");
				$("#flightsegmentationSelectDiv").css("visibility", "visible");
				$("#flightsegmentationtakeoffLandingId").css("visibility", "visible");
				for(var i=0;i<poc3JsonData.length;i++){
					takeoffTime=parseFloat(JSON.stringify(poc3JsonData[i].startTakeoffElapsedTime)).toFixed(2);
					landingTime=parseFloat(JSON.stringify(poc3JsonData[i].startLandingElapsedTime)).toFixed(2);
					$("#airtakeoff").html(parseFloat(JSON.stringify(poc3JsonData[i].startTakeoffElapsedTime)).toFixed(2));
					$("#airtakeoffLanding").html(parseFloat(JSON.stringify(poc3JsonData[i].startLandingElapsedTime)).toFixed(2));
					$("#airborneflightsegment").html(parseFloat(JSON.stringify(poc3JsonData[i].airborneFltSegmentDuration)).toFixed(2));
					airborneDtoList = poc3JsonData[i].airborneDtoList;
					groundDtoList=poc3JsonData[i].groundDtoList;
					totalFlightDataList=poc3JsonData[i].totalFlightDataList;
				}
				
				
				$("#loadingChart6").hide();
				 refreshMFGTable(airborneDtoList);
				 drawChart(totalFlightDataList);
				},
 
                error: function ( xhr, status, error) {
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				$("#loadingChart6").hide();
				}
 				});
 
 }

 function drawChart(totalFlightDataList){
 $("#container6").show();
 pressureAltitudeArray = new Array();
 airspeedArray = new Array();
 
 multiParamsDataArrayPoc3 = new Array();         
 chartTitlesArrayPoc3 = new Array();
		
		for (var i = 0; i < totalFlightDataList.length; i++) {
			 pressureAltitudeArray.push([parseFloat(totalFlightDataList[i].elapsedTime),parseFloat(totalFlightDataList[i].pressureAltitude)]);
		 	airspeedArray.push([parseFloat(totalFlightDataList[i].elapsedTime),parseFloat(totalFlightDataList[i].airspeed)]);
	
		}
		
		multiParamsDataArrayPoc3.push(pressureAltitudeArray);
		chartTitlesArrayPoc3.push("Pressure Altitude");	
		
		multiParamsDataArrayPoc3.push(airspeedArray);
		chartTitlesArrayPoc3.push("Air Speed");	
		
		
		  $.each(multiParamsDataArrayPoc3, function (i, dataset) { 
					var chartTitle = chartTitlesArrayPoc3[i];
					$('<div class="chart" style="width:400px;float:left;">').appendTo('#container6').highcharts({
						chart: {
							//marginLeft: 40, // Keep all charts left aligned
							//spacingTop: 20,
							//spacingBottom: 20,
							//type: 'line',
							zoomType: 'xy',
							height: 300,
							//width:700
						},
						title: {
							text: chartTitle,
							align: 'left',
							margin: 0,
							x: 30
						},
						exporting: { enabled: false },
						annotationsOptions: {
							enabledButtons: false   
						},
						credits: {
							enabled: false
						},
						legend: {
							enabled: false
						},
						
						 tooltip: {
                        positioner: function () {
                            return {
                                x: this.chart.chartWidth - this.label.width, // right aligned
                                y: -1 // align to title
                            };
                        },
                        borderWidth: 0,
                        backgroundColor: 'none',
                        pointFormat: '{point.y}',
                        headerFormat: '',
                        shadow: false,
                        style: {
                            fontSize: '18px'
                        },
                        valueDecimals: dataset.valueDecimals
                    },
						xAxis: {
							crosshair: true,
							events: {
								setExtremes: syncExtremes
							},
							title: {
								enabled: true,
								text: 'Elapsed Time'
							},
							labels: {
								format: '{value} sec'
							},
							 plotLines: [{ // mark the weekend
            color: 'red',
            width: 2,
            value: takeoffTime,
            dashStyle: 'longdashdot',
			 label: {
            text: 'Take Off',
            // Content of the label.
            //align: 'mid' // Positioning of the label.
          }
             },
             { // mark the weekend
            color: 'red',
            width: 2,
            value: landingTime,
            dashStyle: 'longdashdot',
			label: {
            text: 'Landing',
            // Content of the label.
            //align: 'mid' // Positioning of the label.
          }
             }],
							
						},
						yAxis: {
							title: {
								text: null
							}
						},
						series: [{
							data: dataset,
							name: chartTitle,
							color: Highcharts.getOptions().colors[i],
							fillOpacity: 0.3
						}]
					});
				});			
				
	}
	
	function refreshMFGTable(jsonData){
    pocDatatable= $('#airbornesegment').dataTable({
			"aaData": jsonData,
                  dom: 'lBfrtip',
				  "bFilter" : false, 
				  "bPaginate": true,
				 "lengthMenu": [5,10,50,100],
				 "scrollY": 200,
				"scrollX": true,
                 buttons: ['excel' , 'print','copyHtml5'],
                  "aoColumns":poc3NewArray,
			   
			   "initComplete": function(settings){
					$('#airbornesegment thead th').each(function () {
					   var $td = $(this);
					   $td.attr('title', $td.text());
					});

					/* Apply the tooltips */
					$('#airbornesegment thead th[title]').tooltip(
					{
					   "container": 'body'
					}); 
							//var detail=data.poNumber;       
							//alert('detail'+detail);							
				} 

               }

);
	$('#airbornesegment_length').find('label').css({"margin-left": "1000px"})
}

function refreshPOC3Table(jsonData){
	pocDatatable= $('#airbornesegment').dataTable({
			"aaData": jsonData,
                  dom: 'lBfrtip',
				  "bFilter" : false, 
				  "bPaginate": true,
				  "scrollY": 200,
				"scrollX": true,
				 "lengthMenu": [5,10,50,100],
                buttons: ['excel' , 'print','copyHtml5'],
                  "aoColumns":poc3NewArray,
			   
			   "initComplete": function(settings){
					$('#airbornesegment thead th').each(function () {
					   var $td = $(this);
					   $td.attr('title', $td.text());
					});

					/* Apply the tooltips */
					$('#airbornesegment thead th[title]').tooltip(
					{
					   "container": 'body'
					}); 
							//var detail=data.poNumber;       
							//alert('detail'+detail);							
				} 

               }

);
$('#airbornesegment_length').find('label').css({"margin-left": "1000px"})
}
	function syncExtremes(e) {
			 var thisChart = this.chart;         
			 if (e.trigger !== 'syncExtremes') { // Prevent feedback loop
				 Highcharts.each(Highcharts.charts, function (chart) {
					 if (chart !== undefined && chart !== thisChart) {
						 if (chart.xAxis[0].setExtremes) { // It is null while updating
							chart.xAxis[0].setExtremes(e.min, e.max, undefined, false, { trigger: 'syncExtremes' });
						 }
					 }
				 });
			 }

     } 
//**********End of Flight Segmentation Graph function ***********************////
/*******Start of Regression Analysis******************/
 function getRegressionDynamicAnalysis(regressionInput,flightId,radiobuttonval,regressionParameterArray){
	$(".loadingChart5").css("visibility", "visible");
var predixurl="https://aircraft-svc-techmspace.run.aws-usw02-pr.ice.predix.io/getRegressionDynamicAnalysis1";

var urldtl=predixurl+"/"+flightId+"/"+radiobuttonval+"/"+regressionInput;

console.log(urldtl);
				$.ajax({
				url:urldtl,
                type: "get", //send it through post method
                success: function(responseData) {
				jsonDatapoc5=responseData;
				//$("#loadingChart8").hide();

				  if(responseData!=""){
					$(".loadingChart5").css("visibility", "hidden");
					$("#olsSummaryTable").show();
					$("#poc5tableid").show();
					$("#flightTypeDiv").show();
					loadFirefighterChartData(responseData);
					loadFirefighterTable(responseData,regressionParameterArray)				
				}else{
					//$(".loadingChart5").css("visibility", "hidden");
					//$("#olsSummaryTable").hide();
					//$("#poc5tableid").hide();
					//$("#flightTypeDiv").hide();
					//$("#container9").hide();
					
				}
				
			
				},
                error: function ( xhr, status, error) {
				$("#loadingChart7").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});

}
function loadFirefighterChartData(jsonDataPoc5){
	
	if(jsonDataPoc5 != undefined){
		var obj = jQuery.parseJSON(jsonDataPoc5);
	strainActualvalpoc5=new Array();
	strainPredictvalpoc5=new Array();
	
	 for(var i=0;i<obj.elapseTime.length;i++)
	{
		strainActualvalpoc5.push([parseFloat(obj.elapseTime[i]),parseFloat(obj.ActualValue[i])]);
		strainPredictvalpoc5.push([parseFloat(obj.elapseTime[i]),parseFloat(obj.PredictedValue[i])]);
	}
	
    drawChartForFireFighter(strainActualvalpoc5,strainPredictvalpoc5);
	}

}

function loadFirefighterTable(jsonDataPoc5,arr){

 $('#fireFighterTableIfPoc5 tr').slice(1).remove(); 
  if(jsonDataPoc5 != undefined){
	   var obj1 = jQuery.parseJSON(jsonDataPoc5);
		$("#olsSummaryDataForfirecraft").html('RSquared='+parseFloat(obj1.RSquared).toFixed(3));
		 for(var i=0;i<obj1.mapList.length;i++){
			 $("#fireFighterTableIfPoc5").append('<tr><td style="color:green">'+obj1.mapList[i].param+'</td><td>'+parseFloat(obj1.mapList[i].coEff).toFixed(3)+
			 '</td><td>'+parseFloat(obj1.mapList[i].stdErr).toFixed(3)+'</td><td>'+parseFloat(obj1.mapList[i].pVal).toFixed(4)+'</td><td>'+parseFloat(obj1.mapList[i].tVal).toFixed(3)+'</td></tr>')
		 }
  }
}

function drawChartForFireFighter(strainActualvalpoc5,strainPredictvalpoc5){
	$("#container9").show();
	Highcharts.chart('container9', {
		
		 chart: {
        zoomType: 'xy',
		//height:300,
		//width:400
    },

    title: {
        text: ''
    },
	annotationsOptions: {
            enabledButtons: false   
        },

    subtitle: {
        text: ''
    },

    yAxis: {
        title: {
            text: 'StarinGauge Value'
        }
    },
	xAxis: {
        title: {
            text: 'ElapseTime'
        }
    },
    legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle'
    },
	   tooltip: {
                borderWidth: 0,
                backgroundColor: "rgba(255,255,255,0)",
                borderRadius: 0,
                shadow: false,
                useHTML: true,
                percentageDecimals: 2,
                backgroundColor: "rgba(255,255,255,1)",
              
            },
	
    series: [
	{
        name: 'Actual',
        data: strainActualvalpoc5
    },{
        name: 'Predict',
        data: strainPredictvalpoc5,
		color: 'rgba(255,0,0,0.3)'
    
    }]

});
	
}
function getRegressionDynamicCargoGlightAnalysis(regressionInput,flightId,radiobuttonval,regressionParameterArray){
var predixurl="https://aircraft-svc-techmspace.run.aws-usw02-pr.ice.predix.io/getRegressionDynamicAnalysis1";
var urldtl=predixurl+"/"+flightId+"/"+radiobuttonval+"/"+regressionInput;
				$.ajax({
				url:urldtl,
                type: "get", //send it through post method
                success: function(responseData) {
				jsonDatapoc5=responseData;
				$(".loadingChart5").css("visibility", "hidden");
				 $("#olsSummaryTable").show();
				$("#poc5tableid").show();
				$("#flightTypeDiv").show();
				loadCargoFlightTable(responseData,regressionParameterArray)
				loadCargoChartData(responseData);
			
				},
                error: function ( xhr, status, error) {
				$("#loadingChart7").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});


}

function loadCargoFlightTable(jsonDataPoc5,arr){

 $('#cargoTableIfPoc5 tr').slice(1).remove();
 var obj1 = jQuery.parseJSON(jsonDataPoc5);

$("#olsSummaryDataForcargo").html('RSquared='+parseFloat(obj1.RSquared).toFixed(3));
 for(var i=0;i<obj1.mapList.length;i++){
 
 $("#cargoTableIfPoc5").append('<tr><td style="color:green">'+obj1.mapList[i].param+'</td><td>'+parseFloat(obj1.mapList[i].coEff).toFixed(3)+
 '</td><td>'+parseFloat(obj1.mapList[i].stdErr).toFixed(3)+'</td><td>'+parseFloat(obj1.mapList[i].pVal).toFixed(4)+'</td><td>'+parseFloat(obj1.mapList[i].tVal).toFixed(3)+'</td></tr>')
 }

}

function loadCargoChartData(jsonDatacargo){
	 var obj = jQuery.parseJSON(jsonDatacargo);
	strainActualvalpoc5=new Array();
	strainPredictvalpoc5=new Array();
	 for(var i=0;i<obj.elapseTime.length;i++)
	{
		strainActualvalpoc5.push([parseFloat(obj.elapseTime[i]),parseFloat(obj.ActualValue[i])]);
		strainPredictvalpoc5.push([parseFloat(obj.elapseTime[i]),parseFloat(obj.PredictedValue[i])]);
	}
	
     drawChartForCargo(strainActualvalpoc5,strainPredictvalpoc5);
	
	
}
function drawChartForCargo(strainActualvalpoc5,strainPredictvalpoc5){
	
	$("#container10").show();
	Highcharts.chart('container10', {
 chart: {
        //type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
	annotationsOptions: {
            enabledButtons: false   
        },

    subtitle: {
        text: ''
    },

    yAxis: {
        title: {
            text: 'StarinGauge Value'
        }
    },
	xAxis: {
        title: {
            text: 'ElapseTime'
        }
    },
    legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle'
    },
	   tooltip: {
                borderWidth: 0,
                backgroundColor: "rgba(255,255,255,0)",
                borderRadius: 0,
                shadow: false,
                useHTML: true,
                percentageDecimals: 2,
                backgroundColor: "rgba(255,255,255,1)",
              
            },
    series: [
	{
        name: 'Actual',
        data: strainActualvalpoc5
		
    },{
        name: 'Predict',
        data: strainPredictvalpoc5,
		color: 'rgba(255,0,0,0.3)'
    
    }]

});
	
}
  /*******End of Regression Analysis******************/
 
  /*******Start of Cluster Analysis******************/
  
   function clusterPlotForCargoFlight(clusterArray1,clusterArray2,clusterArray3){
 
	Highcharts.chart('container8', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
        title: {
            text: 'Vertical Acceleartion'
        }
    },
   
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
       // color: 'rgba(255,0,0,0.3)',
        //data: clusterArray1
		data: clusterArray3

    },
	{
        name: 'Cluster2',
      // color: 'rgba(0,255,0,0.3)',
        //data: clusterArray2
		data: clusterArray1

    },
	{
        name: 'Cluster3',
       // color: 'rgba(255,0,255,0.3)',
        //data: clusterArray3
		data: clusterArray2

    },
	
	
	]
});

       var chart = $('#container8').highcharts();
       cargoFlightMaxRange = chart.yAxis[0].max;
	//   alert(cargoFlightMaxRange);
clusterChartRight = $('#container8').highcharts();
 }
 function clusterPlotForCargoFlightAgain(clusterArray1,clusterArray2,clusterArray3,yasixToRangeMax){
 
	Highcharts.chart('container8', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
	    max:  yasixToRangeMax,
        title: {
            text: 'Vertical Acceleartion'
        }
    },
   
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
       // color: 'rgba(255,0,0,0.3)',
        //data: clusterArray1
		data: clusterArray3

    },
	{
        name: 'Cluster2',
      // color: 'rgba(0,255,0,0.3)',
        //data: clusterArray2
		data: clusterArray1

    },
	{
        name: 'Cluster3',
       // color: 'rgba(255,0,255,0.3)',
        //data: clusterArray3
		data: clusterArray2

    },
	
	
	]
});

       var chart = $('#container8').highcharts();
       cargoFlightMaxRange = chart.yAxis[0].max;
	//   alert(cargoFlightMaxRange);
clusterChartRight = $('#container8').highcharts();
 }
 
   function clusterPlotAgain(clusterArray1,clusterArray2,clusterArray3,yasixToRangeMax){
    Highcharts.chart('container7', {
	
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
	    max:  yasixToRangeMax,
        title: {
            text: 'Vertical Acceleartion'
        }
    },
   
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
        //color: 'rgba(223, 83, 83, .5)',
        //data: clusterArray1
		data: clusterArray3

    },
	{
        name: 'Cluster2',
       // color: 'rgba(223, 83, 83, .5)',
//data: clusterArray2
		data: clusterArray1

    },
	{
        name: 'Cluster3',
        //color: 'rgba(223, 83, 83, .5)',
        //data: clusterArray3
		data: clusterArray2

    },
	
	
	]
});

       var chart = $('#container7').highcharts();
       fireFlightMaxRange = chart.yAxis[0].max;
	//   alert(fireFlightMaxRange);
	clusterChartLeft = $('#container7').highcharts();

 }
 
  function clusterPlot4ForFireFlightAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,yasixToRangeMax){

 
	Highcharts.chart('container7', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
	     max:  yasixToRangeMax,
        title: {
            text: 'Vertical Acceleartion'
        }
    },
   
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
       // color: 'rgba(255,0,0,0.3)',
        data: clusterArray1

    },
	{
        name: 'Cluster2',
      // color: 'rgba(0,255,0,0.3)',
        data: clusterArray2

    },
	{
        name: 'Cluster3',
       // color: 'rgba(255,0,255,0.3)',
        data: clusterArray3

    },
	{
        name: 'Cluster4',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray4

    }
	
	]
});
 var chart = $('#container7').highcharts();
       fireFlightMaxRange = chart.yAxis[0].max;
	//   alert(fireFlightMaxRange);
	clusterChartLeft = $('#container7').highcharts();
 }
 
  function clusterPlot4ForCargoFlightAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,yasixToRangeMax){
 
	Highcharts.chart('container8', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
	 max:  yasixToRangeMax,
        title: {
            text: 'Vertical Acceleartion'
        }
    },
   
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
       // color: 'rgba(255,0,0,0.3)',
        data: clusterArray1

    },
	{
        name: 'Cluster2',
      // color: 'rgba(0,255,0,0.3)',
        data: clusterArray2

    },
	{
        name: 'Cluster3',
       // color: 'rgba(255,0,255,0.3)',
        data: clusterArray3

    },
	{
        name: 'Cluster4',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray4

    }
	
	]
});
var chart = $('#container8').highcharts();
       cargoFlightMaxRange = chart.yAxis[0].max;
	//   alert(cargoFlightMaxRange);
	clusterChartRight = $('#container8').highcharts();
 }
 
  function clusterPlot5ForFireFlightAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5,yasixToRangeMax){
      
	Highcharts.chart('container7', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
	 max:  yasixToRangeMax,
        title: {
            text: 'Vertical Acceleartion'
        }
    },
    
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
       // color: 'rgba(255,0,0,0.3)',
        data: clusterArray1

    },
	{
        name: 'Cluster2',
      // color: 'rgba(0,255,0,0.3)',
        data: clusterArray2

    },
	{
        name: 'Cluster3',
       // color: 'rgba(255,0,255,0.3)',
        data: clusterArray3

    },
	{
        name: 'Cluster4',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray4

    },
	{
        name: 'Cluster5',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray5

    }
	
	]
});
 var chart = $('#container7').highcharts();
       fireFlightMaxRange = chart.yAxis[0].max;
	//   alert(fireFlightMaxRange);
	clusterChartLeft = $('#container7').highcharts();
 
 }
  
   function clusterPlot5ForCargo(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5){
 	Highcharts.chart('container8', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
        title: {
            text: 'Vertical Acceleartion'
        }
    },
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
       // color: 'rgba(255,0,0,0.3)',
        data: clusterArray1

    },
	{
       name: 'Cluster2',
      // color: 'rgba(0,255,0,0.3)',
        data: clusterArray2

    },
	{
       name: 'Cluster3',
       // color: 'rgba(255,0,255,0.3)',
        data: clusterArray3

    },
	{
        name: 'Cluster4',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray4

    },
	{
        name: 'Cluster5',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray5

    }
	
	]
});

 var chart = $('#container8').highcharts();
       cargoFlightMaxRange = chart.yAxis[0].max;
	 //  alert(cargoFlightMaxRange);
	 clusterChartRight = $('#container8').highcharts();
 
 }
 function clusterPlot5ForCargoAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5,yasixToRangeMax){
 	Highcharts.chart('container8', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
	max:  yasixToRangeMax,
        title: {
            text: 'Vertical Acceleartion'
        }
    },
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
       // color: 'rgba(255,0,0,0.3)',
        data: clusterArray1

    },
	{
       name: 'Cluster2',
      // color: 'rgba(0,255,0,0.3)',
        data: clusterArray2

    },
	{
       name: 'Cluster3',
       // color: 'rgba(255,0,255,0.3)',
        data: clusterArray3

    },
	{
        name: 'Cluster4',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray4

    },
	{
        name: 'Cluster5',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray5

    }
	
	]
});
 var chart = $('#container8').highcharts();
       cargoFlightMaxRange = chart.yAxis[0].max;
	//   alert(cargoFlightMaxRange);
 clusterChartRight = $('#container8').highcharts();
 }
  
   function drawloadFor5clustercargo(responseData){
  
		clusterArray1=new Array();
		clusterArray2=new Array();
		clusterArray3=new Array();
		clusterArray4=new Array();
		clusterArray5=new Array();
		var obj = jQuery.parseJSON(responseData);
		airspeedArray=new Array();
		verticalAccelartion=new Array();
		
		for(var i=0;i<obj.airspeed.length;i++){
		   
		   if(obj["cluster number"][i]=='1'){
		   clusterArray1.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='2'){
		   clusterArray2.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='0'){
		   clusterArray3.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='3'){
		   clusterArray4.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='4'){
		   clusterArray5.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		}

      	//clusterPlot5ForCargo(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5);
		var flightId = $("#flightId").val();
	    //alert(flightId);
	    var cargoFlightId = $("#flightIdPoc4DivForCargoFlight").val();
		
	
	
	/*if(flightType=='fireFighter'){
	  fireFlightMaxRange = parseFloat(obj.verticalAcceleration.max());
	  clusterPlot(clusterArray1,clusterArray2,clusterArray3,fireFlightMaxRange);
	}*/
	//cargoFlightMaxRange = parseFloat(obj.verticalAcceleration.max());
	if(cargoFlightId!=0 && flightId==0){
	  
	  clusterPlot5ForCargo(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5);
	}
	
	if(flightId!=0 && cargoFlightId!= 0){
	     //alert(fireFlightMaxRange + " @@@@@  " + cargoFlightMaxRange);
		 if(cargoFlightMaxRange == ''){
		    clusterPlot5ForCargo(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5);
		 }
	    if(fireFlightMaxRange > cargoFlightMaxRange){
	       yasixToRangeMax = fireFlightMaxRange;
		   clusterPlot5ForCargoAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5,yasixToRangeMax);
		 //  loadClusterData(flightId,3,'fireFighter');
	    }else{
	       yasixToRangeMax = cargoFlightMaxRange;
		   clusterPlot5ForCargoAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5,yasixToRangeMax);
		   loadclusterDataFor5clusterFireFighter(flightId,5);
	    }

	}
  
  
  }
  
  
  
     function clusterPlot5ForFireFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5){
      
	Highcharts.chart('container7', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
        title: {
            text: 'Vertical Acceleartion'
        }
    },
    
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
       // color: 'rgba(255,0,0,0.3)',
        data: clusterArray1

    },
	{
        name: 'Cluster2',
      // color: 'rgba(0,255,0,0.3)',
        data: clusterArray2

    },
	{
        name: 'Cluster3',
       // color: 'rgba(255,0,255,0.3)',
        data: clusterArray3

    },
	{
        name: 'Cluster4',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray4

    },
	{
        name: 'Cluster5',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray5

    }
	
	]
});
 var chart = $('#container7').highcharts();
       fireFlightMaxRange = chart.yAxis[0].max;
	//   alert(fireFlightMaxRange);
 clusterChartLeft = $('#container7').highcharts();
 }
  
   function drawloadFor5clusterFireFighter(responseData){
		clusterArray1=new Array();
		clusterArray2=new Array();
		clusterArray3=new Array();
		clusterArray4=new Array();
		clusterArray5=new Array();
		var obj = jQuery.parseJSON(responseData);
		airspeedArray=new Array();
		verticalAccelartion=new Array();
		
		for(var i=0;i<obj.airspeed.length;i++){
		   
		   if(obj["cluster number"][i]=='1'){
		   clusterArray1.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='2'){
		   clusterArray2.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='0'){
		   clusterArray3.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='3'){
		   clusterArray4.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='4'){
		   clusterArray5.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		}

      
		
		var flightId = $("#flightId").val();
	    var cargoFlightId = $("#flightIdPoc4DivForCargoFlight").val();
	   

	if(flightId!=0 && cargoFlightId==0){
	  
	  clusterPlot5ForFireFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5);
	}
	/*if(flightType=='cargoFlight'){
	  cargoFlightMaxRange = parseFloat(obj.verticalAcceleration.max());
	  clusterPlotForCargoFlight(clusterArray1,clusterArray2,clusterArray3,cargoFlightMaxRange);
	}*/
	
    
	if(flightId!=0 && cargoFlightId!=0){
	 //    alert(fireFlightMaxRange + " @@@@@  " + cargoFlightMaxRange);
		 if(fireFlightMaxRange == ''){
              clusterPlot5ForFireFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5);
		 }
	    if(fireFlightMaxRange > cargoFlightMaxRange){
	       yasixToRangeMax = fireFlightMaxRange;
		   clusterPlot5ForFireFlightAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5,yasixToRangeMax);
		   loadclusterDataFor5cargoFighter(cargoFlightId,5);
	    }else{
	       yasixToRangeMax = cargoFlightMaxRange;
		   clusterPlot5ForFireFlightAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5,yasixToRangeMax);
		  // loadClusterData(cargoFlightId,3,'cargoFlight');
	    }
	}
  }
  
   function clusterPlot4ForFireFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4){
	Highcharts.chart('container7', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
        title: {
            text: 'Vertical Acceleartion'
        }
    },
   
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
            
            }
        }
    },
    series: [{
        name: 'Cluster1',
       // color: 'rgba(255,0,0,0.3)',
        data: clusterArray1

    },
	{
        name: 'Cluster2',
      // color: 'rgba(0,255,0,0.3)',
        data: clusterArray2

    },
	{
        name: 'Cluster3',
       // color: 'rgba(255,0,255,0.3)',
        data: clusterArray3

    },
	{
        name: 'Cluster4',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray4

    }
	
	]
});
 var chart = $('#container7').highcharts();
       fireFlightMaxRange = chart.yAxis[0].max;
	//   alert(fireFlightMaxRange);
	clusterChartLeft = $('#container7').highcharts();
 }
  
   function drawloadFor4clusterFireFighter(responseData){

		clusterArray1=new Array();
		clusterArray2=new Array();
		clusterArray3=new Array();
		clusterArray4=new Array();
		var obj = jQuery.parseJSON(responseData);
		airspeedArray=new Array();
		verticalAccelartion=new Array();
		
		for(var i=0;i<obj.airspeed.length;i++){
		   
		   if(obj["cluster number"][i]=='1'){
		   clusterArray1.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='2'){
		   clusterArray2.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='0'){
		   clusterArray3.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='3'){
		   clusterArray4.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		}

      
		
	var flightId = $("#flightId").val();
	var cargoFlightId = $("#flightIdPoc4DivForCargoFlight").val();

	if(flightId!=0 && cargoFlightId==0){
	  clusterPlot4ForFireFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4);
	}
	
    
	if(flightId!=0 && cargoFlightId!=0){
		 if(fireFlightMaxRange == ''){
              clusterPlot4ForFireFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4);
		 }
	    if(fireFlightMaxRange > cargoFlightMaxRange){
	       yasixToRangeMax = fireFlightMaxRange;
		   clusterPlot4ForFireFlightAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,yasixToRangeMax);
		   loadclusterDataFor4cargoFighter(cargoFlightId,4);
	    }else{
	       yasixToRangeMax = cargoFlightMaxRange;
		   clusterPlot4ForFireFlightAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,yasixToRangeMax);
		 
	    }

	}
 
}
  
     function drawloadFor4clustercargo(responseData){
 	clusterArray1=new Array();
		clusterArray2=new Array();
		clusterArray3=new Array();
		clusterArray4=new Array();
		var obj = jQuery.parseJSON(responseData);
		airspeedArray=new Array();
		verticalAccelartion=new Array();
		
		for(var i=0;i<obj.airspeed.length;i++){
		   
		   if(obj["cluster number"][i]=='1'){
		   clusterArray1.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='2'){
		   clusterArray2.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='0'){
		   clusterArray3.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='3'){
		   clusterArray4.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		}

//clusterPlot4ForCargoFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4);
	//var flightId = document.getElementById('flightIdPoc4').value;
	
	//var cargoFlightId = document.getElementById('flightIdPoc4DivForCargoFlight').value;
	
	
	var flightId = $("#flightId").val();
	var cargoFlightId = $("#flightIdPoc4DivForCargoFlight").val();
	

	if(cargoFlightId!=0 && flightId==0){
	  
	  clusterPlot4ForCargoFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4);
	}
	
	if(flightId!=0 && cargoFlightId!= 0){
	//     alert(fireFlightMaxRange + " @@@@@  " + cargoFlightMaxRange);
		 if(cargoFlightMaxRange == ''){
		    clusterPlot4ForCargoFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4);
		 }
	    if(fireFlightMaxRange > cargoFlightMaxRange){
	       yasixToRangeMax = fireFlightMaxRange;
		   clusterPlot4ForCargoFlightAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,yasixToRangeMax);
		 //  loadClusterData(flightId,3,'fireFighter');
	    }else{
	       yasixToRangeMax = cargoFlightMaxRange;
		   clusterPlot4ForCargoFlightAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,yasixToRangeMax);
		   loadclusterDataFor4clusterFireFighter(flightId,4);
	    }

	}
 
 }
  
   function loadclusterDataFor5cargoFighter(flightId,radioId){
 	 var predixurl="https://aircraft-svc-techmspace.run.aws-usw02-pr.ice.predix.io/getClusterAnalytics1";
				$.ajax({
				url:predixurl+"/"+flightId+"/"+radioId,
                type: "get", //send it through post method
                success: function(responseData) {
				clusterData=responseData;
				$(".loadingChart5").css("visibility", "hidden");
				drawloadFor5clustercargo(responseData);
				},
                error: function ( xhr, status, error) {
				$("#loadingChart7").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});
 }
  
   function loadclusterDataFor4cargoFighter(flightId,radioId){
   var predixurl="https://aircraft-svc-techmspace.run.aws-usw02-pr.ice.predix.io/getClusterAnalytics1";
				$.ajax({
				url:predixurl+"/"+flightId+"/"+radioId,
                type: "get", //send it through post method
                success: function(responseData) {
				
				//$("#loadingChart7").hide();
				$(".loadingChart5").css("visibility", "hidden");
				drawloadFor4clustercargo(responseData);
				},
                error: function ( xhr, status, error) {
				$("#loadingChart7").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});
  
  
  }
  
   function loadClusterData(flightId,radioId,flightType){

 	 var predixurl="https://aircraft-svc-techmspace.run.aws-usw02-pr.ice.predix.io/getClusterAnalytics1";
				$.ajax({
				url:predixurl+"/"+flightId+"/"+radioId,
                type: "get", //send it through post method
                success: function(responseData) {
				
				clusterData=responseData;
				$(".loadingChart5").css("visibility", "hidden");
				//drawclusterChart(flightType);
				if(flightType=='fireFighter'){
	               drawclusterChart(flightType);
	            }
	            if(flightType=='cargoFlight'){
				  drawclusterChartForCargoFlight(flightType);
				}
			
				},
                error: function ( xhr, status, error) {
				$("#loadingChart7").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});
 }
 
 function drawclusterChart(flightType){
		clusterArray1=new Array();
		clusterArray2=new Array();
		clusterArray3=new Array();
		var obj = jQuery.parseJSON(clusterData);
		airspeedArray=new Array();
		verticalAccelartion=new Array();
		
		for(var i=0;i<obj.airspeed.length;i++){
		   
		   if(obj["cluster number"][i]=='1'){
		   clusterArray1.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='2'){
		   clusterArray2.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='0'){
		   clusterArray3.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		}
	
	
	var flightId = $("#flightId").val();

	var cargoFlightId = $("#flightIdPoc4DivForCargoFlight").val();
	
	

   if(flightType=='fireFighter' && cargoFlightId==0){
	  
	  clusterPlot(clusterArray1,clusterArray2,clusterArray3);
	}
	
    
  	if(flightId!=0 && cargoFlightId!=0){

		 if(fireFlightMaxRange == ''){
		    clusterPlot(clusterArray1,clusterArray2,clusterArray3);
		 }
	    if(fireFlightMaxRange > cargoFlightMaxRange){
	       yasixToRangeMax = fireFlightMaxRange;
		   clusterPlotAgain(clusterArray1,clusterArray2,clusterArray3,yasixToRangeMax);
		   loadClusterData(cargoFlightId,3,'cargoFlight');
	    }else{
	       yasixToRangeMax = cargoFlightMaxRange;
		   clusterPlotAgain(clusterArray1,clusterArray2,clusterArray3,yasixToRangeMax);
		  
	    }	   
	}
 }
 
  function drawclusterChartForCargoFlight(flightType){
		clusterArray1=new Array();
		clusterArray2=new Array();
		clusterArray3=new Array();
		var obj = jQuery.parseJSON(clusterData);
		airspeedArray=new Array();
		verticalAccelartion=new Array();
		
		for(var i=0;i<obj.airspeed.length;i++){
		   
		   if(obj["cluster number"][i]=='1'){
		   clusterArray1.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='2'){
		   clusterArray2.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='0'){
		   clusterArray3.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		}

	
	var flightId = $("#flightId").val();

	var cargoFlightId = $("#flightIdPoc4DivForCargoFlight").val();

	if(flightType=='cargoFlight' && flightId==0){
	  
	  clusterPlotForCargoFlight(clusterArray1,clusterArray2,clusterArray3);
	}
	
	if(flightId!=0 && cargoFlightId!= 0){
	
		 if(cargoFlightMaxRange == ''){
		    clusterPlotForCargoFlight(clusterArray1,clusterArray2,clusterArray3);
		 }
	    if(fireFlightMaxRange > cargoFlightMaxRange){
	       yasixToRangeMax = fireFlightMaxRange;
		   clusterPlotForCargoFlightAgain(clusterArray1,clusterArray2,clusterArray3,yasixToRangeMax);
		
	    }else{
	       yasixToRangeMax = cargoFlightMaxRange;
		   clusterPlotForCargoFlightAgain(clusterArray1,clusterArray2,clusterArray3,yasixToRangeMax);
		   loadClusterData(flightId,3,'fireFighter');
	    }
	}
 }
 
   function clusterPlot(clusterArray1,clusterArray2,clusterArray3){
    Highcharts.chart('container7', {
	
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
        title: {
            text: 'Vertical Acceleartion'
        }
    },
   
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
              
            }
        }
    },
    series: [{
        name: 'Cluster1',
      
		data: clusterArray3

    },
	{
        name: 'Cluster2',
      
		data: clusterArray1

    },
	{
        name: 'Cluster3',
      
		data: clusterArray2

    },
	
	
	]
});

       var chart = $('#container7').highcharts();
       fireFlightMaxRange = chart.yAxis[0].max;
	   clusterChartLeft = $('#container7').highcharts();


 }
 
 function loadclusterDataFor4clusterFireFighter(flightId,radioId){
		var predixurl="https://aircraft-svc-techmspace.run.aws-usw02-pr.ice.predix.io/getClusterAnalytics1";
				$.ajax({
				url:predixurl+"/"+flightId+"/"+radioId,
                type: "get", //send it through post method
                success: function(responseData) {
				
				clusterData=responseData;
				//$("#loadingChart7").hide();
				$(".loadingChart5").css("visibility", "hidden");
				drawloadFor4clusterFireFighter(responseData);
				},
                error: function ( xhr, status, error) {
				$("#loadingChart7").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});
 }
 
   function loadclusterDataFor5clusterFireFighter(flightId,radioId){
 	 var predixurl="https://aircraft-svc-techmspace.run.aws-usw02-pr.ice.predix.io/getClusterAnalytics1";
				$.ajax({
				url:predixurl+"/"+flightId+"/"+radioId,
                type: "get", //send it through post method
                success: function(responseData) {
				
				clusterData=responseData;
				//$("#loadingChart7").hide();
				$(".loadingChart5").css("visibility", "hidden");
				drawloadFor5clusterFireFighter(responseData);
				},
                error: function ( xhr, status, error) {
				$("#loadingChart7").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});
 }
  
  /*******End of Cluster Analysis******************/
  
  //********Common function For  Retrieve Data ******////
  function getJsonDataForAllFlight(flightIdVal){
				var predixurl="https://aircraft-svc-techmspace.run.aws-usw02-pr.ice.predix.io/view/getFlightPlottingData";
				$.ajax({
				url:predixurl+"/"+flightIdVal,
                type: "get", 
                success: function(responseData) {
				graphJsonData=responseData;
				$(".loadingChart5").css("visibility", "hidden");
				
				if($("#flightDataGraph").parent().hasClass("active") && $("#singleChartId").parent().hasClass("active")){ 
					$("#flightDataGraph").click(); 
				}
				else if($("#flightDataGraph").parent().hasClass("active") && $("#crossParameterId").parent().hasClass("active")){
					 $("#container4").empty();
					$("#crossParameterId").click();                                   
				}
				else if($("#flightDataGraph").parent().hasClass("active") && $("#multiparameterId").parent().hasClass("active")){
					$("#multiparameterId").click();                       
				}else if($("#flightDataGraph").parent().hasClass("active") && $("#stripChartId").parent().hasClass("active")){
					$("#stripChartId").click();                  
				}
				
				},
                error: function ( xhr, status, error) {
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " Error: "+error );
				$(".loadingChart5").css("visibility", "hidden");
				}
 				});
		
	} 
  /******End of common function ***************************////
  function exportCsv(chartType,csvfileName,thisobj){
	 
	 var csvData = "Cluster,X-axis,Y-axis\n";
		 $.each(chartType.series, function(i,s){			//works
				$.each(s.points, function(j,p){
					csvData += s.name + "," + p.x + "," + p.y + "\n";
				});
			});
			
		 $(thisobj).attr('href', 'data:text/csv;charset=utf-8,'+escape(csvData)); 
		 $(thisobj).attr('download', csvfileName);
 }
  


function captureStripChartData(title,yval,chartTitlesArray,xval){

	//if(yval!=""){
	$("#"+title+"").html('<b style="color:red">'+yval+'</b>');
	//}
	$("#stripChartForMultiSnippet").html('');
	
	$("#stripChartForMultiSnippet").append("Elapsed Time:"+'<b style="color:red">'+xval+'</b>'+"<br>");
	$("#stripChartForMulti").css('border-style', 'solid');
	$.each(chartTitlesArray, function (i, dataset) { 
	
	var chartTitle = chartTitlesArray[i];
	alert(chartTitle +":" +$("#"+chartTitle+"").text());
	
	$("#stripChartForMultiSnippet").append(chartTitle +":" +$("#"+chartTitle+"").text()+"<br>");
					
	});

}


function getFlightData(){
/*$('#invoicedataTable').DataTable( {
       // data: dataSet,
        columns: myArrayNew
    } );*/
	
var flightIdUrl="https://aircraft-svc-techmspace.run.aws-usw02-pr.ice.predix.io/view/getSelectedFlightsData/101";
	
	
	$.ajax({
			url:flightIdUrl,
			type: "GET",
			headers : {
			'Content-Type' : 'application/json'
			},
			success: function(responseData) {
				
			responseJsonDataForFlight=responseData;
			
			showDataTable(responseJsonDataForFlight);
			
			$(".loadingChart5").css("visibility", "hidden");
			$("#prepareDataSetId").show();
			$("#searchBoxIdDate").show();
			$("#yadcf-filter--invoicedataTable-from-date-16").val('06-26-2004');
	
		},

   error: function ( xhr, status, error) {
	   $(".loadingChart5").css("visibility", "hidden");
    console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
    }
    });	
}
function showDataTable(responseJsonDataForFlight){
	if(flightDataDataTable!=undefined){
		$('#invoicedataTable').dataTable().fnDestroy();
	}
	
	var ndx=0;
	flightDataDataTable=$('#invoicedataTable').dataTable({
				"aaData": responseJsonDataForFlight,
				//"bStateSave": true,
				// "bJQueryUI": true,
				//"bProcessing": true,
                  dom: 'lBfrtip',
				  //"bFilter" : false, 
				  "bPaginate": true,
				 "lengthMenu": [10,25,50,100,500],
				  "scrollY": 200,
				"scrollX": true,
                 buttons: ['excel' , 'print','copyHtml5'],
                  "aoColumns":myArrayNew,
               }).yadcf([
			    
				{
				column_number: 1,
				filter_type: "range_number_slider"
				},
				{
				column_number: 2,
					filter_type: "auto_complete"
				}, 
				{
					column_number: 3,
					filter_type: "range_number_slider"
				}, 
				{
					column_number: 4,
					filter_type: "range_number_slider"
				
				},
				{
					column_number: 5,
					filter_type: "range_number_slider"	
				},
				{
					column_number: 6,
					filter_type: "range_number_slider"	
				},
				{
			     column_number: 16,
			     filter_type: "range_date",
				 filter_container_id: "external_filter_container",
				 date_format:  'mm-dd-yy',
				 
				}
			]); 
			   
		oTable = $('#invoicedataTable').DataTable();

}




  
  