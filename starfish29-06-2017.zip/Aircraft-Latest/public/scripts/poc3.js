 
 var poc3JsonData;
 var poc3NewArray;
 var airborneDtoList;
 var groundDtoList;
 var dynamicFlightIdForPoc3;
 var pocDatatable;
 var totalFlightDataList;
 var multipleArrayPoc3=[];
  var pressureAltitudeArray;
 var airspeedArray;
 var multiParamsDataArrayPoc3;
 var chartTitlesArrayPoc3;
 var takeoffTime;
 var landingTime;
 
 
 $(document).ready(function () {
 $("#poc3IDclick").click(function(){
	$("#loadingChart6").show(); 
loadDynamicflightIdForPoc3();	
	
if (pocDatatable != null){
pocDatatable.fnDestroy();
}
$("#container6").hide();
$("#airbornesegmentTableId").hide();
$("#airtakeoff").html(0);
$("#airtakeoffLanding").html(0);
 $("#airborneflightsegment").html(0);
$("#flightIdPoc3").val(0);
 
 
});
 
 
 
 	$('#container6').bind('mousemove touchmove touchstart', function (e) {
			 var chart, point, i, event;
            			 
			 for (i = 0; i < Highcharts.charts.length; i = i + 1) {
				 chart = Highcharts.charts[i];
				 if(chart=== undefined){
				 }else{
				 
				 
				 
				 event = chart.pointer.normalize(e.originalEvent); // Find coordinates within the chart
				 point = chart.series[0].searchPoint(event, true); // Get the hovered point				 
				 if (point) {
					point.highlight(e);
				 }
			 }
			 }
         });
         /**
         * Override the reset function, we don't need to hide the tooltips and crosshairs.
         */
         Highcharts.Pointer.prototype.reset = function () {
			return undefined;
         };
         
         /**
         * Highlight a point by showing tooltip, setting hover state and draw crosshair
         */
         Highcharts.Point.prototype.highlight = function (event) {
			 this.onMouseOver(); // Show the hover marker
			 this.series.chart.tooltip.refresh(this); // Show the tooltip
			 this.series.chart.xAxis[0].drawCrosshair(event, this); // Show the crosshair
         };
		 
	$("#container6").hide();
	     poc3NewArray = [
                { "sTitle": "Flight Id", "mData": "flightId" },
				{ "sTitle": "Elapsed Time ", "mData": "elapsedTime" },
                { "sTitle": "Air Speed", "mData": "airspeed" },
                { "sTitle": "Vertical Acceleration", "mData": "verticalAcceleration" },
                { "sTitle": "Roll Acceleration ", "mData": "rollAcceleration" },
				{ "sTitle": "Pressure Altitude", "mData": "pressureAltitude" },
				{ "sTitle": "Strain Gauge 1", "mData": "strainGauge1" },
				{ "sTitle": "Strain Gauge 2", "mData": "strainGauge2" },
                { "sTitle": "Strain Gauge 3", "mData": "strainGauge3" },
				{ "sTitle": "Strain Gauge 4", "mData": "strainGauge4" }
						
               
            ];  
	 
	
 $("#flightIdPoc3").change(function(){
 
$("#container6").html('');
	$("#segmentationId").val(0);
		if (pocDatatable != null){
			pocDatatable.fnDestroy();
			}
		var flightIdVal=$(this).val();
		$("#loadingChart6").show();
		getjsonDataForPoc3(flightIdVal);
		$("#airbornesegmentTableId").show();
});
$("#segmentationId").change(function(){
	 var segmentationId=$(this).val();
	 
	 if (pocDatatable != null){
			pocDatatable.fnDestroy();
			}
	 if(segmentationId=='0'){
		refreshPOC3Table(airborneDtoList);
	 }else if(segmentationId=='1'){
		refreshPOC3Table(groundDtoList);
	 }else{
	 }
});


 
 });
 function getjsonDataForPoc3(flightIdVal){
	
 	var predixurl="https://predix-aircraft-demo3.run.aws-usw02-pr.ice.predix.io/view/getFlightSegments4";
				$.ajax({
				url:predixurl+"/"+flightIdVal,
                type: "get", 
                success: function(responseData) {
				poc3JsonData=responseData;
				
				for(var i=0;i<poc3JsonData.length;i++){
					takeoffTime=parseFloat(JSON.stringify(poc3JsonData[i].startTakeoffElapsedTime)).toFixed(2);
					landingTime=parseFloat(JSON.stringify(poc3JsonData[i].startLandingElapsedTime)).toFixed(2);
					$("#airtakeoff").html(parseFloat(JSON.stringify(poc3JsonData[i].startTakeoffElapsedTime)).toFixed(2));
					$("#airtakeoffLanding").html(parseFloat(JSON.stringify(poc3JsonData[i].startLandingElapsedTime)).toFixed(2));
					$("#airborneflightsegment").html(parseFloat(JSON.stringify(poc3JsonData[i].airborneFltSegmentDuration)).toFixed(2));
					airborneDtoList = poc3JsonData[i].airborneDtoList;
					groundDtoList=poc3JsonData[i].groundDtoList;
					totalFlightDataList=poc3JsonData[i].totalFlightDataList;
				}
				
				
				$("#loadingChart6").hide();
				 refreshMFGTable(airborneDtoList);
				 drawChart(totalFlightDataList);
				 
			     
		     
				
				},
 
                error: function ( xhr, status, error) {
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				$("#loadingChart6").hide();
				}
 				});
 
 }
 
 function drawChart(totalFlightDataList){
 $("#container6").show();
 pressureAltitudeArray = new Array();
 airspeedArray = new Array();
 
 multiParamsDataArrayPoc3 = new Array();         
 chartTitlesArrayPoc3 = new Array();
		
		for (var i = 0; i < totalFlightDataList.length; i++) {
			 pressureAltitudeArray.push([parseFloat(totalFlightDataList[i].elapsedTime),parseFloat(totalFlightDataList[i].pressureAltitude)]);
		 	airspeedArray.push([parseFloat(totalFlightDataList[i].elapsedTime),parseFloat(totalFlightDataList[i].airspeed)]);
	
		}
		
		multiParamsDataArrayPoc3.push(pressureAltitudeArray);
		chartTitlesArrayPoc3.push("Pressure Altitude");	
		
		multiParamsDataArrayPoc3.push(airspeedArray);
		chartTitlesArrayPoc3.push("Air Speed");	
		
		
		  $.each(multiParamsDataArrayPoc3, function (i, dataset) { 
					var chartTitle = chartTitlesArrayPoc3[i];
					$('<div class="chart">').appendTo('#container6').highcharts({
						chart: {
							marginLeft: 40, // Keep all charts left aligned
							spacingTop: 20,
							spacingBottom: 20,
							type: 'line',
							zoomType: 'xy'
						},
						title: {
							text: chartTitle,
							align: 'left',
							margin: 0,
							x: 30
						},
						annotationsOptions: {
							enabledButtons: false   
						},
						credits: {
							enabled: false
						},
						legend: {
							enabled: false
						},
						xAxis: {
							crosshair: true,
							events: {
								setExtremes: syncExtremes
							},
							title: {
								enabled: true,
								text: 'Elapsed Time'
							},
							labels: {
								format: '{value} sec'
							},
							 plotLines: [{ // mark the weekend
            color: 'red',
            width: 2,
            value: takeoffTime,
            dashStyle: 'longdashdot',
			 label: {
            text: 'Take Off',
            // Content of the label.
            //align: 'mid' // Positioning of the label.
          }
             },
             { // mark the weekend
            color: 'red',
            width: 2,
            value: landingTime,
            dashStyle: 'longdashdot',
			label: {
            text: 'Landing',
            // Content of the label.
            //align: 'mid' // Positioning of the label.
          }
             }],
							
						},
						yAxis: {
							title: {
								text: null
							}
						},
						series: [{
							data: dataset,
							name: chartTitle,
							color: Highcharts.getOptions().colors[i],
							fillOpacity: 0.3
						}]
					});
				});			
				
	}
 
 function syncExtremes(e) {
			 var thisChart = this.chart;         
			 if (e.trigger !== 'syncExtremes') { // Prevent feedback loop
				 Highcharts.each(Highcharts.charts, function (chart) {
					 if (chart !== undefined && chart !== thisChart) {
						 if (chart.xAxis[0].setExtremes) { // It is null while updating
							chart.xAxis[0].setExtremes(e.min, e.max, undefined, false, { trigger: 'syncExtremes' });
						 }
					 }
				 });
			 }

         } 
 
 function refreshMFGTable(jsonData){
    pocDatatable= $('#airbornesegment').dataTable({
			"aaData": jsonData,
                  dom: 'lBfrtip',
				  "bFilter" : false, 
				  "bPaginate": true,
				 "lengthMenu": [5,10,50,100],
                 buttons: ['excel' , 'print','copyHtml5'],
                  "aoColumns":poc3NewArray,
			   
			   "initComplete": function(settings){
					$('#airbornesegment thead th').each(function () {
					   var $td = $(this);
					   $td.attr('title', $td.text());
					});

					/* Apply the tooltips */
					$('#airbornesegment thead th[title]').tooltip(
					{
					   "container": 'body'
					}); 
							//var detail=data.poNumber;       
							//alert('detail'+detail);							
				} 

               }

);
	$('#airbornesegment_length').find('label').css({"margin-left": "900px"})
}

function refreshPOC3Table(jsonData){
	pocDatatable= $('#airbornesegment').dataTable({
			"aaData": jsonData,
                  dom: 'lBfrtip',
				  "bFilter" : false, 
				  "bPaginate": true,
				 "lengthMenu": [5,10,50,100],
                 buttons: ['excel' , 'print','copyHtml5'],
                  "aoColumns":poc3NewArray,
			   
			   "initComplete": function(settings){
					$('#airbornesegment thead th').each(function () {
					   var $td = $(this);
					   $td.attr('title', $td.text());
					});

					/* Apply the tooltips */
					$('#airbornesegment thead th[title]').tooltip(
					{
					   "container": 'body'
					}); 
							//var detail=data.poNumber;       
							//alert('detail'+detail);							
				} 

               }

);
$('#airbornesegment_length').find('label').css({"margin-left": "900px"})
}

	 function loadDynamicflightIdForPoc3(){
		 var predixurl="https://predix-aircraft-demo3.run.aws-usw02-pr.ice.predix.io/getFlightIds";
				$.ajax({
				url:predixurl,
                type: "get", //send it through post method
                success: function(responseData) {
				//dynamicFlightId=responseData;
				$("#loadingChart6").hide();
				$('#flightIdPoc3').find('option:not(:first)').remove();
				for (var i = 0; i < responseData.length; i++) {
					$('#flightIdPoc3').append($('<option>', { 
						value: JSON.stringify(responseData[i].flightId),
						//text : JSON.stringify(responseData[i].flightId)
						text : 'TM-'+JSON.stringify(responseData[i].flightId)
				}));
           }
				},
                error: function ( xhr, status, error) {
				$("#loadingChart6").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});
		 
	 }

