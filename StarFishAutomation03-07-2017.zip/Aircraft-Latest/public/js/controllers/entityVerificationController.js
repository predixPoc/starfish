app.controller('entityVerificationController', function($scope, $filter, $http, $rootScope,$state,Auth,$timeout,toaster,constants,
	$cookies,$cookieStore,$location, WorkFlow, supplier, dueDeligence) {

	$scope.entityVerificationInfo = {};	
	$scope.watchlistScreeningInfo = {};
	$scope.AdverseMediaResearchInfo = {};
	$scope.bankScreeningInfo={};
	$scope.ownerOfficerInfo={};
	$scope.ownerOfficerAdverseMediaInfo={};
	$scope.spiritLetterInfo={};
	$scope.referenceInfo={};
	$scope.accountFlagInfo={};
	$scope.files=[];

    supplier.getCountryList().then(function(data) {
		$scope.chooseCountries = data;
	}, function() {
		toaster.pop('error', "Country list", "server not responding");
	});


    
    $scope.dependantStateClassify=function(country) {
        angular.forEach($scope.chooseCountries, function(value, key) {
        	if(value.id==country){
    	supplier.getStatesList(value.code).then(function(data) {
            $scope.stateList=data[0].subdivisions;			
      	}, function() {
  			toaster.pop('error', "Country", "server not responding");
  		});	
        	}
        });    	
    }



	

	var makeTabFriendly = function(tasks) {
		angular.forEach(tasks, function(value, key) {
			angular.forEach(value, function(tabsValue, tabsKey) {
				value[tabsValue.taskType] = true;	
				value['requestId'] = tabsValue.requestId;				
				value['partyId'] = tabsValue.partyId;				
				value[tabsValue.taskType+'_INTERNAL_ID'] = (tabsValue.linkedInternalId)?tabsValue.linkedInternalId:null;	
				value[tabsValue.taskType+'_TASK_ID'] = (tabsValue.id)?tabsValue.id:null;			
				value[tabsValue.taskType+'_ADDRESS_ID'] = (tabsValue.addressId)?tabsValue.addressId:null;			
				
				// header informations
				if(tabsKey == 0) {
					value['legalName'] = tabsValue.legalName;
					value['address'] = tabsValue.address;
					value['riskLevel'] = tabsValue.riskLevel;
					value['commodity'] = tabsValue.commodity;
				}
				
				if(value['legalName'] == null || !value['legalName']) {
					value['legalName'] = tabsValue.legalName;
				}
				
				if(value['address'] == null || !value['address']) {
					value['address'] = tabsValue.address;
				}
				
				if(value['riskLevel'] == null || !value['riskLevel']) {
					value['riskLevel'] = tabsValue.riskLevel;
				}
				
				if(value['commodity'] == null || !value['commodity']) {
					value['commodity'] = tabsValue.commodity;
				}				
				
			});
			
		});		
		return tasks;
	}
	
	var lastId=0;
	$scope.requests =[];
	var loadWorkFlowParser = function(start) {
		$scope.loader=true;
		dueDeligence.getTaskListsNew(10, start).then(function(data) {		
			$scope.loader=false;
			//data =  {"data":{"519749":[[{"id":"1134795","url":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1134795","name":"Site watchlist review","description":"519749","createTime":"2016-12-13T03:37:15.694Z","priority":"50","suspended":"false","tenantId":"","category":"519749","parentTaskId":"1134794","parentTaskUrl":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1134794","taskType":"DD_SITE_WATCHLIST_REVIEW","requestId":"519749","linkedInternalId":"SUPPL-519749-ADDR1","legalName":"TestSprint21CorpDev3","address":"1007,Main Ave,Stamford","commodity":"Labor Services"}]],"519832":[[{"id":"1136029","url":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1136029","name":"Overall account flag","description":"519832","createTime":"2016-12-13T13:50:58.691Z","priority":"50","suspended":"false","tenantId":"","category":"519832","parentTaskId":"1136021","parentTaskUrl":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1136021","taskType":"DD_ACCOUNT_FLAG","requestId":"519832","legalName":"Test_Standard","address":"a,e,IS-7,Iceland","riskLevel":"HEIGHTENED","commodity":"Logistics & Transportation"},{"id":"1136025","url":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1136025","name":"Legal entity adverse media research","description":"519832","createTime":"2016-12-13T13:50:52.842Z","priority":"50","suspended":"false","tenantId":"","category":"519832","parentTaskId":"1136021","parentTaskUrl":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1136021","taskType":"DD_ENTITY_MEDIA_RESEARCH","requestId":"519832"}],[{"id":"1136027","url":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1136027","name":"Bank watchlist review","description":"519832","createTime":"2016-12-13T13:50:58.680Z","priority":"50","suspended":"false","tenantId":"","category":"519832","parentTaskId":"1136026","parentTaskUrl":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1136026","taskType":"DD_BANK_WATCHLIST_REVIEW","requestId":"519832","linkedInternalId":"PRTBI2","legalName":"Test_Standard","address":"a,e,IS-7,Iceland","riskLevel":"HEIGHTENED","commodity":"Logistics & Transportation"}]],"519788":[[{"id":"1135309","url":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1135309","name":"Site watchlist review","description":"519788","createTime":"2016-12-13T07:30:33.284Z","priority":"50","suspended":"false","tenantId":"","category":"519788","parentTaskId":"1135308","parentTaskUrl":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1135308","taskType":"DD_SITE_WATCHLIST_REVIEW","requestId":"519788","linkedInternalId":"SUPPL-519788-ADDR1","legalName":"TestSpt21.3","address":"Address Line 1a,Address Line 1a","commodity":"Utilities"}]],"519789":[[{"id":"1135319","url":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1135319","name":"Site watchlist review","description":"519789","createTime":"2016-12-13T07:30:49.893Z","priority":"50","suspended":"false","tenantId":"","category":"519789","parentTaskId":"1135318","parentTaskUrl":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1135318","taskType":"DD_SITE_WATCHLIST_REVIEW","requestId":"519789","linkedInternalId":"SUPPL-519789-ADDR1","legalName":"Laos","address":"E22,E4444"}]],"519775":[[{"id":"1135122","url":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1135122","name":"Site watchlist review","description":"519775","createTime":"2016-12-13T07:02:51.137Z","priority":"50","suspended":"false","tenantId":"","category":"519775","parentTaskId":"1135121","parentTaskUrl":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1135121","taskType":"DD_SITE_WATCHLIST_REVIEW","requestId":"519775","linkedInternalId":"SUPPL-519775-ADDR1","legalName":"JBehave Partial address update 2016-12-13T07:02:45.021Z 547e7401-5308-47e1-a5ba-3ee2c6ac1d5d","address":"SUPPLIER_ADDRESS_UPDATE1,SUPPLIER_ADDRESS_UPDATE_CITY"}]],"519750":[[{"id":"1134805","url":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1134805","name":"Site watchlist review","description":"519750","createTime":"2016-12-13T03:37:50.186Z","priority":"50","suspended":"false","tenantId":"","category":"519750","parentTaskId":"1134804","parentTaskUrl":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1134804","taskType":"DD_SITE_WATCHLIST_REVIEW","requestId":"519750","linkedInternalId":"SUPPL-519750-ADDR1","legalName":"TestSprint21CorpDev3","address":"1008,Main Ave,Stamforddd","commodity":"Labor Services"}]],"519829":[[{"id":"1135969","url":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1135969","name":"Site watchlist review","description":"519829","createTime":"2016-12-13T13:20:27.375Z","priority":"50","suspended":"false","tenantId":"","category":"519829","parentTaskId":"1135968","parentTaskUrl":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1135968","taskType":"DD_SITE_WATCHLIST_REVIEW","requestId":"519829","linkedInternalId":"SUPPL-519829-ADDR1","legalName":"Laos","address":"E22,E44"}]],"519781":[[{"id":"1135237","url":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1135237","name":"Site watchlist review","description":"519781","createTime":"2016-12-13T07:24:08.642Z","priority":"50","suspended":"false","tenantId":"","category":"519781","parentTaskId":"1135236","parentTaskUrl":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1135236","taskType":"DD_SITE_WATCHLIST_REVIEW","requestId":"519781","linkedInternalId":"SUPPL-519781-ADDR1","legalName":"TestSpt21.3","address":"jo addess,jo1 addess","commodity":"Utilities"}]],"519806":[[{"id":"1135634","url":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1135634","name":"Legal entity verification","description":"519806","createTime":"2016-12-13T10:01:56.778Z","priority":"50","suspended":"false","tenantId":"","category":"519806","parentTaskId":"1135633","parentTaskUrl":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1135633","taskType":"DD_ENTITY_VERIFICATION","requestId":"519806","legalName":"Sagar","address":"a,e,IS-7,Iceland","riskLevel":"FAST_TRACK","commodity":"Logistics & Transportation"},{"id":"1135616","url":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1135616","name":"Overall account flag","description":"519806","createTime":"2016-12-13T10:01:55.434Z","priority":"50","suspended":"false","tenantId":"","category":"519806","parentTaskId":"1135610","parentTaskUrl":"https://pcflowservices-dev.run.asv-pr.ice.predix.io/runtime/tasks/1135610","taskType":"DD_ACCOUNT_FLAG","requestId":"519806"}]]},"lastId":"36"};			
			lastId = data.lastId;
			var rows = [];
			angular.forEach(data.data, function(value, key) {
				rows = rows.concat(value);		
			});	
			
			$scope.requests = $scope.requests.concat(makeTabFriendly(rows));
			
			//$scope.initPagination();
			/*
			angular.forEach($scope.requests, function(value, key) {			
				
				WorkFlow.getVariablesById(value[0].requestId).then(function(data) {		
						value.WfModel = data.data;					
						if(value.WfModel.subscription.commodityTier1Id){
							supplier.getcommodityValueFromId(value.WfModel.subscription.commodityTier1Id).then(function(data) {

								value.commodityName=data.name;
							}, function() {
								//toaster.pop('error', "commodities", "server not responding");
							});
						}					
						$scope.loader=false;
				}, function(data) {
					$scope.loader=false;
									
				});
						
				
			}); */
		}, function(data) {
			$scope.loader=false;		
		});
	}
	loadWorkFlowParser(0);
	
	
	$scope.showAddress = function(item) {
		
		
			
		
		var address = '';		
		if(item.WfModel) {
			var country = '';
            if(item.WfModel.supplier != null && item.WfModel.supplier.addresses[0]){
				
			    address = item.WfModel.supplier.addresses[0].location.addressLine1+', '+
				   item.WfModel.supplier.addresses[0].location.cityName+', '+
				   $scope.countryName;
				country = item.WfModel.supplier.addresses[0].location.countryId;
			}   
			if(item.DD_SITE_WATCHLIST_REVIEW_INTERNAL_ID != null) {				
				angular.forEach(item.WfModel.supplier.addresses, function(value, key) {					
					if(value.internalId == item.DD_SITE_WATCHLIST_REVIEW_INTERNAL_ID) {						
						address = value.location.addressLine1+', '+
						   value.location.cityName+', '+
						   $scope.countryName;
						country =  value.location.countryId;
					}
				});
				
			}
			if(item.DD_BANK_WATCHLIST_REVIEW_ADDRESS_ID!=null) {				
				angular.forEach(item.WfModel.supplier.addresses, function(value, key) {					
					if(value.internalId == item.DD_BANK_WATCHLIST_REVIEW_ADDRESS_ID) {						
						address = value.location.addressLine1+', '+
						   value.location.cityName+', '+
						   $scope.countryName;
						country =  value.location.countryId;
					}
				});
			}
			if(country) {				
				var codeArray = $filter('filter')($scope.chooseCountries, {'id':country});
				$scope.countryName = (codeArray[0])?codeArray[0].name:'';					
			}
		}
		return  address;
	}
	
	
	var groupRequestIds = function(tasks) {
		
		var uniqueIds = [];
		angular.forEach(tasks, function(value, key) {

			if(value.taskType=="DD_SITE_WATCHLIST_REVIEW" || value.taskType=="DD_BANK_WATCHLIST_REVIEW"){
				uniqueIds.push(value);
				value[value.taskType] = true;
			}	
			else{
				var filterArray = $filter('filter')(uniqueIds, {requestId:value.requestId})
				
				if(!filterArray[0]){
					
					value[value.taskType] = true;
					uniqueIds.push(value);				
				} else {
					angular.forEach(uniqueIds, function(uniqueValue, uniqueKey) {
						if(uniqueValue.requestId == filterArray[0].requestId 
						&& uniqueValue.DD_SITE_WATCHLIST_REVIEW==undefined
						&& uniqueValue.DD_BANK_WATCHLIST_REVIEW==undefined
						){
						
							uniqueValue[value.taskType] = true;
						}
						
					});
	
				}
			}
			
		});
		console.log(uniqueIds);
		return uniqueIds;
	}
	
	
	
	
	//get source dropdown data
	dueDeligence.getEntityVerificationSources().then(function(data){
		$scope.entitySourceData = data;
		console.log("entitySourceData", $scope.entitySourceData)
	});

	//get methods of delivery dropdown data
	dueDeligence.getModeOfDelivery().then(function(data){
		$scope.methodsOfDeliveryData = data;
	});

	//get category dropdown data
	dueDeligence.getNegativeNewsCategories().then(function(data){
		$scope.categoriesData = data;
	});

	$scope.getTags = function(){
		dueDeligence.getTags().then(function(data){
			$scope.tags = data.data;
			$scope.tagsData = $scope.tags.data;
			$rootScope.preselectedValue = $scope.tags.data[0].id;
			console.log("tagsData", $scope.tagsData)
		});
	}
	$scope.getTags();

	$scope.switchTabs = function(item, tab) {
		console.log(item);
		item.showEntity = false;
		item.showWatchlist = false;
		item.showAdverseMedia = false;
		item.showBankScreen = false;
		item.showOwner = false;
		item.showSpirit = false;
		item.showReference = false;
		item.showAccountFlag = false;
		item[tab] = true;
	}
	
	$scope.toggleItem  = function(item) {
			
			// Resetting all tabs
			item.showEntity = false;
			item.showWatchlist = false;
			item.showAdverseMedia = false;
			item.showBankScreen = false;
			item.showOwner = false;
			item.showSpirit = false;
			item.showReference = false;
			item.showAccountFlag = false;
			
			angular.forEach($scope.requests, function(value, key) {
				if(!angular.equals(value, item)){
					value.isOpen = false;
				}
					
			});
			item.isOpen = !item.isOpen;
			if(item.DD_ENTITY_VERIFICATION==true){
				item.showEntity = true;
			}
			else if(item.DD_SITE_WATCHLIST_REVIEW==true){
				item.showWatchlist = true;
			}
			else if(item.ENTITY_MEDIA_RESEARCH==true){
				item.showAdverseMedia = true;
			}
			else if(item.BANK_WATCHLIST_REVIEW==true){
				item.showBankScreen = true;
			}
			else if(item.DD_BANK_WATCHLIST_REVIEW==true){
				item.showBankScreen = true;
			}
			else if(item.DD_OWNER_MEDIA_RESEARCH==true){
				item.showOwner = true;
			}
			else if(item.DD_SPIRIT_AND_LETTER==true){
				item.showSpirit = true;
			}
			else if(item.DD_REFERENCES==true){
				item.showReference = true;
			}
			else if(item.DD_ACCOUNT_FLAG==true){
				item.showAccountFlag = true;
			}
			
			if(item.isOpen) {
			$scope.loader=true;	
				WorkFlow.getVariablesById(item.requestId).then(function(data) {	
						$scope.loader=false;
						item.WfModel = data.data;



							//item.showEntity = true;
							//
							$scope.entityVerificationInfo.legalName = (item.WfModel.supplier)?item.WfModel.supplier.legalName:'';
							$scope.entityVerificationInfo.dba = (item.WfModel.supplier.alternateId[0])?item.WfModel.supplier.alternateId[0].value:null;
							$scope.entityVerificationInfo.addressLine1 = (item.WfModel.supplier.addresses[0])?item.WfModel.supplier.addresses[0].location.addressLine1:null;
							$scope.entityVerificationInfo.addressLine2 = (item.WfModel.supplier.addresses[0])?item.WfModel.supplier.addresses[0].location.addressLine2:null;
							$scope.entityVerificationInfo.addressLine3 = (item.WfModel.supplier.addresses[0])?item.WfModel.supplier.addresses[0].location.addressLine3:null;
							$scope.entityVerificationInfo.addressLine4 = (item.WfModel.supplier.addresses[0])?item.WfModel.supplier.addresses[0].location.addressLine4:null;
							$scope.entityVerificationInfo.city = (item.WfModel.supplier.addresses[0])?item.WfModel.supplier.addresses[0].location.cityName:null;
							$scope.entityVerificationInfo.countryId = (item.WfModel.supplier.addresses[0])?parseInt(item.WfModel.supplier.addresses[0].location.countryId):null;
							$scope.dependantStateClassify($scope.entityVerificationInfo.countryId);
							$scope.entityVerificationInfo.stateId = (item.WfModel.supplier.addresses[0])?parseInt(item.WfModel.supplier.addresses[0].location.stateId):null;
							$scope.entityVerificationInfo.postalCode = (item.WfModel.supplier.addresses[0])?item.WfModel.supplier.addresses[0].location.postalCode:null;
							$scope.entityVerificationInfo.taxId = (item.WfModel.supplier.legalTax)?item.WfModel.supplier.legalTax.taxRegistrationNumber:null;
							$scope.entityVerificationInfo.entityVerified = (item.WfModel.dueDiligence.entityVerification)?item.WfModel.dueDiligence.entityVerification.passed:null;
							$scope.entityVerificationInfo.source = (item.WfModel.dueDiligence.entityVerification)?parseInt(item.WfModel.dueDiligence.entityVerification.source):null;
							$scope.entityVerificationInfo.comments = (item.WfModel.dueDiligence.entityVerification)?item.WfModel.dueDiligence.entityVerification.comments:null;
							$scope.entityVerificationInfo.entityVerifiedDocId = (item.WfModel.dueDiligence.entityVerification)?item.WfModel.dueDiligence.entityVerification.documents[0]:null;
							var docs = (item.WfModel.dueDiligence.entityVerification)?item.WfModel.dueDiligence.entityVerification.documents:null;
							
							$scope.entityVerificationInfo.files= [];
							angular.forEach(docs, function(value, key) {
								if(value){
									dueDeligence.getFileInfo(localStorage.getItem("userId"), value ,'entity').then(function(data){
										var fileObj = {
												id:data.value, 
												name:data.FileName, 
												downloadUrl: constants.FILE_DOWNLOAD+localStorage.getItem("userId")+ '-' + value +'-entity'
											};
										 $scope.entityVerificationInfo.files.push(fileObj);
									}, function(data) {				
									
									});					
								}

							});
							
							
							// if(item.WfModel.dueDiligence.entityVerification.documents.length > 0){
							// 	$scope.entityVerificationInfo.entityVerifiedDocId = (item.WfModel.dueDiligence.entityVerification)?item.WfModel.dueDiligence.entityVerification.documents[0]:null;
							// 	$scope.fileDownload_entityVerified=true;
					  //       	var getId=document.getElementById('downloadUrlForFile_entityVerified');
					  //       	getId.href= constants.FILE_DOWNLOAD+item.WfModel.dueDiligence.entityVerification.documents[0];
							//   	supplier.getlistFileUploaded($scope.entityVerificationInfo.entityVerifiedDocId).then(function(data) {
							//   		$scope.entityVerifiedFileName=data.FileName;
							//   	}, function(data) {});
							// }else{
							// 	$scope.fileDownload_entityVerified=false;
							// }
							$scope.ownerOfficerInfo.name = (item.WfModel.supplier.ownersAndOfficers)?item.WfModel.supplier.ownersAndOfficers.persons[0].name:null;
							$scope.ownerOfficerInfo.title = (item.WfModel.supplier.ownersAndOfficers)?item.WfModel.supplier.ownersAndOfficers.persons[0].title:null;
							$scope.ownerOfficerInfo.ownershipInterest = (item.WfModel.supplier.ownersAndOfficers)?item.WfModel.supplier.ownersAndOfficers.persons[0].ownershipInterest:null;
							$scope.ownerOfficerInfo.residentCountry = (item.WfModel.supplier.ownersAndOfficers)?item.WfModel.supplier.ownersAndOfficers.persons[0].residentCountry:null;
							$scope.ownerOfficerInfo.watchListCheckCaseId = (item.WfModel.supplier.ownersAndOfficers)?item.WfModel.supplier.ownersAndOfficers.persons[0].internalId:null;
							$scope.ownerOfficerInfo.watchListCheckStatus = (item.WfModel.supplier.ownersAndOfficers)?item.WfModel.supplier.ownersAndOfficers.persons[0].watchListCheckStatus:null;
							$scope.ownerOfficerInfo.watchlistCheckComment = (item.WfModel.supplier.ownersAndOfficers)?item.WfModel.supplier.ownersAndOfficers.persons[0].watchListCheckComment:null;
							
							$scope.isASP = (item.WfModel.dueDiligence.isASP)?item.WfModel.dueDiligence.isASP:null;
							$scope.riskLevel = (item.WfModel.dueDiligence.riskLevel)?item.WfModel.dueDiligence.riskLevel:null;
							/*
								$scope.ownerOfficerAdverseMediaInfo.summary = (item.WfModel.dueDiligence.ownerAndOfficerAdverseMediaResearch)?item.WfModel.dueDiligence.ownerAndOfficerAdverseMediaResearch.articles[0].summary:null;
								$scope.ownerOfficerAdverseMediaInfo.category = (item.WfModel.dueDiligence.ownerAndOfficerAdverseMediaResearch)?parseInt(item.WfModel.dueDiligence.ownerAndOfficerAdverseMediaResearch.articles[0].category):null;
								$scope.ownerOfficerAdverseMediaInfo.websites = (item.WfModel.dueDiligence.ownerAndOfficerAdverseMediaResearch)?item.WfModel.dueDiligence.ownerAndOfficerAdverseMediaResearch.articles[0].websites:null;
							*/

							$scope.negativeNewsArticlesOwner = (item.WfModel.dueDiligence.ownerAndOfficerAdverseMediaResearch)?item.WfModel.dueDiligence.ownerAndOfficerAdverseMediaResearch.articles:[{}];			
							angular.forEach($scope.negativeNewsArticlesOwner, function(ReportsValue, key) {
								 ReportsValue.files = [];
								 angular.forEach(ReportsValue.documents, function(value, key) {
									 if(value){
										dueDeligence.getFileInfo(localStorage.getItem("userId"), value ,'mediaResearch').then(function(data){
											var fileObj = {
													id:data.value, 
													name:data.FileName, 
													downloadUrl: constants.FILE_DOWNLOAD+localStorage.getItem("userId")+ '-' + value +'-mediaResearch'
												};
											 ReportsValue.files.push(fileObj);
										}, function(data) {				
										
										});
										 
									 }

								});
							});
							
							//$scope.ownerOfficerAdverseMediaInfo.documents = (item.WfModel.dueDiligence.ownerAndOfficerAdverseMediaResearch)?item.WfModel.dueDiligence.ownerAndOfficerAdverseMediaResearch.articles[0].documents[0]:null;
							$scope.spiritLetterInfo.acknowledgmentDate = (item.WfModel.dueDiligence.spiritAndLetter)?item.WfModel.dueDiligence.spiritAndLetter.acknowledgmentDate.month+'-'+item.WfModel.dueDiligence.spiritAndLetter.acknowledgmentDate.day:null;
							$scope.spiritLetterInfo.dateOfTraining = (item.WfModel.dueDiligence.spiritAndLetter)?item.WfModel.dueDiligence.spiritAndLetter.dateOfTraining.month+'-'+item.WfModel.dueDiligence.spiritAndLetter.dateOfTraining.day:null;
							$scope.spiritLetterInfo.methodOfDelivery = (item.WfModel.dueDiligence.spiritAndLetter)?parseInt(item.WfModel.dueDiligence.spiritAndLetter.methodOfDelivery):null;
							$scope.spiritLetterInfo.documents = (item.WfModel.dueDiligence.spiritAndLetter)?item.WfModel.dueDiligence.spiritAndLetter.documents:null;
							$scope.spiritLetterInfo.files= [];
							angular.forEach(docs, function(value, key) {
								if(value){
									dueDeligence.getFileInfo(localStorage.getItem("userId"), value ,'sprit').then(function(data){
										var fileObj = {
												id:data.value, 
												name:data.FileName, 
												downloadUrl: constants.FILE_DOWNLOAD+localStorage.getItem("userId")+ '-' + value +'-sprit'
											};
										 $scope.spiritLetterInfo.files.push(fileObj);
									}, function(data) {				
									
									});
									
								}

							});
							
							/*
							$scope.referenceInfo.source = (item.WfModel.dueDiligence.references)?parseInt(item.WfModel.dueDiligence.references.source):null;
							$scope.referenceInfo.dateReceived = (item.WfModel.dueDiligence.references)?item.WfModel.dueDiligence.references.thirdPartyReports[0].dateReceived.month+'-'+item.WfModel.dueDiligence.references.thirdPartyReports[0].dateReceived.day:null;			
							$scope.referenceInfo.commercialReferencesComment = (item.WfModel.dueDiligence.references)?item.WfModel.dueDiligence.references.commercialReferencesComment:null;											
							$scope.referenceInfo.documents = (item.WfModel.dueDiligence.references)?item.WfModel.dueDiligence.references.thirdPartyReports[0].documents[0]:null;
							*/
							$scope.reports = (item.WfModel.dueDiligence.references)?item.WfModel.dueDiligence.references.thirdPartyReports:[{}];
							$scope.commercialReferencesComment = (item.WfModel.dueDiligence.references)?item.WfModel.dueDiligence.references.commercialReferencesComment:null;											
							 angular.forEach($scope.reports, function(ReportsValue, key) {
								 ReportsValue.files = [];
								 angular.forEach(ReportsValue.documents, function(value, key) {
									 if(value){
										dueDeligence.getFileInfo(localStorage.getItem("userId"), value ,'reference').then(function(data){
											var fileObj = {
													id:data.value, 
													name:data.FileName, 
													downloadUrl: constants.FILE_DOWNLOAD+localStorage.getItem("userId")+ '-' + value +'-reference'
												};
											 ReportsValue.files.push(fileObj);
										}, function(data) {				
										
										});
										 
									 }

								});
							});
							
							
							$scope.accountFlagInfo.overallDueDiligenceFlag = (item.WfModel.dueDiligence.overallDueDiligenceFlag)?item.WfModel.dueDiligence.overallDueDiligenceFlag:null;
							$scope.accountFlagInfo.overallDueDiligenceFlag = (item.WfModel.dueDiligence.overallDueDiligenceFlag)?item.WfModel.dueDiligence.overallDueDiligenceFlag:null;
							$scope.accountFlagInfo.overallDueDiligenceSummary = (item.WfModel.dueDiligence.overallDueDiligenceSummary)?item.WfModel.dueDiligence.overallDueDiligenceSummary:null;
							$scope.findings = (item.WfModel.dueDiligence.additionalFindings)?item.WfModel.dueDiligence.additionalFindings.findings:[];						
							angular.forEach($scope.findings, function(FindingValue, key) {
								 FindingValue.files = [];
								 angular.forEach(FindingValue.documents, function(value, key) {
									 if(value){
										dueDeligence.getFileInfo(localStorage.getItem("userId"), value ,'accountFlag').then(function(data){
											var fileObj = {
													id:data.value, 
													name:data.FileName, 
													downloadUrl: constants.FILE_DOWNLOAD+localStorage.getItem("userId")+ '-' + value +'-accountFlag'
												};
											 FindingValue.files.push(fileObj);
										}, function(data) {				
										
										});
										 
									 }

								});
							});
							//$scope.accountFlagInfo.documents = (item.WfModel.dueDiligence.additionalFindings)?item.WfModel.dueDiligence.additionalFindings.finding.documents[0]:null;

							/*==========WATCHLIST SCREENING START===========*/			
							$scope.watchlistScreeningInfo.watchListCheckCaseId = (item.WfModel.supplier.addresses[0])?item.WfModel.supplier.addresses[0].watchListCheckCaseId:'';
							$scope.watchlistScreeningInfo.watchListCheckStatus = (item.WfModel.supplier.addresses[0])?item.WfModel.supplier.addresses[0].watchListCheckStatus:'';
							$scope.watchlistScreeningInfo.watchlistCheckComment = (item.WfModel.supplier.addresses[0])?item.WfModel.supplier.addresses[0].watchListCheckComment:'';
							var watchListCheckScore = (item.WfModel.supplier.addresses[0])?item.WfModel.supplier.addresses[0].watchListCheckScore:'';
							
							if(!$scope.watchlistScreeningInfo.watchListCheckStatus) {
								$scope.watchlistScreeningInfo.watchListCheckStatus = scoreCalculation(watchListCheckScore);							
							}				
							/*==========WATCHLIST SCREENING END===========*/
							
							
							/*==========ADVERSE MEDIA RESEARCH START===========*/
							/*
								 $scope.AdverseMediaResearchInfo.summary=(item.WfModel.dueDiligence.entityAdverseMediaResearch)?item.WfModel.dueDiligence.entityAdverseMediaResearch.articles[0].summary:'' ;
								 $scope.AdverseMediaResearchInfo.category= (item.WfModel.dueDiligence.entityAdverseMediaResearch)?parseInt(item.WfModel.dueDiligence.entityAdverseMediaResearch.articles[0].category):'' ;
								 $scope.AdverseMediaResearchInfo.websites= (item.WfModel.dueDiligence.entityAdverseMediaResearch)?item.WfModel.dueDiligence.entityAdverseMediaResearch.articles[0].websites:'' ;
								 $scope.AdverseMediaResearchInfo.adverseMedia= (item.WfModel.dueDiligence.entityAdverseMediaResearch)?item.WfModel.dueDiligence.entityAdverseMediaResearch.articles[0].documents[0]:'' ;
							 */
							 $scope.negativeNewsArticles = (item.WfModel.dueDiligence.entityAdverseMediaResearch)?item.WfModel.dueDiligence.entityAdverseMediaResearch.articles:[{}] ;
							 angular.forEach($scope.negativeNewsArticles, function(ArticleValue, key) {
								 ArticleValue.files = [];
								 angular.forEach(ArticleValue.documents, function(value, key) {
									 if(value){
										dueDeligence.getFileInfo(localStorage.getItem("userId"), value ,'AdverseMediaResearchInfo').then(function(data){
											var fileObj = {
													id:data.value, 
													name:data.FileName, 
													downloadUrl: constants.FILE_DOWNLOAD+localStorage.getItem("userId")+ '-' + value +'-AdverseMediaResearchInfo'
												};
											 ArticleValue.files.push(fileObj);
										}, function(data) {				
										
										});
										 
									 }

								});
							});
							
							/*==========ADVERSE MEDIA RESEARCH ENDS===========*/
							 
							 
							 
							 /*=========BANK SCREENING START==========*/
							 $scope.bankScreeningInfo.watchListCheckCaseId = (item.WfModel.supplier.banks[0])?item.WfModel.supplier.banks[0].partyBankInfo.watchListCheckCaseId:'';
							 $scope.bankScreeningInfo.watchListCheckStatus = (item.WfModel.supplier.banks[0])?item.WfModel.supplier.banks[0].watchListCheckStatus:'';
							 $scope.bankScreeningInfo.watchlistCheckComment = (item.WfModel.supplier.banks[0])?item.WfModel.supplier.banks[0].watchListCheckComment:'';	 
							 var watchListCheckScore = (item.WfModel.supplier.banks[0])?item.WfModel.supplier.banks[0].watchListCheckScore:'';	 			 			 
								if(!$scope.bankScreeningInfo.watchListCheckStatus) {
									$scope.bankScreeningInfo.watchListCheckStatus = scoreCalculation(watchListCheckScore);								
								}			
							 /*=========BANK SCREENING ENDS==========*/
						
					
						
				}, function(data) {
					$scope.loader=false;
									
			});
				
			}
			
			
	}
	
	var scoreCalculation = function(watchListCheckScore) {
		
		if(!watchListCheckScore) {
			return 'FAIL';
		}
		
		if(watchListCheckScore > 85 ) {
			return 'FAIL';
		}
		
		if(watchListCheckScore < 85 ) {
			return 'PASS';
		}	

		return 'FAIL';
	}
	
	/**** add new supplier group button ****/
	// $scope.addNewSupplierGroup = function(supplierGroup){
	// 	$scope.loader = true;
	// 	if(supplierGroup == null || supplierGroup == undefined){
	// 		toaster.pop('error', "New Supplier Group", "Please Add New Supplier Group");
	// 		$scope.loader = false;
	// 		return;
	// 	}else{
	// 		var obj = {	
	// 			"name": supplierGroup.newSupplierGroup
	// 		};
	// 		dueDeligence.setTags(obj).then(function(){
	// 			supplierGroup.newSupplierGroup = null;
	// 			$scope.getTags();
	// 			$scope.loader = false;
	// 		}, function(data){
	// 			toaster.pop('error', "New Supplier Group", "server not responding");
	// 			$scope.loader = false;
	// 		});
	// 	}
	// }

	$scope.addNewSupplierGroup = {
        displayText: 'Select or add a new group',
        addText: '(New Group)',
        onAdd: function (text) {
            var newItem = {	
				"name": text
			};
            dueDeligence.setTags(newItem).then(function(data){
            	if(data.success == true){
            		$scope.entityVerificationInfo.supplierGroup = parseInt(data.data.id);
            	}
				$scope.getTags();
			}, function(data){
				toaster.pop('error', "New Supplier Group", "server not responding");
				$scope.loader = false;
			});
			
        }
    };

	// save button on entity verification screen
	$scope.saveEntityVerification = function(entityVerificationInfo, item, flag){
		$scope.loader=true;
		var tempFile = [];
		
		angular.forEach(entityVerificationInfo.files,function(value, key) {			
		    tempFile.push(value.id);
		});
		var obj = {
			"passed" : $scope.entityVerificationInfo.entityVerified,
			"source": $scope.entityVerificationInfo.source ,
			"comments": $scope.entityVerificationInfo.comments,
			"documents":tempFile
		}
		
		if(flag == 'reject'){
			obj.passed = false;
		}


		console.log(obj);		
		dueDeligence.setEntityVerification(obj, item.requestId).then(function(data) {		
			$scope.loader=false;
			//toaster.pop('success', "Entity Verified", "Saved successfully");			
			WorkFlow.completeWorkflowById(item.DD_ENTITY_VERIFICATION_TASK_ID).then(function(data) {	
				//toaster.pop('success', "WorkFlow Completed successfully");
				item.disableButtonEntity = true;
				// Disable all tabs
				if(flag == 'reject') {	
					$state.reload();
					/*	
					angular.forEach($scope.requests, function(value, key) {
						if(item.requestId == value.requestId) {
							value.DD_ACCOUNT_FLAG = false;
							value.DD_REFERENCES = false;
							value.DD_SPIRIT_AND_LETTER = false;
							value.DD_OWNER_MEDIA_RESEARCH = false;
							value.DD_OWNER_INFO = false;
							value.DD_BANK_WATCHLIST_REVIEW = false;
							value.BANK_WATCHLIST_REVIEW = false;
							value.ENTITY_MEDIA_RESEARCH = false;
							value.DD_SITE_WATCHLIST_REVIEW = false;
							value.DD_ENTITY_VERIFICATION = false;
							value.DD_ENTITY_MEDIA_RESEARCH = false;							
						}
					});
					*/
				}
			}, function(data) {
				toaster.pop('error', "Entity API failling !");
			});	
		}, function(data) {
			toaster.pop('error', "Complete WorkFlow API failling !");
			$scope.loader=false;
		});
	}

	$scope.saveWatchlistScreening = function(watchlistScreeningInfo, item){
		$scope.loader=true;
		console.log(item.DD_SITE_WATCHLIST_REVIEW_INTERNAL_ID);
		var obj = [{
			//"internalId" : item.linkedInternalId,
			"internalId" : item.DD_SITE_WATCHLIST_REVIEW_INTERNAL_ID,
			"watchListCheckStatus": $scope.watchlistScreeningInfo.watchListCheckStatus ,
			"watchListCheckComment": $scope.watchlistScreeningInfo.watchlistCheckComment
		}]
		console.log(obj);		
		dueDeligence.setWatchlistScreening(obj, item.requestId).then(function(data) {
			$scope.loader=false;		
			//toaster.pop('success', "Watchlist Screening", "Saved successfully");
			WorkFlow.completeWorkflowById(item.DD_SITE_WATCHLIST_REVIEW_TASK_ID).then(function(data) {	
				//toaster.pop('success', "WorkFlow Completed successfully");
				item.disableButtonWatchlist = true;
			}, function(data) {
				toaster.pop('error', "Complete WorkFlow API failling !");
			});	
		}, function(data) {
			$scope.loader=false;
			toaster.pop('error', "Watchlist Screening API failling !");
		});
	}

	$scope.saveAdverseMediaResearch = function(obj, item){
		$scope.loader=true;

		angular.forEach(obj,function(objValue, objKey) {			
		    //tempFile.push(value.id);
			objValue.documents = [];
			angular.forEach(objValue.files,function(fileValue, fileKey) {
				
				objValue.documents.push(fileValue.id);
			})			
		});
		
		dueDeligence.setAdverseMediaResearch(obj, item.requestId).then(function(data) {
			$scope.loader=false;		
			//toaster.pop('success', "Adverse Media Research", "Saved successfully");
			WorkFlow.completeWorkflowById(item.DD_ENTITY_MEDIA_RESEARCH_TASK_ID).then(function(data) {	
				//toaster.pop('success', "WorkFlow Completed successfully");
				item.disableButtonAdversMedia = true;
			}, function(data) {
				toaster.pop('error', "Complete WorkFlow API failling !");
			});	
		}, function(data) {
			$scope.loader=false;
			toaster.pop('error', "Adverse Media Research API failling !");
		});
	}

	$scope.saveBankScreening = function(bankScreeningInfo, item){
		$scope.loader=true;
		var obj = [{
			//"internalId" : item.linkedInternalId,
			"internalId" : item.DD_BANK_WATCHLIST_REVIEW_INTERNAL_ID,
			"watchListCheckStatus": $scope.bankScreeningInfo.watchListCheckStatus ,
			"watchListCheckComment": $scope.bankScreeningInfo.watchlistCheckComment
		}]
		console.log(obj);		
		dueDeligence.setBankScreening(obj, item.requestId).then(function(data) {
			$scope.loader=false;		
			//toaster.pop('success', "Bank Screening", "Saved successfully");
			WorkFlow.completeWorkflowById(item.DD_BANK_WATCHLIST_REVIEW_TASK_ID).then(function(data) {	
				//toaster.pop('success', "WorkFlow Completed successfully");
				item.disableButtonBank = true;
			}, function(data) {
				toaster.pop('error', "Complete WorkFlow API failling !");
			});	
		}, function(data) {
			$scope.loader=false;
			toaster.pop('error', "Bank Screening API failling !");
		});
	}

	$scope.saveOwnerOfficer = function(ownerOfficerInfo, item){
		$scope.loader=true;
		if(ownerOfficerInfo.name == null && ownerOfficerInfo.residentCountry == null){
			toaster.pop('error','Required Field', "Please provide name and country");
			$scope.loader=false;
			return;
		}
		if(ownerOfficerInfo.watchListCheckCaseId == null || ownerOfficerInfo.watchListCheckCaseId == "" || ownerOfficerInfo.watchListCheckCaseId == undefined){
			toaster.pop('error','Bridger ID Number Required', "Please run watchlist");
			$scope.loader=false;
			return;
		}else{
			var obj = [
				{
					//"internalId" : item.linkedInternalId,
					"internalId" : item.DD_OWNER_INFO_INTERNAL_ID,
					"name": $scope.ownerOfficerInfo.name,
					"title": $scope.ownerOfficerInfo.title,
					"ownershipInterest": $scope.ownerOfficerInfo.ownershipInterest,
					"residentCountry": $scope.ownerOfficerInfo.residentCountry,
					"watchListCheckStatus": $scope.ownerOfficerInfo.watchListCheckStatus,
					"watchListCheckCaseId": $scope.ownerOfficerInfo.watchListCheckCaseId,
					"watchListCheckDate": $rootScope.watchListCheckDate,
					"watchListCheckComment": $scope.ownerOfficerInfo.watchlistCheckComment
				}
			]
			
			console.log(obj);		
			dueDeligence.setOwnerOfficer(obj, item.requestId).then(function(data) {
				$scope.loader=false;		
				//toaster.pop('success', "Owner Officer", "Saved successfully");
				WorkFlow.completeWorkflowById(item.DD_OWNER_INFO_TASK_ID).then(function(data) {	
					//toaster.pop('success', "WorkFlow Completed successfully");
					if($scope.enableButton == true){
						item.disableButtonOwner = false;
					}else{
						item.disableButtonOwner = true;
					}
					
				}, function(data) {
					toaster.pop('error', "Complete WorkFlow API failling !");
				});	
			}, function(data) {
				$scope.loader=false;
				toaster.pop('error', "Owner Officer API failling !");
			});
		}
	}

	$scope.saveOwnerOfficerAdverseMedia = function(obj, item){
		$scope.loader=true;
		//var obj = $scope.negativeNewsArticlesOwner;
		angular.forEach(obj,function(objValue, objKey) {			
		    //tempFile.push(value.id);
			objValue.documents = [];
			angular.forEach(objValue.files,function(fileValue, fileKey) {
				
				objValue.documents.push(fileValue.id);
			})
			delete objValue.files;
		});
		
		dueDeligence.setOwnerOfficerAdverseMedia(obj, item.requestId).then(function(data) {
			$scope.loader=false;		
			//toaster.pop('success', "Owner Officer AdverseMedia ", "Saved successfully");
			WorkFlow.completeWorkflowById(item.DD_OWNER_MEDIA_RESEARCH_TASK_ID).then(function(data) {	
				
			}, function(data) {
				toaster.pop('error', "Complete WorkFlow API failling !");
			});	
		}, function(data) {
			$scope.loader=false;
			$scope.enableButton = true;
			toaster.pop('error', "Owner Officer AdverseMedia API failling !");
		});
	}

	$scope.saveSpiritLetter = function(spiritLetterInfo, item){
		$scope.loader=true;
		var tempFile = [];
		angular.forEach(spiritLetterInfo.files,function(value, key){			
		    tempFile.push(value.id);
		})
		var obj = {
			"dateOfTraining" : $scope.spiritLetterInfo.dateOfTraining,
			"acknowledgmentDate": $scope.spiritLetterInfo.acknowledgmentDate,
			"methodOfDelivery": $scope.spiritLetterInfo.methodOfDelivery,
			"documents": tempFile
		}
		console.log(obj);		
		dueDeligence.setSpiritLetter(obj, item.requestId).then(function(data) {
			$scope.loader=false;		
			//toaster.pop('success', "Spirit Letter", "Saved successfully");
			WorkFlow.completeWorkflowById(item.DD_SPIRIT_AND_LETTER_TASK_ID).then(function(data) {	
				//toaster.pop('success', "WorkFlow Completed successfully");
				item.disableButtonSpirit = true;
			}, function(data) {
				toaster.pop('error', "Complete WorkFlow API failling !");
			});
		}, function(data) {
			$scope.loader=false;
			toaster.pop('error', "Spirit Letter API failling !");
		});
	}

	$scope.saveReference = function(referenceInfo, commercialReferencesComment, item){
		$scope.loader=true;
		// var tempFile = [];
		angular.forEach(referenceInfo,function(objValue, objKey) {			
		    //tempFile.push(value.id);
			objValue.documents = [];
			angular.forEach(objValue.files,function(fileValue, fileKey) {
				
				objValue.documents.push(fileValue.id);
			})
			delete objValue.files;
		});
		var obj = {
			"commercialReferencesComment": commercialReferencesComment,
	      	"thirdPartyReports": referenceInfo 	
		}
		console.log(obj);		
		dueDeligence.setReference(obj, item.requestId).then(function(data) {
			$scope.loader=false;		
			//toaster.pop('success', "Reference", "Saved successfully");
			WorkFlow.completeWorkflowById(item.DD_REFERENCES_TASK_ID).then(function(data) {	
				//toaster.pop('success', "WorkFlow Completed successfully");
				item.disableButtonReference = true;
			}, function(data) {
				toaster.pop('error', "Complete WorkFlow API failling !");
			});
		}, function(data) {
			$scope.loader=false;
			toaster.pop('error', "Reference API failling !");
		});
	}

	$scope.saveAccountFlag = function(accountFlagInfo, item, findings){
		$scope.loader=true;
		
		angular.forEach(findings,function(objValue, objKey) {			
		    //tempFile.push(value.id);
			objValue.documents = [];
			angular.forEach(objValue.files,function(fileValue, fileKey) {
				
				objValue.documents.push(fileValue.id);
			})
			delete objValue.files;
		});
		
		var obj = {
			"overallDueDiligenceFlag" : $scope.accountFlagInfo.overallDueDiligenceFlag,
			"overallDueDiligenceSummary": $scope.accountFlagInfo.overallDueDiligenceSummary,
		   	"additionalFindings": {
		      	"findings": findings
		   	}
		}
		console.log(obj);		
		dueDeligence.setAccountFlag(obj, item.requestId).then(function(data) {
			$scope.loader=false;		
			//toaster.pop('success', "Account Flag", "Saved successfully");
			WorkFlow.completeWorkflowById(item.DD_ACCOUNT_FLAG_TASK_ID).then(function(data) {	
				//toaster.pop('success', "WorkFlow Completed successfully");
				item.disableButtonAccount = true;
			}, function(data) {
				toaster.pop('error', "Complete WorkFlow API failling !");
			});
		}, function(data) {
			$scope.loader=false;
			toaster.pop('error', "Account Flag API failling !");
		});
	}

	$scope.generatePdf = function(){
		swal({   
				title: "Do you want to generate a PDF?", 
				// text: "You want to cancel the task ?",  
				type: "info", 
				showCancelButton: true, 
				confirmButtonColor: "#8cc63f",
				confirmButtonText: "Yes", 
				cancelButtonText: "No", 
				closeOnConfirm: false,
				closeOnCancel: true 
			},
			function(isConfirm){ 
				if (isConfirm) { 
					swal("Generated!", "Pdf generation completed.", "success");
				}else{} 
			}
		)
	}

	$scope.negativeNewsArticles =[];
	$scope.negativeNewsArticles.push({"documents": []});
	$scope.addNegativeNewsArticles = function(){
	    $scope.negativeNewsArticles.push({"documents": []});
	}

	$scope.delNegativeNewsArticles = function(item){
	    var index = $scope.negativeNewsArticles.indexOf(item);
        $scope.negativeNewsArticles.splice(index, 1);
	}
	
	$scope.negativeNewsArticlesOwner =[];
	$scope.negativeNewsArticlesOwner.push({"documents": []});
	$scope.addNegativeNewsArticlesOwner = function(){
	    $scope.negativeNewsArticlesOwner.push({"documents": []});
	}

	$scope.delNegativeNewsArticlesOwner = function(item){
	    var index = $scope.negativeNewsArticlesOwner.indexOf(item);
        $scope.negativeNewsArticlesOwner.splice(index, 1);
	}

	$scope.reports=[];
	$scope.reports.push({"documents": []});
	$scope.addReport = function(){
		$scope.reports.push({"documents": []});
	}
	$scope.delReport = function(item){
		var index = $scope.reports.indexOf(item);
	    $scope.reports.splice(index,1);
	}
	$scope.findings=[];
	$scope.AddadditionalFindings = function(){
		if ($scope.findings) {
	      	$scope.findings.push({"documents": []});
	    }
	}
	$scope.delAdditionalFindings = function(item){
		var index = $scope.findings.indexOf(item);
	    $scope.findings.splice(index,1);
	}
	$scope.runWatchlist = function(ownerOfficerInfo){
		if(ownerOfficerInfo.name == null && ownerOfficerInfo.residentCountry == null){
			toaster.pop('error','Required Field', "Please provide name and country");
			return;
		}else{
			$scope.loader=true;
			var checkModeObj = {
			  	"individual" : true, 
			  	"asp":$scope.isASP, 
			  	"riskLevel": $scope.riskLevel
			}
			getCheckMode(checkModeObj);
			supplier.getCountryById(ownerOfficerInfo.residentCountry).then(function(data){
	    		$scope.CountryName = data.name;
	    		var obj ={
	    			"checkMode": $scope.checkMode,
					"individualCheckDtoList":[
					   {
					    "country": $scope.CountryName,
					    "entityType": "INDIVIDUAL",
					    "internalId": "123",
					    "name": $scope.ownerOfficerInfo.name
					   }
					]
				}
				dueDeligence.runWatchlist(obj).then(function(data){
					$scope.runWatchlistData = data.data;
					if($scope.runWatchlistData != null){
						$scope.ownerOfficerInfo.watchListCheckCaseId = $scope.runWatchlistData[0].watchListCaseId;
						$rootScope.watchListCheckDate = $scope.runWatchlistData[0].watchListCheckDate;
						if($scope.runWatchlistData[0].positiveCheck == false){
							$scope.ownerOfficerInfo.watchListCheckStatus = "PASS";
							$scope.loader=false;
						}else{
							$scope.ownerOfficerInfo.watchListCheckStatus = "FAIL";
							$scope.loader=false;
						}
					}else{
						$scope.loader=false;
						toaster.pop('error','Response not Valid', "Please try again");
					}	
				},function(data){
					$scope.loader=false;
				})
	    	}, function(data){
	    		$scope.loader=false;
	    	});	
		}
		
	}

	var getCheckMode = function(checkModeObj){
		dueDeligence.getCheckMode(checkModeObj).then(function(data){
			$scope.checkMode = data.data;
		})
	};
	/************ Document Upload ********/

	$scope.eventId = "";
	$scope.getCurrentIdFound = "";
	$scope.fileDownload_entityVerified=false;
	var eventIdTrack;
	var currentId;
	
    $scope.setFiles = function(element, files, obj) {
		
		
		var getElementId=element.id.split('_');
		var index = getElementId[1];
		
		$scope.eventId = files; 
		/*
	    $scope.$apply(function($scope) {
			$scope[files+index] = ($scope[files+index])?$scope[files+index]:[];
			for (var i = 0; i < element.files.length; i++) {
			  //$scope[files].push(element.files[i]);
			  $scope[files+index].push(element.files[i]);
			  uploadFileSend($scope[files+index][$scope[files+index].length-1]); 
			}			
		});*/
		if(index == '') {
			$scope.$apply(function($scope) {
				$scope[obj].files = ($scope[obj].files)?$scope[obj].files:[];
				for (var i = 0; i < element.files.length; i++) {
				  //$scope[files].push(element.files[i]);
				  $scope[obj].files.push(element.files[i]);
				  uploadFileSend($scope[obj].files[$scope[obj].files.length-1]); 
				}			
			});
			
		} else {
			
			$scope.$apply(function($scope) {
				$scope[obj][index].files = ($scope[obj][index].files)?$scope[obj][index].files:[];
				for (var i = 0; i < element.files.length; i++) {
				  //$scope[files].push(element.files[i]);
				  $scope[obj][index].files.push(element.files[i]);
				  uploadFileSend($scope[obj][index].files[$scope[obj][index].files.length-1]); 
				}			
			});
			
		}

	
    };
	
	function uploadFileSend(file){
		//// TODO - REMOVE This
		//localStorage.setItem("userId", 111);///
		$scope.loader=true; 
		console.log("supplierApiUrl",constants.SUPPLIER_API_URL);
		console.log("file",file);
	    $($scope.getCurrentIdFound).css("background-color","#eaf1f8");
		$scope.preloader=true;
		$scope.fileName=file.name;
		var formData = new FormData();
		formData.append('file', file);
		formData.append('SUPPLIERID', localStorage.getItem("userId"));
		formData.append('docType', $scope.eventId);
		
		console.log("formData",formData)
		 var req = {
					method : 'POST',
					url :constants.FILE_UPLOAD_MULTIPLE,
					transformRequest: angular.identity,
					headers : {
						'Content-Type': undefined,
						'Authorization' : WorkFlow.getCookieVal()
					},
					    data: formData,
					    cache: false,
					    contentType: false,
					    processData: false
				};
				$http(req).then(function(data) {
					 $scope.loader=false;
			
			
					file.downloadUrl = constants.FILE_DOWNLOAD+localStorage.getItem("userId")+ '-' + data.data[0].fileId +'-'+data.data[0].docType;
					file.id = data.data[0].fileId;
					/*
					var divAttribute;
					var downloadUrl;
					var userId=localStorage.getItem("userId");					
					$scope.getCurrentIdFound = "";
					$scope.eventId = "";
					$scope.preloader=false;
					var pJson=data.data;
					var finalUrlData=pJson.key;
					var dataFile=finalUrlData.split('/');
					var docName=data.data.docType;
                    var specificFileName=dataFile[3];
                    $scope.loader=false;
					toaster.pop('success', "Document Upload", "Document had been uploaded successfully");
					if(dataFile[1]=="entityVerified"){
						$scope.fileDownload_entityVerified=true;
						$scope.entityVerifiedFileName=dataFile[3];
						downloadUrl=data.data.filePath;
						$scope.entityVerificationInfo.entityVerifiedDocName=$scope.entityVerifiedFileName;
						$scope.entityVerificationInfo.entityVerifiedPath=downloadUrl.split('/').pop();
						$scope.entityVerificationInfo.entityVerifiedDocId = $scope.entityVerificationInfo.entityVerifiedPath;
						//divAttribute = document.getElementById('downloadUrlForFile_entityVerified');
						//divAttribute.href = '/pc_document_management'+downloadUrl;
					} */
					// else if(dataFile[1]=="mediaResearch"){
					// 	$scope.fileDownload_TaxRegistration=true;						
					// 	$scope.fileNameTaxReg = dataFile[3];
					// 	downloadUrl=data.data.filePath;
					// 	$scope.supplierInfo.taxRegistrationDocPath=downloadUrl.split('/').pop();
					// 	$scope.supplierInfo.taxRegDocumentId=$scope.supplierInfo.taxRegistrationDocPath;
					// 	divAttribute = document.getElementById('downloadUrlForFile_TaxRegistration');
					// 	divAttribute.href = '/pc_document_management'+downloadUrl;
						
					// }
					// else if(dataFile[1]=="taxExempt"){
					// 	$scope.fileDownload_taxExempt=true;
					// 	$scope.fileNameTaxExempt = dataFile[3];
					// 	downloadUrl=data.data.filePath;
					// 	$scope.supplierInfo.taxExemptDocPath=downloadUrl.split('/').pop();
					// 	$scope.supplierInfo.exemptDocumentId=$scope.supplierInfo.taxExemptDocPath;
					// 	divAttribute = document.getElementById('downloadUrlForFile_taxExemptDoc');
					// 	divAttribute.href = '/pc_document_management'+downloadUrl;
					// }
					// else if(dataFile[1]=="VatDoc"){
					// 	$scope.fileDownload_VatDocument=true;
					// 	$scope.fileNameVat=dataFile[3];
					// 	downloadUrl=data.data.filePath;
					// 	$scope.supplierInfo.vatDocPath=downloadUrl.split('/').pop();
					// 	divAttribute = document.getElementById('downloadUrlForFile_VatDocument');
					// 	divAttribute.href = '/pc_document_management'+ downloadUrl;
					// }
					// else if(dataFile[1]=="CrossDownload"){
					// 	$scope.fileDownload_CrossDownload=true;
					// 	$scope.crossFileName=dataFile[3];
					// 	downloadUrl=data.data.filePath;
					// 	$scope.supplierInfo.vatDocPath=downloadUrl.split('/').pop();
					// 	divAttribute = document.getElementById('downloadUrlForFile_CrossDownload');
					// 	divAttribute.href = '/pc_document_management'+ downloadUrl;
					// }
				}, function() {
					$scope.loader=false;
					$scope.eventId = "";
					$scope.getCurrentIdFound = "";
					$scope.preloader=false;
					toaster.pop('error', "Document Upload", "server not responding");
				});
		
	}	


	/** pagination **/
    //$scope.sortingOrder = sortingOrder;
    $scope.reverse = false;
    $scope.filteredItems = [];
    $scope.groupedItems = [];
    $scope.itemsPerPage = 10;
    $scope.pagedItems = [];
    $scope.currentPage = 0;
	
	$scope.totalCount = 100; // TODO - get total count from backend
	
	//$scope.filteredItems = $scope.requests;
	
    // init the filtered items
	/*
    $scope.initPagination = function() {
        if ($scope.requests == undefined) {
            $scope.filteredItems = 0;
            $scope.noResult = true;
        } else {
            $scope.filteredItems = $scope.requests;
        }
        //$scope.currentPage = 0;
        // now group by pages
        $scope.groupToPages();
    };*/
	
	

    // calculate page in place
	/*
    $scope.groupToPages = function() {
        $scope.pagedItems = [];

        for (var i = 0; i < $scope.filteredItems.length; i++) {
            if (i % $scope.itemsPerPage === 0) {
                $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
            } else {
                $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
            }
        }
    }; */

    $scope.range = function(start, end) {
        var ret = [];
        if (!end) {
            end = start;
            start = 0;
        }
        for (var i = start; i < end; i++) {
            ret.push(i);
        }
        return ret;
    };

    $scope.prevPage = function() {
        if ($scope.currentPage > 0) {
            $scope.currentPage--;
        }
		console.log($scope.currentPage);
		var start=0;
		if($scope.currentPage>0){
			start = $scope.currentPage*10;
		}
		loadWorkFlowParser(start);
		
    };

    $scope.nextPage = function() {
        /*if ($scope.currentPage < $scope.pagedItems.length - 1) {
            $scope.currentPage++;
        } */
		 $scope.currentPage++;
		console.log($scope.currentPage);
		var start=0;
		if($scope.currentPage>0){
			start = $scope.currentPage*10;
		}
		loadWorkFlowParser(start);
    };

    $scope.setPage = function() {
        $scope.currentPage = this.n;
		console.log(this.n);
		var start=0;
		if($scope.currentPage>0){
			start = $scope.currentPage*10;
		}
		loadWorkFlowParser(start);
    };

    $scope.shortPages = function(total, current) {
        //console.log("total", total);
        ////console.log("current", current);
        //console.log("$scope.currentPage", $scope.currentPage);
        if (($scope.currentPage - 3) < current && current < ($scope.currentPage + 3)) {
            return true;
        }
        return false
    }
	
	$scope.viewMore= function() {
		loadWorkFlowParser(lastId);
	}
	

	
});
