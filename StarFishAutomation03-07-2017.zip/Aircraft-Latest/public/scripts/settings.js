 
 
 
$(document).ready(function () {
 $("#poc6IDclick").click(function(){
	
});
});
 