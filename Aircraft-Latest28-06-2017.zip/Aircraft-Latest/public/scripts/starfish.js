$(document).ready(function () {

	  var availableTags = [
      "Function1",
	  "Function2",
      "Function3"
	
     
    ];
    $( "#functionId" ).autocomplete({
      source: availableTags
    });
	
	
	
	$("#environmentId").change(function () {
		
		$("#schemaId").val('geagp_schema1');
	});
	
	 
 });