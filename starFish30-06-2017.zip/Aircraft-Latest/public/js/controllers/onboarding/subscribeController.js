
app.controller('subscribeController', function($scope,$stateParams, $filter, $http, $rootScope,$state,Auth,$timeout,toaster,constants,
		$cookies,$cookieStore,$location, WorkFlow, supplier) {	
	$scope.addPayTerm=false;
	$scope.addCommodity=false;
	$scope.paymentDefault=true;
	$scope.paytermOptionsByDefault=false;
	$scope.subscribeDetails={};
	$scope.supplierData ={};
	$scope.supplierInfo ={};
	$scope.panel ={};
	$scope.supplierDataNew ={};
	$scope.subscribeDetails=$stateParams;
	$scope.changePayTerm=true;
	$scope.applyPayTerm=false;
	$scope.showOthers = false;
//	$scope.addPayTerm=false;
	var WfModel = {};
	WorkFlow.getVariablesV2Subscribe().then(function(workflowData) {
		WfModel = workflowData.data;
		WfModel.supplier = (WfModel.supplier==null)?{}:WfModel.supplier;	
					
	},function(data){
		toaster.pop('error','No Request Id', "server  not responding ");
		$scope.loader=false;
	});
	
	
	  supplier.getCountryList().then(function(data) {
			$scope.chooseCountries = data;
		}, function() {
			toaster.pop('error', "Country list", "server not responding");
		});
		
	supplier.getCurrencyList().then(function(data) {
		$scope.currencyList=data;		
	}, function() {
		toaster.pop('error', "Currency list", "server not responding");
	});

   	supplier.getPhoneCodes().then(function(data){
		$scope.phoneCodesGeneral = data;
	}, function() {
		toaster.pop('error', "Phone list", "server not responding");
	});
	
//   	$scope.addPayTermFn=function(term){
//   		if(term.selected==true){
//   			debugger;
//   			$scope.subscription.paymentTermsId = term.id;
//   			
//   		}
//   	}
   	
	
	$scope.showPayTermDetails=function(){
		if($scope.businessNewLevelSave=="" || $scope.businessNewLevelSave==undefined){
        	toaster.pop('error','Business Levels Details Missing', "Please select All business levels");
        	$scope.loader=false;
        	$scope.paytermOptionsByDefault=false;
        	return;
        }
        if($scope.erpId=="" || $scope.erpId==undefined){
        	toaster.pop('error','Business Level4 Details Missing', "Please select ERP in businessLevel 4");
        	$scope.paytermOptionsByDefault=false;
        	$scope.loader=false;
        	return;
        }
        if($scope.erpId){
        	$scope.countryCode= $scope.addresses.legalentity[0].countryCode;			
			supplier.getDefaultPaymentTerms($scope.erpId, $scope.countryCode).then(function(data){
				if(data.changeable){
					$scope.showOthers = true;
				}
				$scope.defaultPaymentTermsData = data.paymentsTerms;
				$scope.paytermOptionsByDefault=true;
				debugger;
			});
			$scope.changePayTerm=false;
			$scope.applyPayTerm=true;
			$scope.addPayTerm=true;
			$scope.paytermOptions=false;
			$scope.paymentDefault=true;
        }
	}
	
	$scope.bankRuleUI = function (item) {
		item.showForm = false;
		item.failingCaseTrue = false;

        var ruleObj = {
            "request": {
                "isElectronicBanking": ($scope.notElectronic) ? ($scope.notElectronic) : true,
                "erpIds": [],
                "banks": [
                    {
                        "bankCountry": item.bankCountryCode,
                        "isUseFurtherCreditTo": (item.bankCreditDetails) ? (item.bankCreditDetails) : false,
                        "id": "123"
                    }
                ]
            }
        }
        supplier.getBankUIRule(ruleObj).then(function (data) {
            item.bankRule = data;			
        }, function () {
            toaster.pop('error', "Bank Rule", "server not responding");
        });

        // reset IBAN and AC number on change
        // $scope.supplierInfo.iban = undefined;
        // $scope.supplierInfo.maskedAccountNumber = undefined;		

    }
	
	$scope.getStateListForBankCountry = function (item) {
		item.stateBankLabel = 'State';                    
        item.stateBankList = '';
		
        angular.forEach($scope.chooseCountries, function (value, key) {
            if (value.id == item.country_name) {
                supplier.getStatesList(value.code).then(function (data) {
                    item.stateBankLabel = data[0].authorityName;                    
                    item.stateBankList = data[0].subdivisions;
                }, function () {
                    toaster.pop('error', "State", "server not responding");
                });
            }
        });


    }
	
   	var loadPayterms = function(supplierId) {
		$scope.panelPayterms = [];
	    supplier.getSupplierPayterms(supplierId).then(function(data) {			
			data= data.data;
			angular.forEach(data, function(value, key) {
				var temp = {};
				temp.id = value.id;
				supplier.getAllPaymentTermsById(value.id).then(function(payData) {
					temp.name = payData.name;
					$scope.mainPayterm=temp
					$scope.panelPayterms.push(temp);
				}, function() {
	        
				});
				// var idArray =  $filter('filter')(payData.paymentsTerms, {"id": value.id});
				// if(idArray[0]){
				// 	if(idArray[0].name){
				// 		temp.name = idArray[0].name;
				// 	}
				// }
				
			});
				
    	   
		}, function() {
	        
		});
   }

   
	
	$scope.notElectronic = false;
	$scope.panel.routingLabel = 'Bank Code';
	$scope.panel.routingTooltip = 'Bank Code';
	$scope.panel.accountTooltip = 'Please enter Account Number';
	$scope.setCurrency = function(item){
		//console.log(code);
		item.bankCurrency = "";
		$scope.loader=true;		
		supplier.getCountryById(item.bankCountryCode).then(function(data){			
			$scope.loader=false;
    		$scope.CountryCode = data.code
    		$scope.loader=true;
			
    		supplier.getCountryList($scope.CountryCode).then(function(data) {
			$scope.loader=false;
			//
				angular.forEach(data, function(value, key) {
					if(value.code === $scope.CountryCode){																	
						var idArray = $filter('filter')($scope.currencyList, {'currencyCode':value.currencyCode});						
						if(idArray[0].id){
							item.bankCurrency = idArray[0].id;	
						}
					}
				})	
			}, function() {
				$scope.loader=false;
				//toaster.pop('error', "Country list", "server not responding");
			});
    	}, function() {
    		$scope.loader=false;
			//toaster.pop('error', "Country list", "server not responding");
		});	
	}
	
	$scope.maskCredit = function (item) {
		
		if (item.bankCreditNumber.indexOf('*') == -1) {
            item.unmaskedBankCreditNumber = item.bankCreditNumber;
        }

        item.bankCreditNumber = item.bankCreditNumber.replace(/\d(?=\d{4})/g, "*");	
	}
	
	$scope.bankAccountCheck=function(item) {	
		var acnumber = item.maskedAccountNumber;		
		if(item.maskedAccountNumber.indexOf('*') == -1)
		{
			item.bankAccountNumber  = item.maskedAccountNumber;
		}
						
		item.maskedAccountNumber  = item.maskedAccountNumber.replace(/\d(?=\d{4})/g, "*");
	}
	
	$scope.setRoutingLabel = function(item) {		
		$scope.loader=true;
		supplier.getCountryById(item.bankCountryCode).then(function(data){
			$scope.loader=false;
    		$scope.CountryCode = data.code
    		$scope.loader=true;
    		supplier.getRoutingLabel($scope.CountryCode).then(function(data) {
				$scope.loader=false;
				if(data[0]){
					item.routingLabel = data[0].routingCode;				
					item.routingTooltip = data[0].definitionTxt;
					$scope.accountTooltip = data[0].accountFormatTooltip;
					if($scope.accountTooltip === null){
						item.accountTooltip = 'Please enter Account Number';	
					}
				}else {
					item.routingLabel = 'Bank Code';
					item.routingTooltip = 'Bank Code';
					item.accountTooltip = 'Please enter Account Number';				
				}
			}, function() {
				$scope.loader=false;
				toaster.pop('error', "Routing Label", "server not responding");
			});
    	}, function() {
			$scope.loader=false;
		});	
	}
	
	$scope.getStateListForAddressCountry=function(item){
		$scope.loader=true;
		if(item.addressCountryCode == undefined){
			item.stateList = [];
			item.stateLabel = "";
			$scope.loader=false;
			return;
		}else{
	    	angular.forEach($scope.chooseCountries, function(value, key) {
		    	if(value.id==item.addressCountryCode){
		        	supplier.getStatesList(value.code).then(function(data) {
		              item.stateLabel= data[0].authorityName;;
		              item.stateList=data[0].subdivisions;
		              $scope.loader=false;          
		        	}, function() {
		    			toaster.pop('error', "State", "server not responding");
		    			$scope.loader=false;
		    		});	
		    	}
		    });
		}
	}
	
	$scope.stateChange = function(item, states) {
		angular.forEach(states, function(value, index) {
		   if(value.id==item.stateId) {
			   
			  item.stateName = value.code; 
		   }
		});
	}
	
	
	$scope.cancelPayment = function () {
		$scope.showaddPayment = false;
		$scope.panel.bankSubmitted = false;
		$scope.panel.bankAccountName = '';
		$scope.panel.bankCreditNumber = '';
		$scope.panel.bankCreditName = '';
		$scope.panel.bankCreditBenName = '';
		$scope.panel.bankCountryCode = '';
		$scope.panel.bankName = '';
		$scope.panel.abaRouting = '';
		$scope.panel.maskedAccountNumber = '';
		$scope.panel.bankAccountNumber = '';
		$scope.panel.bankCurrency = '';
		$scope.panel.primaryAccount = '';
		$scope.panel.remittance = '';
		
		$scope.panel.showForm = false;
		$scope.panel.branch_information = '';
		$scope.panel.branch_information_alt = '';
		$scope.panel.institution_name = '';
		$scope.panel.institution_name_alt = '';
		$scope.panel.POBnumber = '';
		$scope.panel.address1 = '';
		$scope.panel.town_name = '';
		$scope.panel.country_name = '';
		$scope.panel.country_subdivision = '';
		$scope.panel.zip_code = '';
	}
	

		
	$scope.savePayment = function(panel, addBankForm) {
		
		panel.bankSubmitted = true;
		/*
		if(addBankForm.$invalid) {
				toaster.pop('error', "", "Please fill all mandatory fields");	
				return;
		} */
		
		var assocFlag = false;
		var linkAddresses= []
		angular.forEach($scope.addresses, function(address, key) {
			if(address.assocAddress) {
				linkAddresses.push(address.entityId);
				assocFlag = true;
			}
		});
		
		if(assocFlag == false) {						
			toaster.pop('error', "", "Please choose atleast one associate address for each bank");	
			return;
		}
		
		if($scope.notElectronic){
			
			if(panel.address1==''||panel.address1==undefined && panel.city=='' ||panel.city==undefined &&panel.addressCountryCode==''||panel.addressCountryCode==undefined){
				$('#noElectronicAddr1,#noElectronicCity,#noElectronicCountry,#noElectronicState,#noElectronicPost').addClass("invalid");
				toaster.pop('error', "", "Please fill all mandatory fields");	
				return;
			}
			
			var addObj=
			/*{
				 "partyId": $scope.supplierId,
				  "subscription": {
					 "subscriptionIds": [
						"string"
					  ]
					},
				  "partyId": $scope.supplierId,
				  "supplier": {
					"addresses": [*/
					  {
						"addressTypes":['REMITTANCE'],
						"location": {
						  "addressLine1": panel.address1,
						  "addressLine2": panel.address2,
						  "addressLine3": panel.address3,
						  "addressLine4": panel.address4,
						  "cityName": panel.city,
						  "postalCode": panel.postalCode,
						  "stateId": panel.stateId,
						  "countryId": panel.addressCountryCode,
						  "stateName": panel.stateName
						}
					  }
					/*]
				  }
				}*/
				console.log(addObj);
				
				WfModel.supplier.addresses = (WfModel.supplier.addresses)?WfModel.supplier.addresses:[];		
				WfModel.supplier.addresses.push(addObj);
				$scope.loader= true;
				WorkFlow.setVariablesV2Subscribe(WfModel).then(function(data) {					
					// $scope.loader=false;
					supplier.getRequestDetails($cookieStore.get("subscribeRequestId")).then(function(rDetails) {
						$scope.loader=false;							
						
						$scope.bankAccounts.push({
							"entityId": rDetails.data.supplier.addresses[0].internalId,
							"internalId": rDetails.data.supplier.addresses[0].internalId,
							"selected": true,
							"partyAccountName": 'REMITTANCE',
							"furtherCreditTo": {
							  "accountNumber": '',
							  "bankName": '',
							  "beneficiaryName": ''
							},
							"partyBankInfo": {
							   "bankCountry": '',
								"bankName": '',
								"bankLocalRoutingNumber": '',
								"accountNumber": '',
								"accountCurrencyId": '',
								"isPrimary": '',
								"remittanceEmailAddress": '',
								"addresses": linkAddresses
							},
							"useFurtherCreditTo": panel.bankCreditDetails
						});
						$scope.cancelPayment();
						$scope.bankChangedCheckBox();
						panel.address1 = "";
						panel.address2 = "";
						panel.address3 = "";
						panel.address4 = "";
						panel.city = "";
						panel.postalCode = "";
						panel.stateId = undefined
						panel.addressCountryCode = undefined;
						panel.stateName = undefined;
						$scope.notElectronic = false;
					}, function(data) {
						toaster.pop('error', "Some error happend", "server not responding");
						$scope.loader=false;
					});
				},function(data){
					toaster.pop('error', "server  not responding ");
					$scope.loader=false;
				});
				

				/*				
			   supplier.editCreateWorkflow("SUPPLIER_ADDRESS_ADD").then(function(wData) {
				   
				   if(wData.requestId){
					   WorkFlow.searchWorkflowSave(wData.requestId,addObj).then(function(data){
						   WorkFlow.completeWorkflowForSearchTab(wData.taskId).then(function(data){
							   $scope.loader=false;
							   
								supplier.getRequestDetails(wData.requestId).then(function(rDetails) {
									$scope.loader=false;							

									  
										$scope.bankAccounts.push({
											"entityId": rDetails.data.supplier.addresses[0].internalId,
											"internalId": rDetails.data.supplier.addresses[0].internalId,
											"partyAccountName": 'REMITTANCE',
											"furtherCreditTo": {
											  "accountNumber": '',
											  "bankName": '',
											  "beneficiaryName": ''
											},
											"partyBankInfo": {
											   "bankCountry": '',
												"bankName": '',
												"bankLocalRoutingNumber": '',
												"accountNumber": '',
												"accountCurrencyId": '',
												"isPrimary": '',
												"remittanceEmailAddress": '',
												"addresses": []
											},
											"useFurtherCreditTo": panel.bankCreditDetails
										});
										$scope.cancelPayment();
									  
								}, function(data) {
									toaster.pop('error', "Some error happend", "server not responding");
									$scope.loader=false;
								})
							   

						   }, function(data) {
								$scope.loader=false;
								toaster.pop('error', "WorkFlow Complete Api Fails", "Server not responding");
							});
					   }, function(data) {
						$scope.loader=false;
						toaster.pop('error', "WorkFlow Save Api Fails", "Server not responding");
					});
				   }
				}, function() {
					$scope.loader=false;
				});	*/				
			
		} else {
			
						
			var alertCurrencyPrimary = false;		
			angular.forEach($scope.bankAccounts, function (val2, index2) {					
					if (panel.primaryAccount==true && val2.partyBankInfo.isPrimary==true) {
						var currencyCode='';
						var idArray = $filter('filter')($scope.currencyList, {'id':panel.bankCurrency});						
						if(idArray[0].id){
							currencyCode = idArray[0].currencyCode;	
						}
						if(currencyCode == val2.partyBankInfo.accountCurrencyCode ) {						
							alertCurrencyPrimary = true;								
						}							
					}					
			});
			if (alertCurrencyPrimary) {
				toaster.pop('error', "", "You have already selected primary bank for this currency");
				return;
			}
			
			var regEx = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;			
			if(panel.remittance && !regEx.test(panel.remittance)){			
				//panel.invalidEmail = false;
				toaster.pop('error', "Please enter valid remittance email");
				return;
			}	
			
			var idArray = $filter('filter')($scope.chooseCountries, {'id': panel.bankCountryCode});		
			var countryCode = ''
			if(idArray[0].code){
				countryCode=idArray[0].code
			}
			
			
			panel.chinaCase = false;	
			// CHINA - diffrent case
			if(idArray[0].code == 'CN' && idArray[0].currencyCode == 'CNY' ){
				
				//if(!item.branch_information_alt){							
					panel.chinaCase = true;													
				//}
			}
			
			
			supplier.AccountNumberFormat(panel.bankAccountNumber, countryCode).then(function(data) {

				if (data.data == "true") {
					panel.acFormatValidation = true;
					supplier.LocalRoutingFormat(panel.abaRouting, countryCode).then(function(data) {

						if (data.data == "true") {
							panel.localRoutingValidation = true;
							
							if (panel.failingCaseTrue == false || panel.failingCaseTrue == null) {
									// SWIFT call on rule engine success
									supplier.abaNumberRouting(panel.abaRouting, countryCode).then(function(data) {
										//toaster.pop('success', $scope.routingLabel+" Format Valid", $scope.uiMessage);
										// $scope.loader=false;
										if (data) {

											supplier.getBranchInfo(panel.abaRouting, countryCode).then(function(data) {
												//panel.bankName = data.national_ids[0].institution_name;
										
												/*
												
												
												panel.bankName = data.institution_name;
												panel.addressLine1 = data.address.address_lines[0];
												panel.addressLine2 = data.address.address_lines[1];
												panel.addressLine3 = data.address.address_lines[2];
												panel.addressLine4 = data.address.address_lines[3];
												panel.bankCountryCode = data.address.country_code;
												panel.bankCountryName = data.address.country_name;
												panel.bankStateName = data.address.country_subdivision;
												panel.bankCityName = data.address.town_name;
												panel.bankBranchInformation = data.branch_information;																	
												save();*/
												
														panel.failingCaseTrue = false;
														if (data.length == 0) {
																if (panel.branch_information == null || panel.institution_name == null || item.address1 == null || item.town_name == null || item.country_subdivision == null || item.country_name == null) {
																	panel.showForm = true;
																	toaster.pop('error', "Mandatory Fields", "Please fill all the mandatory fields");
																	return;
																} else {
																	panel.bankName = panel.institution_name;
																	panel.addressLine1 = panel.address1;
																	panel.addressLine2 = panel.address2;
																	panel.addressLine3 = panel.address3;
																	panel.addressLine4 = panel.address4;
																	panel.bankCountryCode = panel.bankCountryCode;
																	panel.bankCountryName = panel.country_name;
																	panel.bankStateName = panel.country_subdivision;
																	panel.bankCityName = panel.town_name;
																	panel.bankBranchInformation = panel.branch_information;
																	panel.bankInstitutionName = panel.institution_name;
																	panel.bankpoBoxNumber = panel.POBnumber;

																}

															} else {
																panel.bankName = data.institution_name;
																panel.addressLine1 = data.address.address_lines[0];
																panel.addressLine2 = data.address.address_lines[1];
																panel.addressLine3 = data.address.address_lines[2];
																panel.addressLine4 = data.address.address_lines[3];
																panel.bankCountryCode = panel.bankCountryCode;
																panel.bankCountryName = data.address.country_name;
																panel.bankStateName = data.address.country_subdivision;
																panel.bankCityName = data.address.town_name;
																panel.bankBranchInformation = data.branch_information;
																panel.bankInstitutionName = data.institution_name;
																panel.bankpoBoxNumber = data.address.post_office_box;
																// Fill form with fields - if china
																if(panel.chinaCase && !panel.institution_name_alt ) {
																	alertFlag=true;
																	panel.showForm = true;
																	panel.branch_information_alt =  data.branch_information;
																	panel.institution_name_alt =  data.institution_name;
																	panel.address1 = data.address.address_lines[0];
																	panel.zip_code = data.address.post_code[0];
																	panel.town_name = data.address.town_name;
																	panel.POBnumber = data.address.post_office_box;
																	panel.country_name = panel.bankCountryCode;
																	$scope.getStateListForBankCountry(panel);																
																}
															}
															
															save();

											}, function(data) {
												$scope.loader = false;
												panel.failCounter++;
												if(panel.failCounter>=2) {
													panel.showForm = true;
													panel.failingCaseTrue = true;
												}
												
												if (data.httpStatusCode == 404) {
													$scope.uiMessage = data.uiMessage;
													toaster.pop('error', panel.routingLabel + " Format Valid", $scope.uiMessage);
													$scope.loader = false;
													return;
												}

												
											});
											$scope.loader = false;
										}
									}, function(data) {
										$scope.loader = false;
										panel.failCounter++;
										if(panel.failCounter>=2) {
											panel.showForm = true;
											panel.failingCaseTrue = true;
										}
										if (data.httpStatusCode == 404) {
											$scope.uiMessage = data.uiMessage;
											toaster.pop('error', panel.routingLabel + " Format Valid", $scope.uiMessage);
											
											return;
										}
									});
							} else {
								
									/*

																								
											var obj = {
													partyAccountName: value.bankAccountName,
													partyAccountNameAlt: null,
													partyBankInfo: {
														//institutionName: value.bankInstitutionName,
														bankNameAlt: value.institution_name_alt,
														branchNameAlt: value.branch_information_alt ,
														bankCountryCode: value.bankCountryCode,
														bankCountryName: value.bankCountryName,
														bankLocalRoutingNumber: value.abaRouting,
														accountNumber: value.bankAccountNumber,
														accountCurrencyId: value.bankCurrency,
														iban: value.iban,
														swift: value.swift,
														isPrimary: value.primary,
														remittanceEmailAddress: value.remittance,
														addresses: [],
														//branchInformation: value.bankBranchInformation,
														branchName: value.branch_information,
														bankAddress: {
															"countryId": value.bankCountryCode,
															"stateId": value.country_subdivision,
															"stateName": null,
															"cityName": value.town_name,
															"provinceName": value.bankStateName,
															"postalCode": value.zip_code,
															"addressLine1": value.address1,
															"addressLine2": value.address2,
															"addressLine3": value.address3,
															"addressLine4": value.address4,
															"poBoxNumber": value.POBnumber
														},
														bankName: value.institution_name
																//bankName: 'BANK OF AMERICA N.A.'
													},
													useFurtherCreditTo: value.bankCreditDetails,
													furtherCreditTo: {
														bankName: value.bankCreditName,
														accountNumber: value.bankCreditNumber,
														beneficiaryName: value.bankCreditBenName
													}
											}; */
											
											panel.addressLine1 = panel.address1;
											panel.addressLine2 = panel.address2;
											panel.addressLine3 = panel.address3;
											panel.addressLine4 = panel.address4;
											
											save();
											
						
									
								
							}



						} else {

							$scope.loader = false;
							item.localRoutingValidation = false;

							toaster.pop('error', item.routingLabel + "Format is not Valid", data.statusMessage);
							return;
						}

					});

				} else {
					alertFlag = true;
					$scope.loader = false;
					item.acFormatValidation = false;
					toaster.pop('error', "Account Number Format is not valid", data.statusMessage);
					return;
				}
			});
			
			
		}
	
	

		var save = function() {
			
					$scope.loader=true;
				
					   /*var obj = 
							  {
								"partyAccountName": panel.bankAccountName,
								"furtherCreditTo": {
								  "accountNumber": panel.bankCreditNumber,
								  "bankName": panel.bankCreditName,
								  "beneficiaryName": panel.bankCreditBenName
								},
								"partyBankInfo": {
                                    "bankCountry": panel.bankCountryCode,                                    
                                    "bankLocalRoutingNumber": panel.abaRouting,
                                    "accountNumber": panel.bankAccountNumber,
                                    "accountCurrencyId": panel.bankCurrency,
                                    "isPrimary": panel.primaryAccount,
                                    "remittanceEmailAddress": panel.remittance,
                                    "addresses": linkAddresses,
									"bankName": panel.bankName,
									"branchInformation": panel.bankBranchInformation,
									"institutionName": panel.bankName,
									"bankAddress":{
										"countryId": panel.bankCountryCode,
										"stateId": null,
										"stateName": panel.bankStateName,
										"cityName": panel.bankCityName,
										"provinceName": panel.bankStateName,
										"postalCode": null,
										"addressLine1": panel.addressLine1,
										"addressLine2": panel.addressLine2,
										"addressLine3": panel.addressLine3,
										"addressLine4": panel.addressLine4,
										"poBoxNumber": null
									}
                                },
								"useFurtherCreditTo": panel.bankCreditDetails
							  }*/
							  
							  var obj = {
                                "partyAccountName": panel.bankAccountName,
								"partyAccountNameAlt": null,
                                "furtherCreditTo": {
                                    "accountNumber": panel.bankCreditNumber,
                                    "bankName": panel.bankCreditName,
                                    "beneficiaryName": panel.bankCreditBenName
                                },
                                "partyBankInfo": {
									bankNameAlt: panel.institution_name_alt,
									branchNameAlt: panel.branch_information_alt ,
                                    "bankCountry": panel.bankCountryCode,                                    
                                    "bankLocalRoutingNumber": panel.abaRouting,
                                    "accountNumber": panel.bankAccountNumber,
                                    "accountCurrencyId": panel.bankCurrency,
                                    "isPrimary": panel.primaryAccount,
									"iban": panel.iban,
									"swift": panel.swift,
                                    "remittanceEmailAddress": panel.remittance,
                                    "addresses": linkAddresses,
									"bankName": panel.institution_name,
									//"branchInformation": panel.bankBranchInformation,
									//"institutionName": panel.bankName,
									"bankAddress":{
										"countryId": panel.bankCountryCode,
										"stateId": panel.country_subdivision,
										"stateName": panel.bankStateName,
										"cityName": panel.bankCityName,
										"provinceName": panel.bankStateName,
										"postalCode": panel.zip_code,
										"addressLine1": panel.addressLine1,
										"addressLine2": panel.addressLine2,
										"addressLine3": panel.addressLine3,
										"addressLine4": panel.addressLine4,
										"poBoxNumber": panel.POBnumber
									}
                                },
                                "useFurtherCreditTo": panel.bankCreditDetails
                            }
				
							  
						if(!panel.bankCreditDetails) {
							obj.furtherCreditTo = null;
						}
						

							 			
						
						
						
						WfModel.supplier.banks = (WfModel.supplier.banks)?WfModel.supplier.banks:[];		
						WfModel.supplier.banks.push(obj);		

						WorkFlow.setVariablesV2Subscribe(WfModel).then(function(data) {					
							// $scope.loader=false;
							supplier.getRequestDetails($cookieStore.get("subscribeRequestId")).then(function(rDetails) {
								$scope.loader=false;							
								
								$scope.bankAccounts.push({
									"entityId": rDetails.data.supplier.banks[0].internalId,
									"internalId": rDetails.data.supplier.banks[0].internalId,
									"selected": true,
									"partyAccountName": panel.bankAccountName,
									"furtherCreditTo": {
									  "accountNumber": panel.bankCreditNumber,
									  "bankName": panel.bankCreditName,
									  "beneficiaryName": panel.bankCreditBenName
									},
									"partyBankInfo": {
										"bankAddress":{
	            							"countryId": panel.bankCountryCode
	          							},
									   "bankCountry": panel.bankCountryCode,
										"bankName": panel.bankName,
										"bankLocalRoutingNumber": panel.abaRouting,
										"accountNumber": panel.bankAccountNumber,
										"accountCurrencyId": panel.bankCurrency,
										"isPrimary": panel.primaryAccount,
										"remittanceEmailAddress": panel.remittance,
										"addresses": linkAddresses
									},
									"useFurtherCreditTo": panel.bankCreditDetails
								});
								$scope.cancelPayment();
								$scope.bankChangedCheckBox();

							
						},function(data){
							toaster.pop('error', "server  not responding ");
							$scope.loader=false;
						});
					},function(data){
							toaster.pop('error', "server  not responding ");
							$scope.loader=false;
						});
						
						/*
					
				$scope.loader=true;
				supplier.editCreateWorkflow("SUPPLIER_BANK_ADD").then(function(data) {
				  $scope.loader=false;
				   if(data){
					   //data.instanceId;			  
					   //data.requestId;			  
					   //data.taskId;
					   
					   var obj = {
						   /*
						  "partyId": $scope.supplierId,
						  "subscription": {
							 "subscriptionIds": []
							},*/
						 /* "partyId": $scope.supplierId,
						  "supplier": {
							"banks": [
							  {
								"partyAccountName": panel.bankAccountName,
								"furtherCreditTo": {
								  "accountNumber": panel.bankCreditNumber,
								  "bankName": panel.bankCreditName,
								  "beneficiaryName": panel.bankCreditBenName
								},
								"partyBankInfo": {
								   "bankCountry": panel.bankCountryCode,
									"bankName": panel.bankName,
									"bankLocalRoutingNumber": panel.abaRouting,
									"accountNumber": panel.bankAccountNumber,
									"accountCurrencyId": panel.bankCurrency,
									"isPrimary": panel.primaryAccount,
									"remittanceEmailAddress": panel.remittance,
									"addresses": [
									  
									]
								},
								"useFurtherCreditTo": panel.bankCreditDetails
							  }
							]
						  }
						}						
						
						
					   if(data.requestId){
						   WorkFlow.searchWorkflowSave(data.requestId,obj).then(function(saveData){
							   WorkFlow.completeWorkflowForSearchTab(data.taskId).then(function(cData){
								   $scope.loader=false;


								
								supplier.getRequestDetails(data.requestId).then(function(rDetails) {
										$scope.loader=false;
										$scope.bankAccounts.push({
											"entityId": rDetails.data.supplier.banks[0].internalId,
											"internalId": rDetails.data.supplier.banks[0].internalId,
											"partyAccountName": panel.bankAccountName,
											"furtherCreditTo": {
											  "accountNumber": panel.bankCreditNumber,
											  "bankName": panel.bankCreditName,
											  "beneficiaryName": panel.bankCreditBenName
											},
											"partyBankInfo": {
											   "bankCountry": panel.bankCountryCode,
												"bankName": panel.bankName,
												"bankLocalRoutingNumber": panel.abaRouting,
												"accountNumber": panel.bankAccountNumber,
												"accountCurrencyId": panel.bankCurrency,
												"isPrimary": panel.primaryAccount,
												"remittanceEmailAddress": panel.remittance,
												"addresses": []
											},
											"useFurtherCreditTo": panel.bankCreditDetails
										});
										$scope.cancelPayment();
									  
								}, function(data) {
									toaster.pop('error', "Some error happend", "server not responding");
									$scope.loader=false;
								})
								
							   }, function(data) {
									$scope.loader=false;
									toaster.pop('error', "WorkFlow Complete Api Fails", "Server not responding");
								});
						   }, function(data) {
							$scope.loader=false;
							toaster.pop('error', "WorkFlow Save Api Fails", "Server not responding");
						});
					   }
					  
				   }
				}, function() {
					$scope.loader=false;
				}); 
			*/
		}
		
	}
	
	$scope.getStateListForAddressCountryInAdd=function(item){
		$scope.loader=true;
		if(item == undefined){
			$scope.stateList = [];
			$scope.stateLabel ="";
			$scope.loader=false;
		}else{
			supplier.getStatesList(item).then(function(data) {
			  $scope.stateLabel= data[0].authorityName;;
			  $scope.stateList=data[0].subdivisions;
			  $scope.loader=false;          
			}, function() {
				toaster.pop('error', "State", "server not responding");
				$scope.loader=false;
			});	
		}
	}
	
	$scope.showRemittanceEmailSection = function(){
        if($scope.addressTypes.orderfulfilling == true){
            $scope.remittanceEmailSection = true;
        }else{
            $scope.remittanceEmailSection = false;
        }
    }

	$scope.addAddressBtnClick=function(panel,supplierData, form, addressTypes){
		panel.addressSubmitted = true;
		//$scope.loader=true;
		if(addressTypes ==undefined){
            toaster.pop('error', "Address Type", "Please check atleast one address Type");
            return;
        }
        if($scope.remittanceEmailSection){
            if(!supplierData.remittanceEmail){
                toaster.pop('error', "", "Please provide remittance email address");
                return;
            }
        }
		if(form.$invalid) {
			toaster.pop('error', "", "Please fill all mandatory fields");	
			return;
		}
		$scope.loader= true;
		$scope.searchAddressType = [];
        if(addressTypes.orderfulfilling == true){
            addressTypes.orderfulfilling = "ORDER_FULLFILLING";
            $scope.searchAddressType.push(addressTypes.orderfulfilling);
        }
        if(addressTypes.remittance == true){
            addressTypes.remittance = "REMITTANCE";
            $scope.searchAddressType.push(addressTypes.remittance);
        }
        if(addressTypes.manufacturing == true){
            addressTypes.manufacturing = "MANUFACTURING";
            $scope.searchAddressType.push(addressTypes.manufacturing);
        }
        if(addressTypes.alternateShip == true){
            addressTypes.alternateShip = "SHIP_FROM_ALT";
            $scope.searchAddressType.push(addressTypes.alternateShip);
        }
		if($scope.internalSupplierSubscribe){
			var addObj={
				"partyId": $scope.supplierId,
				"subscription": {
				    "bucId": $scope.bucId
				},
			  	"supplier": {
				    "addresses": [
					    {
					        "addressTypes":$scope.searchAddressType,
					        "location": {
					          	"addressLine1": supplierData.addAddressLine1,
					          	"addressLine2": supplierData.addAddressLine2,
					          	"addressLine3": supplierData.addAddressLine3,
					          	"addressLine4": supplierData.addAddressLine4,
					          	"cityName": supplierData.addCity,
					          	"postalCode": supplierData.addPostalCode,
					          	"stateId": supplierData.addState.id,
					          	"countryId": supplierData.addCountry,
					          	"stateName": supplierData.addState.subdivisionName
					        }
					    }
					]
				}   
		    }
		    WfModel = addObj;
		    WorkFlow.setVariablesV2Subscribe(WfModel).then(function(data){					
				// $scope.loader=false;
				supplier.getRequestDetails($cookieStore.get("subscribeRequestId")).then(function(rDetails) {
					$scope.loader=false;							
					var item = {
						"entityId": rDetails.data.supplier.addresses[0].internalId,
						"internalId": rDetails.data.supplier.addresses[0].internalId,
						"selected": true,
					  	"addressId" : null,							 
					  	"addressTypes" : [rDetails.data.supplier.addresses[0].addressTypes[0]],
					  	"location": {
						  	"addressLine1": supplierData.addAddressLine1,
						  	"addressLine2": supplierData.addAddressLine2,
						  	"addressLine3": supplierData.addAddressLine3,
						  	"addressLine4": supplierData.addAddressLine4,
						  	"cityName": supplierData.addCity,
						  	"postalCode": supplierData.addPostalCode,
						  	"stateId": supplierData.addState.id,
						  	"countryId": supplierData.addCountry,
						  	"stateName": supplierData.addState.subdivisionName
						},
						"bucId": rDetails.data.supplier.addresses[0].bucId,
						"blllingPersonName":$scope.blllingPersonName,
						"billingPersonSSO":$scope.billingPersonSSO,
						"companyCode":$scope.companyCode,
					 };
					  $scope.addresses.push(item);
					  $scope.cancelAddAddress();
					  $scope.addressSelected(item)
				}, function(data) {
					toaster.pop('error', "Some error happend", "server not responding");
					$scope.loader=false;
				});

				
			},function(data){
				toaster.pop('error', "server  not responding ");
				$scope.loader=false;
			});
		}else{
			var addObj={ 
			  	"partyId": $scope.supplierId,
			  	"supplier": {
				    "addresses": [
				      	{
					        "addressTypes":$scope.searchAddressType,
					        "location": {
					          	"addressLine1": supplierData.addAddressLine1,
					          	"addressLine2": supplierData.addAddressLine2,
					          	"addressLine3": supplierData.addAddressLine3,
					          	"addressLine4": supplierData.addAddressLine4,
					          	"cityName": supplierData.addCity,
					          	"postalCode": supplierData.addPostalCode,
					          	"stateId": supplierData.addState.id,
					          	"countryId": supplierData.addCountry,
					          	"stateName": supplierData.addState.subdivisionName
					        },
					        "emailForPurchaseOrders": supplierData.POemail,
                    		"emailForRemittance":supplierData.remittanceEmail
					    }
				   	]
			  	}
			}
			// WfModel.supplier.addresses = (WfModel.supplier.addresses)?WfModel.supplier.addresses:[];		
			// WfModel.supplier.addresses.push(addObj);
			WfModel = addObj;
		
			WorkFlow.setVariablesV2Subscribe(WfModel).then(function(data) {					
				// $scope.loader=false;
				supplier.getRequestDetails($cookieStore.get("subscribeRequestId")).then(function(rDetails) {
					$scope.loader=false;							
					var item = {
						"entityId": rDetails.data.supplier.addresses[0].internalId,
						"internalId": rDetails.data.supplier.addresses[0].internalId,
						"selected": true,
					  	"addressId" : null,							 
					  	"addressTypes" : $scope.searchAddressType,
					  	"location": {
						  	"addressLine1": supplierData.addAddressLine1,
						  	"addressLine2": supplierData.addAddressLine2,
						  	"addressLine3": supplierData.addAddressLine3,
						  	"addressLine4": supplierData.addAddressLine4,
						  	"cityName": supplierData.addCity,
						  	"postalCode": supplierData.addPostalCode,
						  	"stateId": supplierData.addState.id,
						  	"countryId": supplierData.addCountry,
						  	"stateName": supplierData.addState.subdivisionName
						}
					 };
					  $scope.addresses.push(item);
					  $scope.cancelAddAddress();
					  $scope.addressSelected(item)
				}, function(data) {
					toaster.pop('error', "Some error happend", "server not responding");
					$scope.loader=false;
				});	
			},function(data){
				toaster.pop('error', "server  not responding ");
				$scope.loader=false;
			});
		}
	/*	    
	   supplier.editCreateWorkflow("SUPPLIER_ADDRESS_ADD").then(function(wData) {
		   
		   if(wData.requestId){
			   WorkFlow.searchWorkflowSave(wData.requestId,addObj).then(function(data){
				   WorkFlow.completeWorkflowForSearchTab(wData.taskId).then(function(data){
						supplier.getRequestDetails(wData.requestId).then(function(rDetails) {
							$scope.loader=false;							
							
							$scope.addresses.push({
								"entityId": rDetails.data.supplier.addresses[0].internalId,
								"internalId": rDetails.data.supplier.addresses[0].internalId,
							  "addressId" : null,							 
							  "addressTypes" : [supplierData.multiSelectAddress],
							  "location": {
								  "addressLine1": supplierData.addAddressLine1,
								  "addressLine2": supplierData.addAddressLine2,
								  "addressLine3": supplierData.addAddressLine3,
								  "addressLine4": supplierData.addAddressLine4,
								  "cityName": supplierData.addCity,
								  "postalCode": supplierData.addPostalCode,
								  "stateId": supplierData.addState.id,
								  "countryId": supplierData.addCountry,
								  "stateName": supplierData.addState.subdivisionName
								}
							  });
							  $scope.cancelAddAddress();
						}, function(data) {
							toaster.pop('error', "Some error happend", "server not responding");
							$scope.loader=false;
						});
					   

				   }, function(data) {
						$scope.loader=false;
						toaster.pop('error', "WorkFlow Complete Api Fails", "Server not responding");
					});
			   }, function(data) {
				$scope.loader=false;
				toaster.pop('error', "WorkFlow Save Api Fails", "Server not responding");
			});
		   }
		}, function() {
			$scope.loader=false;
		}); 
	*/

	}
	
	$scope.cancelAddAddress = function() {
		$scope.showaddAddress = false;
		$scope.supplierData.addAddressLine1= '';
		$scope.supplierData.addAddressLine2= '';
		$scope.supplierData.addAddressLine3= '';
		$scope.supplierData.addAddressLine4= '';
		$scope.supplierData.addCity= '';
		$scope.supplierData.addPostalCode= '';
		$scope.supplierData.addState= {};
		$scope.supplierData.addCountry= '';
		$scope.supplierData.POemail ='';
		$scope.supplierData.remittanceEmail = '';
		$scope.panel.addressSubmitted= false;
	}
	
	
	$scope.addContactNew=function(panel,supplierData, form){

		panel.contactSubmitted = true;
		var regEx = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;			
		if(supplierData.contactEmail && !regEx.test(supplierData.contactEmail)) {						
					toaster.pop('error', "Please enter valid email");
					return;
		}

		if(form.$invalid) {
			toaster.pop('error', "", "Please fill all mandatory fields");	
			return;
		}
		if(!supplierData.businessCodeShortForContact) {
			toaster.pop('error', "", "Please fill business phone code");	
			return;
		}
//		$scope.loader=true;
		var addObj=/*{
				  "partyId": $scope.supplierIdInSearch,
				  "subscription": {
				     "subscriptionIds": [
				        "string"
				      ]
				    },
				  "supplier": {
				    "contacts": [*/
				      {
				        "businessPhoneCountryId": supplierData.businessCodeShortForContact,
				        "businessPhoneNumber": supplierData.contactBusinessPhoneNo,
				        "email": supplierData.contactEmail,
				        "firstName": supplierData.contactFirstName,
				        "lastName": supplierData.contactLastName,
				        "mobilePhoneCountryId": supplierData.mobileCodeShortForContact,
				        "mobilePhoneNumber": supplierData.contactMobilePhoneNo,
				        "contactType": supplierData.addContactTypeForContact
				      }
				    /*]
				  }
				}*/


		WfModel.supplier.contacts = (WfModel.supplier.contacts)?WfModel.supplier.contacts:[];		
		WfModel.supplier.contacts.push(addObj);	

		WorkFlow.setVariablesV2Subscribe(WfModel).then(function(data) {					
			// $scope.loader=false;
			supplier.getRequestDetails($cookieStore.get("subscribeRequestId")).then(function(rDetails) {
				$scope.loader=false;							
				
				$scope.contacts.push(
				{
					"entityId": rDetails.data.supplier.contacts[0].internalId,
					"internalId": rDetails.data.supplier.contacts[0].internalId,
					"selected": true,
					"businessPhoneCountryId": supplierData.businessCodeShortForContact,
					"businessPhoneNumber": supplierData.contactBusinessPhoneNo,
					"email": supplierData.contactEmail,
					"firstName": supplierData.contactFirstName,
					"lastName": supplierData.contactLastName,
					"mobilePhoneCountryId": supplierData.mobileCodeShortForContact,
					"mobilePhoneNumber": supplierData.contactMobilePhoneNo,
					"contactType": supplierData.addContactTypeForContact
				 });
				$scope.cancelContact();
				$scope.contactChangedCheckBox();
			}, function(data) {
				toaster.pop('error', "Some error happend", "server not responding");
				$scope.loader=false;
			});

			
		},function(data){
			toaster.pop('error', "server  not responding ");
			$scope.loader=false;
		});			
		
		/*
			var text= "SUPPLIER_CONTACT_ADD";
	       supplier.editCreateWorkflow(text).then(function(wData) {
	    	   $scope.taskId=wData.taskId;
	    	   if(wData.requestId){
	    		   WorkFlow.searchWorkflowSave(wData.requestId,addObj).then(function(data){
	    			   WorkFlow.completeWorkflowForSearchTab($scope.taskId).then(function(data){
							supplier.getRequestDetails(wData.requestId).then(function(rDetails) {
								$scope.loader=false;							

									$scope.contacts.push(
									{
										"entityId": rDetails.data.supplier.contacts[0].internalId,
										"internalId": rDetails.data.supplier.contacts[0].internalId,
										"businessPhoneCountryId": supplierData.businessCodeShortForContact,
										"businessPhoneNumber": supplierData.contactBusinessPhoneNo,
										"email": supplierData.contactEmail,
										"firstName": supplierData.contactFirstName,
										"lastName": supplierData.contactLastName,
										"mobilePhoneCountryId": supplierData.mobileCodeShortForContact,
										"mobilePhoneNumber": supplierData.contactMobilePhoneNo,
										"contactType": supplierData.addContactTypeForContact
									 });
									 $scope.cancelContact();
							}, function(data) {
								toaster.pop('error', "Some error happend", "server not responding");
								$scope.loader=false;
							});
	    		    	  

	    			   }, function(data) {
	    					$scope.loader=false;
	    					toaster.pop('error', "WorkFlow Complete Api Fails", "Server not responding");
	    				});
    			   }, function(data) {
   					$scope.loader=false;
   					toaster.pop('error', "WorkFlow Save Api Fails", "Server not responding");
   				});
	    	   }
		}, function() {
			$scope.loader=false;
		});  */
	}
	
	$scope.cancelContact = function() {
		$scope.showaddContact = false;
		$scope.supplierData.businessCodeShortForContact = '';
		$scope.supplierData.contactBusinessPhoneNo = '';
		$scope.supplierData.contactEmail = '';
		$scope.supplierData.contactFirstName = '';
		$scope.supplierData.contactLastName = '';
		$scope.supplierData.mobileCodeShortForContact = '';
		$scope.supplierData.contactMobilePhoneNo = '';
		$scope.supplierData.addContactTypeForContact = '';
	}

	
    
//	$cookieStore.put("roleForSubscribe", $stateParams.obj.rootType);
//	$cookieStore.put("supplierIdForSubscribe", $stateParams.obj.rootId);
	$scope.basicData =  $cookieStore.get("basicSubscribeDetailsForRow");
	var roleForSubscribe =  $cookieStore.get("roleForSubscribe");
	if(roleForSubscribe=="supplier"){
		if($scope.subscribeDetails.supplierSubscribingTo == "true"){
			$scope.externalSupplierSubscribe = true;
		}else{
			$scope.internalSupplierSubscribe = true;
		}
		$rootScope.businessTableList=[];
		$rootScope.businessList2="";
		$rootScope.businessList3="";
		$scope.businessNewLevelSave=[];
		$scope.addresses = {};
		supplier.getSupplierDetails($cookieStore.get("supplierIdForSubscribe")).then(function(data) {			
			$scope.dataDetails=data.data;
			$scope.supplierId=data.data.id;
			   loadPayterms($scope.supplierId);
			if($scope.supplierId!=""&&$scope.supplierId!=undefined){
				supplier.getCommodityListOnPayLoad($scope.supplierId).then(function(data) {
					$scope.commodityListOnPayLoad=[];
        			$scope.commodityListOnPayLoad = data.data
        		}, function() {
        			toaster.pop('error', "Commodities list", "server not responding");
        		});
        		
			}
			$scope.countryCode= data.data.countryCode;			
			// supplier.getDefaultPaymentTerms('', $scope.countryCode).then(function(data){
			// 	$scope.defaultPaymentTermsData = data.paymentsTerms;
			// 	debugger;
			// });
			$scope.supplierData.legalName=(data.data.legalName)?data.data.legalName:'';
			$scope.supplierData.supplierSpecialtyId = (data.data.supplierSpecialty)?data.data.supplierSpecialty:''
		    if(data.data.countryCode!=""||data.data.countryCode!=undefined){
		    	  angular.forEach($scope.chooseCountries, function(key, index) {
			    		if(key.code==data.data.countryCode){
			    			$scope.supplierData.countryCode = (key.name)?key.name:''
			    		}  
		    	  });
		    }
			$scope.supplierData.taxClassification = (data.data.taxClassification)?data.data.taxClassification:'';
	        $scope.bankAccounts=(data.data.bankAccounts)?data.data.bankAccounts:[];
	        $scope.contacts=(data.data.contacts)?data.data.contacts:[];
	        $scope.supplierInfoDiversity = (data.data.diversities)?data.data.diversities:[];
	        $scope.addresses=(data.data.addresses)?data.data.addresses:[];
	        $scope.buc=(data.data.buc)?data.data.buc:[];
	        $scope.rels=(data.data.rels)?data.data.rels:[];
	        angular.forEach($scope.addresses, function(address, index) {
	       
	            if (address.addressTypes.indexOf("LEGAL") != -1) {
	                if (!$scope.addresses.legalentity) {
	                    $scope.addresses.legalentity = [];
	                }
	                
	                angular.forEach($scope.chooseCountries, function(key, index) {
	                	if(key.id==address.location.countryCode){
	    	                supplier.getStatesList(key.code).then(function(data) {
	   	                	 angular.forEach(data.subdivisions, function(key, index) {
	   	                		 if(key.id==address.location.stateCode){
	   	                			 $scope.legalStateName=key.subdivisionName;
	   	                		 }
	   	                	 });
	   	        		}, function() {
	   	        			toaster.pop('error', "States list", "server not responding");
	   	        		});	
	                	}
	                });
	                
	                address.location.entityId= address.entityId;
	                $scope.addresses.legalentity.push(address.location);
	                
	            }
	            if (address.addressTypes.indexOf("ORDER_FULFILLMENT") != -1) {
	                if (!$scope.addresses.orderFulfilmentAddress) {
	                    $scope.addresses.orderFulfilmentAddress = [];
	                }

	                angular.forEach($scope.rels, function(rel, key){
	                	if(address.entityId == rel.child.entityId && rel.child.entityType === "ADDRESS"){
	                		//to do
	                		if(rel.parent.entityType === "BUC"){
	                			if(rel.parent.entityId == $scope.buc.entityId){
	                				address.blllingPersonName = $scope.buc.blllingPersonName;
	                				$scope.blllingPersonName = address.blllingPersonName;
	                				address.billingPersonSSO = $scope.buc.billingPersonSSO;
	                				$scope.billingPersonSSO = address.billingPersonSSO;
	                				address.companyCode = $scope.buc.companyCode;
	                				$scope.companyCode = address.companyCode;
	                				address.bucId = $scope.buc.entityId;
	                				$scope.bucId=address.bucId;

	                			}
	                			// angular.forEach($scope.buc, function(val, key){
	                			// 	if(rel.parent.entityId == key[val]){
	                			// 		$scope.addresses.push($scope.buc);
	                			// 	}
	                			// })
	                		}
	                	}
	                })
	                angular.forEach($scope.chooseCountries, function(key, index) {
	                	if(key.id==address.location.countryCode){
	    	                supplier.getStatesList(key.code).then(function(data) {
	   	                	 angular.forEach(data.subdivisions, function(key, index) {
	   	                		 if(key.id==address.location.stateCode){
	   	                			 $scope.orderStateName=key.subdivisionName;
	   	                		 }
	   	                	 });
	   	        		}, function() {
	   	        			toaster.pop('error', "States list", "server not responding");
	   	        		});	
	                	}
	                });
	                address.location.entityId= address.entityId;
	                $scope.addresses.orderFulfilmentAddress.push(address.location);
	            }
	            if (address.addressTypes.indexOf("MANUFACTURING") != -1) {
	                if (!$scope.addresses.manufacturingAddress) {
	                    $scope.addresses.manufacturingAddress = [];
	                }
	                angular.forEach($scope.chooseCountries, function(key, index) {
	                	if(key.id==address.location.countryCode){
	    	                supplier.getStatesList(key.code).then(function(data) {
	   	                	 angular.forEach(data.subdivisions, function(key, index) {
	   	                		 if(key.id==address.location.stateCode){
	   	                			 $scope.manuStateName=key.subdivisionName;
	   	                		 }
	   	                	 });
	   	        		}, function() {
	   	        			toaster.pop('error', "States list", "server not responding");
	   	        		});	
	                	}
	                });
	                address.location.entityId= address.entityId;
	                $scope.addresses.manufacturingAddress.push(address.location);
	            }
	            if (address.addressTypes.indexOf("SHIPPING") != -1) {
	                if (!$scope.addresses.shippingAddress) {
	                    $scope.addresses.shippingAddress = [];
	                }
	                angular.forEach($scope.chooseCountries, function(key, index) {
	                	if(key.id==address.location.countryCode){
	    	                supplier.getStatesList(key.code).then(function(data) {
	   	                	 angular.forEach(data.subdivisions, function(key, index) {
	   	                		 if(key.id==address.location.stateCode){
	   	                			 $scope.shipStateName=key.subdivisionName;
	   	                		 }
	   	                	 });
	   	        		}, function() {
	   	        			toaster.pop('error', "States list", "server not responding");
	   	        		});	
	                	}
	                });
	                address.location.entityId= address.entityId;
	                $scope.addresses.shippingAddress.push(address.location);
	            }
	            if (address.addressTypes.length==0) {
	                if (!$scope.addresses.addresswithNoType) {
	                    $scope.addresses.addresswithNoType = [];
	                }
	                angular.forEach($scope.chooseCountries, function(key, index) {
	                	if(key.id==address.location.countryCode){
	    	                supplier.getStatesList(key.code).then(function(data) {
	   	                	 angular.forEach(data.subdivisions, function(key, index) {
	   	                		 if(key.id==address.location.stateCode){
	   	                			 $scope.commonStateName=key.subdivisionName;
	   	                		 }
	   	                	 });
	   	        		}, function() {
	   	        			toaster.pop('error', "States list", "server not responding");
	   	        		});	
	                	}
	                });
	                address.location.entityId= address.entityId;
	                $scope.addresses.addresswithNoType.push(address.location);
	            }
	        });
	        
	        
	        // $scope.showPayTermDetails();
	        $scope.dueDiligence = (data.data.dueDiligence) ? (data.data.dueDiligence) : {};
	        $scope.subscription = (data.data.subscription) ? (data.data.subscription) : {}; 
	        $scope.subscription.businessLevels=(data.data.subscription) ? (data.data.subscription.businessLevels) : [];
            $scope.subscription.commoditiesList = (data.data.subscription) ? (data.data.subscription.commodities) : [];
            
            
//	        if($scope.subscription.businessLevels!=""||$scope.subscription.businessLevels!=undefined){
//	        	angular.forEach($scope.subscription.businessLevels, function(value, index) {
//			        $scope.businessLevel=[];
//	        		supplier.getbusinessLevelsNameFromID(value).then(function(data) {
//	        			//$scope.businessLevelsArray.push(data.name)
//	        			
//	        			$scope.businessLevel[index]=data.id ;
//
//	        			$scope.subscribeDetails.businessLevel1 = $scope.businessLevel[0];
//	        			$scope.getBusinessList2($scope.businessLevel[0]);
//	        			$scope.subscribeDetails.businessLevel2 = $scope.businessLevel[1];
//	        			$scope.getBusinessList3($scope.businessLevel[1]);
//	        			$scope.subscribeDetails.businessLevel3 = $scope.businessLevel[2];
//	        			$scope.getBusinessList4($scope.businessLevel[2]);
//	        		}, function() {
//	        			toaster.pop('error', "Business Names list", "server not responding");
//	        		});
//	        	});
//	        }
	       
	        if($scope.subscription.commoditiesList!=""||$scope.subscription.commoditiesList!=undefined){
	        	angular.forEach($scope.subscription.commoditiesList, function(value, index) {
			        $scope.commoditiesLevelsArray=[]
			        $scope.commoditiesLevelsNewArray=[]
	        		supplier.getcommodityValueFromId(value).then(function(data) {
	        			$scope.commoditiesLevelsArray.push({"name":data.name});
	        			$scope.commoditiesLevelsNewArray[index]=data.id;
	        			$scope.subscribeDetails.commodityFamily = $scope.commoditiesLevelsNewArray[0];
	        			$scope.subscribeDetails.commoditySubList = $scope.commoditiesLevelsNewArray[1];
	        			$scope.subscribeDetails.commodity = $scope.commoditiesLevelsNewArray[2];
	        		}, function() {
	        			toaster.pop('error', "Business Names list", "server not responding");
	        		});
	        	});
	        }   
		}, function(data) {
			$scope.loader=false;
		});
	}

	else if($cookieStore.get("roleForSubscribe")=="request"){
		supplier.getRequestDetails($cookieStore.get("supplierIdForSubscribe")).then(function(data) {	
			$scope.loader=false;
			if(data.data.supplier){
			$scope.supplierData.legalName=(data.data.supplier)?data.data.supplier.legalName:'';
			$scope.supplierData.supplierSpecialtyId = (data.data.supplier.supplierSpecialtyId)?data.data.supplier.supplierSpecialtyId:'';
			$scope.supplierData.countryCode = (data.data.supplier.countryId)?data.data.supplier.countryId:'';
			$scope.countryCode= data.data.supplier.countryId;
			$scope.supplierData.taxClassification= (data.data.supplier.legalTax.taxClassificationId)?data.data.supplier.legalTax.taxClassificationId:'';
			if(data.data.supplier.countryId!=""||data.data.supplier.countryId!=undefined){
		    	  angular.forEach($scope.chooseCountries, function(key, index) {
			    		if(key.id==data.data.supplier.countryId){
			    			$scope.supplierData.countryCode = (key.name)?key.name:''
			    		}  
		    	  });
		    }
			//$scope.supplierData.taxClassification = (data.data.supplier.taxClassificationId)?data.data.supplier.taxClassificationId:'';
	        $scope.addresses = {};
	        var addresses = (data.data.supplier.addresses) ? (data.data.supplier.addresses) : null;
	        angular.forEach(addresses, function(address, index) {
	            if (address.addressTypes.indexOf("LEGAL") != -1) {
	                if (!$scope.addresses.legalentity) {
	                    $scope.addresses.legalentity = [];
	                }
	                $scope.addresses.legalentity.push(address.location);
	            }
	            if (address.addressTypes.indexOf("ORDER_FULFILLMENT") != -1) {
	                if (!$scope.addresses.orderFulfilmentAddress) {
	                    $scope.addresses.orderFulfilmentAddress = [];
	                }
	                $scope.addresses.orderFulfilmentAddress.push(address.location);
	            }
	            if (address.addressTypes.indexOf("MANUFACTURING") != -1) {
	                if (!$scope.addresses.manufacturingAddress) {
	                    $scope.addresses.manufacturingAddress = [];
	                }
	                $scope.addresses.manufacturingAddress.push(address.location);
	            }
	        });
	        $scope.bankAccounts=(data.data.supplier.banks)?data.data.supplier.banks:[];
	        $scope.contacts=(data.data.supplier.contacts)?data.data.supplier.contacts:[];
	        $scope.supplierInfoDiversity = (data.data.supplier.diversity)?data.data.supplier.diversity:{};
	        $scope.dueDiligence = (data.data.supplier.dueDiligence) ? (data.data.supplier.dueDiligence) : {};
	        $scope.subscription = (data.data.subscription) ? (data.data.subscription) : {}; 
	        $scope.subscription.businessLevels=(data.data.subscription) ? (data.data.subscription.businessLevels) : [];
            $scope.subscription.commoditiesList = (data.data.subscription) ? (data.data.subscription.commodities) : [];
	        if($scope.subscription.businessLevels!=""||$scope.subscription.businessLevels!=undefined){
	        	angular.forEach($scope.subscription.businessLevels, function(value, index) {
			        $scope.businessLevel=[];
	        		supplier.getbusinessLevelsNameFromID(value).then(function(data) {
	        			//$scope.businessLevelsArray.push(data.name)
	        			$scope.businessLevel[index]=data.id ;

	        			$scope.subscribeDetails.businessLevel1 = $scope.businessLevel[0];
	        			$scope.getBusinessList2($scope.businessLevel[0]);
	        			$scope.subscribeDetails.businessLevel2 = $scope.businessLevel[1];
	        			$scope.getBusinessList3($scope.businessLevel[1]);
	        			$scope.subscribeDetails.businessLevel3 = $scope.businessLevel[2];
	        			$scope.getBusinessList4($scope.businessLevel[2]);
	        		}, function() {
	        			toaster.pop('error', "Business Names list", "server not responding");
	        		});
	        	});
	        }
	        if($scope.subscription.commoditiesList!=""||$scope.subscription.commoditiesList!=undefined){
	        	angular.forEach($scope.subscription.commoditiesList, function(value, index) {
			        $scope.commoditiesLevelsArray=[]
	        		supplier.getcommodityValueFromId(value).then(function(data) {
	        			$scope.commoditiesLevelsArray.push({"name":data.name})
	        		}, function() {
	        			toaster.pop('error', "Business Names list", "server not responding");
	        		});
	        	});
	        }
			}
			
		}, function(data) {
			$scope.loader=false;
		});
	}

	//business level
	supplier.getBusinessList1().then(function(data){
		$scope.businessList1 = data;
	}, function() {
		$scope.loader=false; 
		toaster.pop('error', "Business Root list", "server not responding");
	});

	$scope.onbusinessList1ChangeCode=function(id){
		$scope.loader=true;
		if(id==undefined){
			$rootScope.businessList2 = [];
			$scope.businessList3=false;
			$rootScope.businessTableList = [];
			$scope.loader=false;
			return;
		}else{
			$scope.businessList3=true;
			$scope.businessNewLevelSave.push(id);
			console.log("businessNewLevelSave1",$scope.businessNewLevelSave);
			$scope.getBusinessList2(id);
		}
	}
     $scope.getBusinessList2=function(id){
    	$scope.loader=true;
    	if(id==undefined){
    		$rootScope.businessList2 = [];
    		$rootScope.businessList3=[];
    		$rootScope.businessTableList = [];
    	 	$scope.loader=false;
			return;
		}else{
    		supplier.getBusinessSubList(id).then(function(data){
    			$rootScope.businessList2 = data;
    			$scope.loader=false;
    		}, function() {
    			$scope.loader=false;
    			toaster.pop('error', "Business sub list", "server not responding");
    		});
    	}
     }
     $scope.getBusinessList3=function(id){
     	$scope.loader=true;
    	if(id==undefined){
    		$rootScope.businessList3=[];
    		$rootScope.businessTableList = [];
    	 	$scope.loader=false;
			return;
		}else{
	    	$scope.businessNewLevelSave.push(id);
	    	console.log("businessNewLevelSave2",$scope.businessNewLevelSave);
	 		supplier.getBusinessSubList(id).then(function(data){
	 			$rootScope.businessList3 = data;
	 			$scope.loader=false;
			}, function() {
				$scope.loader=false;
				toaster.pop('error', "Business sub list", "server not responding");
			}); 
		}
     }
    $scope.getBusinessList4=function(id){
     	$scope.loader=true;
     	if(id==undefined){
     		$rootScope.businessTableList = [];
     		$scope.loader=false;
			return;
		}else{
	    	$scope.businessNewLevelSave.push(id);
	    	console.log("businessNewLevelSave3",$scope.businessNewLevelSave);
	    	$rootScope.businessTableList=[];
	  		supplier.getBusinessSubListNew(id).then(function(data){			
	  			$rootScope.businessTableList = data;
	  			$scope.loader=false;
	 		}, function() {
	 			$scope.loader=false;
	 			toaster.pop('error', "Business sub list", "server not responding");
	 		});
	 	} 
    }
    $scope.loadNextLevels = function(level, id){
		$scope.loader=true;
		if(id==undefined){
			$scope[level] = [];
			$scope.subscribeDetails.businessLevel2 = '';
			$scope.subscribeDetails.businessLevel3 = '';
			$rootScope.businessTableList = [];
			$rootScope.businessList3=[];
			$scope.loader=false;
			return;
		}else{
			supplier.getBusinessSubList(id).then(function(data){
				$scope[level] = data;
				$scope.loader=false;
			}, function() {
				$scope.loader=false;
				toaster.pop('error', "Business sub list", "server not responding");
			});
		}
	} 
     
   //Commodities List  
 	supplier.getCommoditiesFamilyList().then(function(data){
		$scope.commoditiesFamilyList = data;
	}, function() {
		$scope.loader=false;
		toaster.pop('error', "Commodities list", "server not responding");
	});
	$scope.onCommodityFamilyChangeCode=function(id){
		$scope.loader=true;
		if(id==undefined){
			$rootScope.commodityList = [];
			$rootScope.commoditySubList = [];
			$scope.subscribeDetails.commodityFamily = undefined;
    		$scope.subscribeDetails.commoditySubList = undefined;
			$scope.loader=false;
			return;
		}else{
			$scope.subscribeDetails.commodityFamily=id;
		  	$scope.getCommoditySubList(id);
		}  	
	}
	$scope.loadNextCommodity = function(level, id){
		$scope.loader=true;
    	if(id==undefined){
    		$scope[level] = [];
    	 	$scope.loader=false;
			return;
		}else{
			supplier.getCommoditiesSubList(id).then(function(data){
				if(data.length <= 0){
					$scope.showCommodity = false;
					//$scope.showSubCommodity =false;
				}else{
					$scope.showSubCommodity = true;
					$scope[level] = data;
					$scope.loader=false;
				}
			}, function() {
				$scope.loader=false;
			});
		}
	} 
	$scope.getCommoditySubList=function(id){
		$scope.loader=true;
    	if(id==undefined){
    		$rootScope.commoditySubList = [];
    		$rootScope.commodityList = [];
    		$scope.subscribeDetails.commodity = undefined;
    		$scope.subscribeDetails.commodityFamily = undefined;
    		$scope.subscribeDetails.commoditySubList = undefined;
    	 	$scope.loader=false;
			return;
		}else{
	    	$rootScope.commoditySubList=[];
	    	$scope.subscribeDetails.commoditySubList = "";
			supplier.getCommoditiesSubList(id).then(function(data){
				$rootScope.commoditySubList = data;
				if($rootScope.commoditySubList.length<=0){
					$scope.showSubCommodity = false;
				}else{
					$scope.showSubCommodity =true;
				}
				$scope.loader=false;
			}, function() {
				$scope.loader=false;
				toaster.pop('error', "Commodities sub list", "server not responding");
			});
		}
     }
     $scope.getCommoditiesList=function(id){
    	$scope.loader=true;
    	if(id==undefined){
    		$rootScope.commodityList = [];
    		$rootScope.commoditySubList = [];
    		$scope.subscribeDetails.commodity = undefined;
    		$scope.subscribeDetails.commodityFamily = undefined;
    		$scope.subscribeDetails.commoditySubList = undefined;
    	 	$scope.loader=false;
			return;
		}else{
	 		supplier.getCommoditiesSubList(id).then(function(data){
	 			$scope.loader=false;
	 			$rootScope.commodityList = data;
	 			if($rootScope.commodityList.length<= 0){
	 			$scope.showCommodity = false;}
	 			else{
	 				$scope.showCommodity = true;
	 			}
			}, function() {
				$scope.loader=false;
				toaster.pop('error', "commodity list", "server not responding");
			}); 
		}
     }

    $scope.maskNumber = function(number) {
        number = (number) ? number + "" : "";
        return number.replace(/\d(?=\d{4})/g, "*");
    }
	
	$scope.backSearch=function(){
		$state.go('supplierSearch', {activeSearch: $scope.subscribeDetails.supplierSubscribingTo});
	}
	$scope.showPayTerm=function(){
		$scope.addPayTerm=true;
	}
	$scope.showCommodityMain=function(){
		$scope.addCommodity=!$scope.addCommodity;
		
	}
	$scope.doPaymentTermsSearch = function(keyWord){
		$scope.poPaymentTermsSearchResult = false;
		supplier.getPaymentTerms(keyWord).then(function(data){
			$scope.paymentTermsData = data.paymentsTerms;
			$rootScope.paymentData=data;
			$scope.loader_poSearch=false;
			if($scope.paymentTermsData.length > 0){
				$scope.poPaymentTermsSearchResult = true;
				$scope.loader_poSearch=false;
			}else{
				$scope.poPaymentTermsSearchResult = false;
				$scope.loader_poSearch=true;

			}
		}, function(){

		});	
	}

	$scope.newPayTermValue=function(value,items){
		//$scope.panelPayterms=[];
		//$scope.panelPayterms.push($scope.mainPayterm);
		$scope.panelPayterms.push({"id":items.id,"name":items.name});
		$scope.subscription.paymentTermsChecksubscription=true;
		$scope.paytermOptionsByDefault=false;
		$scope.subscription.payment_terms_check=false;
		$scope.loader=true;
		$scope.payTermReasonName=value;
		$scope.newSelectedPayTermValue=[]
		$scope.newSelectedPayTermValue.push(value);
		supplier.getPaymentTermsById($scope.newSelectedPayTermValue[0]).then(function(data){
			$scope.loader=false;
			$scope.getPaymentTermsName = data.name;
		},function(){
			$scope.loader=false;
		}); 	
		$scope.subscription.paymentTermsId = $scope.newSelectedPayTermValue[0];
		$scope.addPayTerm=false;
		$scope.subscription.paymentTermsChecksubscription=true;
		$scope.subscription.payment_terms_check=''
		$scope.subscription.keyWord='';
        $scope.subscription.payment_terms_check='';
        $scope.poPaymentTermsSearchResult=false;
    	$scope.changePayTerm=true;
    	$scope.applyPayTerm=false;
	}
	$scope.paymentCurSubscribe=function(){

	$scope.bankAccountsLevelPayments=!$scope.bankAccountsLevelPayments;
	}
	
	$scope.addressSubscribe=function(){
		$scope.bankAccountsLevelAddress=!$scope.bankAccountsLevelAddress;	
	}
	$scope.saveBusinessLevel4=function(item){
		// $scope.newBusinessLevel4=[];
		// $scope.newBusinessLevel4.push({"erpName":item.erpInstance,"erpOrg":item.erpOrgNumber,"erpOrgName":item.erpOrgName,"country":item.erpCountryCode,"currency":item.erpCurrencyCode})
		// $scope.idSelectedErp=item.erpOrgNumber;
		// $scope.businessNewLevel4Save=item.id;
		// $scope.businessNewLevel4SaveArray=[];
		// $scope.businessNewLevel4SaveArray.push(item.id);
		
		// console.log("$scope.businessNewLevelSave",$scope.businessNewLevelSave)
		$scope.erpId = [];
 		angular.forEach($rootScope.businessTableList, function(item, key){
 			item.selected = false
 		})
     	item.selected = true;
     	$scope.erpId.push(item.id);
	}
	$scope.getCurrentSubscribers=function(text,entityId,item){
		if(text=="address"){
			angular.forEach($scope.addresses, function(value, index) {				
				if(!angular.equals(value, item)){
					value.bankAccountsLevelAddress=false
				}	
			});
			item.bankAccountsLevelAddress=!item.bankAccountsLevelAddress;	
		}
		if(text=="bankAccount"){
			angular.forEach($scope.bankAccounts, function(value, index) {				
				if(!angular.equals(value, item)){
					value.bankAccountsLevelPayments=false
				}	
			});
			item.bankAccountsLevelPayments=!item.bankAccountsLevelPayments;
		}
		if(text=="contact"){
			angular.forEach($scope.contacts, function(value, index) {
				
				if(!angular.equals(value, item)){
					value.bankAccountsLevelContacts=false
				}	
			});
			
			item.bankAccountsLevelContacts=!item.bankAccountsLevelContacts;
		}
		
		$scope.loader=true;
 		supplier.getcurrentSubscribers(text,entityId,$scope.supplierId).then(function(data){
 			$scope.loader=false;
         if(data.data!="" && data.data!=undefined && text=="contact"){
        	 $scope.contactGetSubscribers=data.data;
         }
         if(data.data!="" && data.data!=undefined && text=="bankAccount"){
        	 $scope.bankGetSubscribers=data.data;
         }
         if(data.data!="" && data.data!=undefined && text=="address"){
        	 $scope.addressGetSubscribers=data.data;
         }
         
		}, function() {
           $scope.loader=false;
		}); 	
	}
	
	$scope.subscribeSaveBtn=function(subscription){
		
		if($scope.businessNewLevelSave=="" || $scope.businessNewLevelSave==undefined){
        	toaster.pop('error','Business Levels Details Missing', "Please select any business levels");
        	$scope.loader=false;
        	return
        }
         if($scope.erpId=="" || $scope.erpId==undefined){
        	toaster.pop('error','Business Level4 Details Missing', "Please select any businessLevel4");
        	$scope.loader=false;
        	return
        }
        if($scope.addressIdValArray=="" || $scope.addressIdValArray==undefined){
        	toaster.pop('error','Address Details Missing', "Please select any address");
        	$scope.loader=false;
        	return
        } 
		if($scope.externalSupplierSubscribe){
			if($scope.subscription.paymentTermsId=="" || $scope.subscription.paymentTermsId==undefined){
				toaster.pop('error','Pay Term Details Missing', "Please select any Pay Term");
				return
			}
			
			if($scope.bankIdArray=="" || $scope.bankIdArray==undefined){
				toaster.pop('error','Bank Details Missing', "Please select any bank details");
				$scope.loader=false;
				return
			}
			if($scope.contactIdArray=="" || $scope.contactIdArray==undefined){
				toaster.pop('error','Contact Details Missing', "Please select any contact");
				$scope.loader=false;
				return
			}
			if($scope.supplierDataNew.commodityId==undefined && $scope.supplierDataNew.commoditySubListId==undefined && $scope.supplierDataNew.commodityFamilyId==undefined){
				toaster.pop('error','Commodity Details Missing', "Please select any Commodity");
				$scope.loader=false;
				return
			}
		}
		WfModel.subscription = (WfModel.subscription==null)?{}:WfModel.subscription;
		WfModel.partyId=$scope.supplierId;
		
		if($scope.internalSupplierSubscribe) {
			$scope.subscription.paymentTermsId = 0; // We dont have Payterm for internal now
			WfModel.subscription.bucId = $scope.buc.entityId;
		}
		var addressObjs = [];
		angular.forEach($scope.addressIdValArray, function(idValue, idKey) {			
			var idArray = $filter('filter')($scope.addresses, {'entityId': idValue});						
			if(idArray[0]) {				
				angular.forEach(idArray[0].addressTypes, function(typeValue, typeKey) {
					if(typeValue == "ORDER_FULFILLMENT"){
						var addressTypeValue = "ORDER_FULLFILLING";
						addressObjs.push({addressId: idValue, type: addressTypeValue});
					}else{
						addressObjs.push({addressId: idValue, type: typeValue});
					}	
				});
			}			
		});
		
		//WfModel.subscription.addressId=($scope.addressIdValArray)?$scope.addressIdValArray:[],		
		WfModel.subscription.addresses=addressObjs,
		WfModel.subscription.bankAccountId=($scope.bankIdArray)?$scope.bankIdArray:[],
		WfModel.subscription.contactId=($scope.contactIdArray)?$scope.contactIdArray:[],
		WfModel.subscription.businessLevels=($scope.businessNewLevelSave)?$scope.businessNewLevelSave:[],
		WfModel.subscription.commodityTier1Id=($scope.supplierDataNew.commodityFamilyId)?$scope.supplierDataNew.commodityFamilyId:'',
		WfModel.subscription.commodityTier2Id=($scope.supplierDataNew.commoditySubListId)?$scope.supplierDataNew.commoditySubListId:'',
		WfModel.subscription.commodityTier3Id=($scope.supplierDataNew.commodityId)?$scope.supplierDataNew.commodityId:null,
		WfModel.subscription.erpId=($scope.erpId)?$scope.erpId:[],
		//WfModel.subscription.incoTermsId='',
		WfModel.subscription.paymentTermsId=($scope.subscription)?$scope.subscription.paymentTermsId:'',
		WfModel.subscription.paymentTermsReason='',
		WfModel.subscription.settlementProcessId=null
			console.log(WfModel);
				$scope.loader=true;
				WorkFlow.setVariablesV2Subscribe(WfModel).then(function(data) {	
					//1. call the modal here
					supplier.getComplianceSubscribeRules(WfModel.requestId).then(function(data) {	
						$scope.compliance = data.data;
						if($scope.compliance){
							$('#complianceModal').modal('show');
						    $scope.loader = false;
						    return;
						}else{
							completeSubscribeWorkflow();
						}
					},function(data){
						$scope.loader = false;
					});	
				},function(data){
					toaster.pop('error', "server  not responding ");
					$scope.loader=false;
				});	
	}
	//save the modal data 
	$scope.saveComplianceModalQuestions = function(supplierInfo){
		$scope.submitted = true;
	  	if(supplierInfo.conflictOfInterests==true) {
		  	if(supplierInfo.relationshipData==""||supplierInfo.relationshipData==undefined){
			  	toaster.pop('error', "Explain the relationship", "Please answer all the mandatory question");	
			  	return
		  	}
	  	}
	  	if(supplierInfo.onboardingRedFlag==true){
	  	 	if(supplierInfo.onboardingRedFlagComment==""||supplierInfo .onboardingRedFlagComment==undefined){
		  	 	toaster.pop('error', "Describe the concern", "Please answer all the mandatory question");	
				return;
	  		}
	  	}
	  	if(supplierInfo.donationProvidesBenefitsToGE==true){
		  	if(supplierInfo.donationProvidesBenefitsToGEComment==""||supplierInfo.donationProvidesBenefitsToGEComment==undefined){
		  		toaster.pop('error', "Please Explain", "Please answer all the mandatory question");	
				return;
		  	}
		}
	  	if(supplierInfo.isSupplierInteractsWithGovernmentForGE==true){
	  		if(supplierInfo.functionPerform==undefined || supplierInfo.functionPerform==""){
				toaster.pop('error', "Select the function", "Please answer all the mandatory question");	
				return;
			}
	  	}
        if(supplierInfo.isSupplierInteractsWithGovernmentForGE==true){
		  	if(supplierInfo.supplierASPFunctionBusinessPurpose==undefined || supplierInfo.supplierASPFunctionBusinessPurpose==""){
				toaster.pop('error', "Please provide business purpose", "Please answer all the mandatory question");	
				return;
			}
	  	}
	  	if(supplierInfo.conflictOfInterests==null && $scope.compliance.conflictOfInterests.mandatory == true && $scope.compliance.conflictOfInterests.enabled == true){
		  	toaster.pop('error', "conflict Of Interests", "Please answer all the mandatory question");	
			return;
	  	}
	  	if(supplierInfo.defaultQuestionnaire==null && $scope.compliance.infoSecurity.mandatory == true && $scope.compliance.infoSecurity.enabled == true){
		  	toaster.pop('error', "Please select supplier details", "Please answer all the mandatory question");	
			return;
	  	}
	  	if(supplierInfo.onboardingRedFlag==null && $scope.compliance.onboardingRedFlag.mandatory == true && $scope.compliance.onboardingRedFlag.enabled == true){
		  	toaster.pop('error', "On Boarding Red Flag", "Please answer all the mandatory question");	
			return;
	  	}
	  	if(supplierInfo.providesDigitalComponentForGE==null && $scope.compliance.providesDigitalComponentForGE.mandatory == true && $scope.compliance.providesDigitalComponentForGE.enabled == true){
		 	toaster.pop('error', "Provides Digital Component For GE", "Please answer all the mandatory question");	
			return;
	  	}
	  	if(supplierInfo.isTTTGProvider==null && $scope.compliance.isTTTGProvider.mandatory == true && $scope.compliance.isTTTGProvider.enabled == true){
		  	toaster.pop('error', "Is TTTG Provider", "Please answer all the mandatory question");	
			return;
	  	}
	  	if(supplierInfo.isTTTGProductProvider==null && $scope.compliance.isTTTGProductProvider.mandatory == true && $scope.compliance.isTTTGProductProvider.enabled == true){
		  	toaster.pop('error', "Is TTTG Product Provider", "Please answer all the mandatory question");	
			return;
	  	}
        if(supplierInfo.isSupplierInteractsWithGovernmentForGE==null && $scope.compliance.isSupplierInteractsWithGovernmentForGE.mandatory == true && $scope.compliance.isSupplierInteractsWithGovernmentForGE.enabled == true){
		  	toaster.pop('error', "Is Supplier Interacts With Government For GE", "Please answer all the mandatory question");	
			return;
	  	}
	  	if(supplierInfo.donationDoneAtTheForeignOfficialRequest==null && $scope.compliance.donationDoneAtTheForeignOfficialRequest.mandatory == true && $scope.compliance.donationDoneAtTheForeignOfficialRequest.enabled == true){
		  	toaster.pop('error', "Donation Done At The Foreign Official Request", "Please answer all the mandatory question");	
			return;
	  	}
	  	if(supplierInfo.donationProvidesBenefitsToGE==null && $scope.compliance.donationProvidesBenefitsToGE.mandatory == true && $scope.compliance.donationProvidesBenefitsToGE.enabled == true){
		  	toaster.pop('error', "Donation Provides Benefits To GE", "Please answer all the mandatory question");	
			return;
	  	}
	  	if(supplierInfo.isUsingGETrademark==null && $scope.compliance.isUsingGETrademark.mandatory == true && $scope.compliance.isUsingGETrademark.enabled == true){
		  	toaster.pop('error', "GE Trademark", "Please answer all the mandatory question");	
			return;
	  	}
	  	if(supplierInfo.laborServicesPurpose==null && $scope.compliance.laborServicesPurpose.mandatory == true && $scope.compliance.laborServicesPurpose.enabled == true){
		  	toaster.pop('error', "Labour Service Purpose", "Please answer all the mandatory question");	
			return;
	  	}
	  	if(supplierInfo.laborServicesPurpose==true){
		  	supplierInfo.laborServicesPurpose = 'GE';
	  	}
	  	if(supplierInfo.laborServicesPurpose==false){
		  	supplierInfo.laborServicesPurpose = 'CUSTOMER'; 
	  	}

	  	$scope.loader = true;
	  	WfModel.dueDiligence = (WfModel.dueDiligence==null)?{}:WfModel.dueDiligence;
		
		WfModel.dueDiligence.infoSecurity = supplierInfo.defaultQuestionnaire;
		WfModel.dueDiligence.conflictOfInterests  = supplierInfo.conflictOfInterests;  
		WfModel.dueDiligence.conflictOfInterestsComment = supplierInfo.relationshipData;
		WfModel.dueDiligence.onboardingSupplierRedFlag = supplierInfo.onboardingRedFlag;
		WfModel.dueDiligence.onboardingSupplierRedFlagComment = supplierInfo.onboardingRedFlagComment;
		WfModel.dueDiligence.donationProvidesBenefitsToGEComment = supplierInfo.donationProvidesBenefitsToGEComment;
		WfModel.dueDiligence.donationPurpose = supplierInfo.donationPurpose; 
		WfModel.dueDiligence.providesDigitalComponentForGE = supplierInfo.providesDigitalComponentForGE;
		WfModel.dueDiligence.isTTTGProvider  = supplierInfo.isTTTGProvider;
		WfModel.dueDiligence.isTTTGProductProvider   = supplierInfo.isTTTGProductProvider;
		WfModel.dueDiligence.supplierInteractsWithGovernmentForGE    = supplierInfo.isSupplierInteractsWithGovernmentForGE;
		WfModel.dueDiligence.supplierASPFunction     = false; // id from ref data
		WfModel.dueDiligence.supplierASPFunctionBusinessPurpose      = supplierInfo.supplierASPFunctionBusinessPurpose; 
		WfModel.dueDiligence.supplierASPFunctionId = supplierInfo.functionPerform;
		WfModel.dueDiligence.donationDoneAtTheForeignOfficialRequest  = supplierInfo.donationDoneAtTheForeignOfficialRequest; 
		WfModel.dueDiligence.donationProvidesBenefitsToGE  = supplierInfo.donationProvidesBenefitsToGE; 
		WfModel.dueDiligence.isUsingGETrademark   = supplierInfo.isUsingGETrademark; 
		WfModel.dueDiligence.laborServicesPurpose    = supplierInfo.laborServicesPurpose;  // customer/GE
		WorkFlow.setVariablesV2Subscribe(WfModel).then(function(data) {
			// $scope.loader=false;
		  	completeSubscribeWorkflow();		
		},function(data){
			$scope.loader=false;
			toaster.pop('error','Workflow Api', "Server not Responding");
		});
	}

	//complete the subscribe workflow 
	var completeSubscribeWorkflow = function(){
		WorkFlow.completeWorkflowV2Subscribe().then(function(data) {	
			$scope.completed = data.completed;
			if($scope.completed === false){
				toaster.pop('error', data.fault[0]);
				$scope.loader=false;
			}
			else{
				toaster.pop('success', "workflow completed successfully");	
				$state.go('supplierSearch', {activeSearch: $scope.subscribeDetails.supplierSubscribingTo});
			}
		},function(data){
			toaster.pop('error', "server  not responding ");
			$scope.loader=false;
		});	
	}
	
	$scope.getCurrentSubscribersForCommodity=function(text,item){
		if(text=="commodity"){
			 angular.forEach($scope.commodityListOnPayLoad, function(value, index) {				
				if(!angular.equals(value, item)){
					value.commodityLevelAddress=false;
				}	
			 });
			item.commodityLevelAddress=!item.commodityLevelAddress;
		}
		$scope.loader=true;
		supplier.getcurrentSubscribersForCommodity(text,item,$scope.supplierId).then(function(data){
			$scope.loader=false;
	         if(data.data!="" && data.data!=undefined && text=="commodity"){
	        	 $scope.commodityGetNewSubscribers=[];
	        	 $scope.commodityGetNewSubscribers=data.data;
	        	// $scope.commodityLevelAddress=true;
	         }

	         
			}, function() {
                $scope.loader=false;
			}); 
	}
	$scope.toggleCommodity=function(){
		$scope.commodityLevelAddress = !$scope.commodityLevelAddress;
	}
	//This function is called when a user clicks a button to apply commodity changes.
	$scope.applyChangeCommodity=function(subscription){
		//used to detect whether the user sees three boxes for commodities
  		var isAllThreeSelectionBoxesVisibleForCommodoties = false; 
  		//used to detect whether the user sees two boxes
  		//We use scope variable to check whether the user sees which 
  		//selection boxes. Check the relative page to see bound/referenced
  		//data
  		var onlyTwoSelectionBoxesAreVisible = $scope.commoditySubList;


	  	if($scope.commodityList){
			isAllThreeSelectionBoxesVisibleForCommodoties = ($scope.commodityList.length > 0) ? true : false;
	  	}

	  	//we should display an error message to the user informing them
	  	//that a selection box is visible, however, no valid input is selected.
	  	//The criteria for invalid is a null input, an empty string, or 
	  	//undefined input
		if(isAllThreeSelectionBoxesVisibleForCommodoties){
			if(!subscription.commodityFamily || !subscription.commoditySubList
			 || !subscription.commodity ) {
				toaster.pop('error', "", "Please fill all values");
				return ;
			}
		}else if(onlyTwoSelectionBoxesAreVisible){
			if(!subscription.commodityFamily || !subscription.commoditySubList) {
				toaster.pop('error', "", "Please fill all values");
				return ;
			}
		}

		
		$scope.supplierDataNew={};
		$scope.submitted = true;
	  	  angular.forEach($rootScope.commodityList, function(key, index) {
	    		if(key.id==subscription.commodity){
	      			$scope.supplierDataNew.commodity = (key.name)?key.name:'';
	      			$scope.supplierDataNew.commodityId = (key.id)?key.id:''
	      		}  
	  	  });
		
		if($scope.commoditySubList){
			$scope.commoditySubList.length=0;
		}
		$scope.commoditySubList=false;
		if($scope.commodityList){
			$scope.commodityList.length=0;
		}
		if(subscription.commodityFamily == undefined && subscription.commoditySubList == undefined && subscription.commoditySubList == undefined) {
			toaster.pop('error', "", "Please fill all values");	
			return;
		}
		if($scope.commodityListOnPayLoad==undefined){
			$scope.commodityListOnPayLoad=[];
		}
		
  	   angular.forEach($scope.commoditiesFamilyList, function(key, index) {
    		if(key.id==subscription.commodityFamily){
      			$scope.supplierDataNew.commodityFamily = (key.name)?key.name:'';
      				$scope.supplierDataNew.commodityFamilyId= (key.id)?key.id:'';
      		}  
	  });
  	  angular.forEach($rootScope.commoditySubList, function(key, index) {
  		if(key.id==subscription.commoditySubList){
    			$scope.supplierDataNew.commoditySubList = (key.name)?key.name:'';
    			$scope.supplierDataNew.commoditySubListId = (key.id)?key.id:''
    		}  
	  });
		$scope.commodityListOnPayLoad.push({"tier1Id":$scope.supplierDataNew.commodityFamilyId,"tier2Id":$scope.supplierDataNew.commoditySubListId,"tier3Id":$scope.supplierDataNew.commodityId,"tier1Name":$scope.supplierDataNew.commodityFamily,"tier2Name":$scope.supplierDataNew.commoditySubList,"tier3Name":$scope.supplierDataNew.commodity})
		subscription.commoditySubList = undefined;
		subscription.commodityFamily = undefined;
		subscription.commodity = undefined;
	}
	

	$scope.paymentTermIdSave=function(id,payment){
		$scope.finalPayTermsId=id;
		$scope.panelPayterms=[];
		$scope.panelPayterms.push($scope.mainPayterm);
		$scope.panelPayterms.push({"id":payment.id,"name":payment.name});
		$scope.subscription.payment_terms_check=false;
		$scope.poPaymentTermsSearchResult=false
		$scope.paytermOptionsByDefault=false;
	}
	$scope.bankChangedCheckBox=function(id){
		$scope.bankIdArray = [];
	    angular.forEach($scope.bankAccounts, function(item){
	      if (item.selected) $scope.bankIdArray.push(item.entityId);
	      console.log($scope.bankIdArray)
	    });
	}
	$scope.contactChangedCheckBox=function(id){
		$scope.contactIdArray=[];
		 angular.forEach($scope.contacts, function(item){
		      if (item.selected) $scope.contactIdArray.push(item.entityId);
		      console.log($scope.contactIdArray)
		    });
	}
	
	$scope.updateSelectionPayTerm=function(position, panelPayterms,term){
	      angular.forEach(panelPayterms, function(value, index) {
	    	  debugger;
	        	if (position != index) 
	          	value.checked = false;
	      	});

	      if(term.checked==true){
		     $scope.subscription.paymentTermsId = term.id;
//		     alert($scope.subscription.paymentTermsId);
             }
	}
	
	$scope.commoditySelectedId=function(item){
		$scope.supplierDataNew.commodityFamilyId = item.tier1Id;
		$scope.supplierDataNew.commoditySubListId = item.tier2Id;
		$scope.supplierDataNew.commodityId =item.tier3Id ;
	}
	$scope.updateSelection = function(position, commodityListOnPayLoad) {
      angular.forEach(commodityListOnPayLoad, function(value, index) {
        	if (position != index) 
          	value.checked = false;
      	});
    }
	$scope.addressIdValArray=[];
    $scope.addressSelected=function(item){
	$scope.addressIdValArray.push(item.entityId);
	item.remittanceAndPOEmailLevelAddress = true;
	}
	$scope.addCommodity = function() {
		$scope.showAddCommodity = !$scope.showAddCommodity;
	}
	
	$scope.addAddress = function() {
		$scope.showaddAddress = !$scope.showaddAddress;
	}
	
	$scope.addPayment = function() {
		$scope.showaddPayment = !$scope.showaddPayment;
		$scope.panel.bankCreditDetails = false;
		$scope.panel.primaryAccount = false;		
		$scope.panel.failCounter = 0;;	
		angular.forEach($scope.addresses, function(value, index) {				
			value.assocAddress = false;
		});
	}
		
	$scope.addContact = function() {
		$scope.supplierData.businessCodeShortForContact='';
		$scope.supplierData.businessCodeForContact='';
		$scope.supplierData.mobileCodeForContact='';
		$scope.supplierData.mobileCodeShortForContact='';
		$scope.showaddContact = !$scope.showaddContact;
	}
	
});
