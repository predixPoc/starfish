
app.controller('signInController', function($scope, $filter, $http, $rootScope,$state,Auth,$timeout,toaster,$cookies,$cookieStore,constants) {	
	$scope.loginSubmit = function(login) {
	       if(login==undefined){
			   toaster.pop('error', "Invalid Login", "Please fill username and password.");
			   return false;
		   }else{
			$scope.preloader=false;
	        Auth.login(login).then(function(data){		
				if(data.ResponseCode == 200) {
					toaster.pop('success', "Welcome", "welcome to supplier connect home page."); 
					$scope.preloader=false;
					$state.go('homePage');
					var tokenFor = data.token_type + " " + data.access_token;
					 $cookieStore.put('sc_token',tokenFor);
					 console.log("LatestCookie",$cookieStore.get("sc_token"));
				
					var req = {
							headers: {
								'Content-Type': 'application/x-www-form-urlencoded',
								'Authorization': tokenFor
							},
							/*https://pc-api-gateway-dev.run.asv-pr.ice.predix.io/pc_access_control/users/authorize*/
							url:constants.USERS_AUTHORIZE ,
							method: 'POST',
							data:$.param({token: tokenFor})
						}
					
					$http(req).then(function(response) {
							console.log('authorize');				
					}, function() {
				
					});
				
				} else {
					$scope.preloader=true;
				   toaster.pop('error', "Invalid Login", "Please fill username and password correctly.");    
				}
	        	}, function () {
					    toaster.pop('error', "System Error", "Some error happend .Please try again after sometime."); 
	                   
	            });
		}	
	}

});