var count=0;
var currentStr = '';
app.directive('numbersOnly', function(){
   return {
     require: 'ngModel',
     link: function(scope, element, attrs, modelCtrl) {
       modelCtrl.$parsers.push(function (inputValue) {
           if (inputValue == undefined) return ''
           var transformedInput = inputValue.replace(/[^0-9]/g, '');
           if (transformedInput!=inputValue) {
              modelCtrl.$setViewValue(transformedInput);
              modelCtrl.$render();
           }

           return transformedInput;
       });
     }
   };
});
app.directive('countryNameFromId', function (supplier, $filter) {
	item={};
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            scope.$watch(attrs.ngModel, function (v) {
            	supplier.getCountryList().then(function(data) {
			    	  angular.forEach(data, function(key, index) {
				    		if(key.id==v){
				    			scope.countryCode=key.name;
				    		}  
			    	  });	
        		}, function() {
        		});
                
            });
        }
    };
});
app.directive('removeModal', ['$document', function ($document) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            element.bind('click', function () {
                $document[0].body.classList.remove('modal-open');
                angular.element($document[0].getElementsByClassName('modal-backdrop')).remove();
                angular.element($document[0].getElementsByClassName('modal')).remove();
            });
        }
    };
}]);
app.directive('changeCommodityNameFromId', function (supplier, $filter) {
	item={};
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            scope.$watch(attrs.ngModel, function (v) {
            	supplier.getCommoditiesFamilyList().then(function(data){
			    	  angular.forEach(data, function(key, index) {
				    		if(key.id==v){
				    			scope.commodityName=key.name;
				    		}  
			    	  });	
        		}, function() {
        			toaster.pop('error', "Country list", "server not responding");
        		});
                
            });
        }
    };
});
app.directive('changePaytermNameFromId', function (supplier, $filter) {
	item={};
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            scope.$watch(attrs.ngModel, function (v) {
            	supplier.getPayTermNameFromVal(v).then(function(data){
                      scope.payTermName=data.name	
        		}, function() {
        			toaster.pop('error', "Country list", "server not responding");
        		});
                
            });
        }
    };
});

app.directive('changeTaxNameFromId', function (supplier, $filter) {
	item={};
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            scope.$watch(attrs.ngModel, function (v) {
            	supplier.getWithHoldingTaxTypeById(v).then(function(data){
                      scope.taxName=data.name	
        		}, function() {
        		});
                
            });
        }
    };
});

app.directive('changeTaxNameFromIdForOwner', function (supplier, $filter) {
	item={};
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            scope.$watch(attrs.ngModel, function (v) {
            	supplier.getWithHoldingTaxTypeById(v).then(function(data){
                      scope.taxNameOwner=data.name	
        		}, function() {
        		});
                
            });
        }
    };
});

app.directive('myMaxlength', function() {
  return {
    require: 'ngModel',
    link: function (scope, element, attrs, ngModelCtrl) {
      var maxlength = Number(attrs.myMaxlength);
      function fromUser(text) {
          if (text.length > maxlength) {
            var transformedInput = text.substring(0, maxlength);
            ngModelCtrl.$setViewValue(transformedInput);
            ngModelCtrl.$render();
            return transformedInput;
          } 
          return text;
      }
      ngModelCtrl.$parsers.push(fromUser);
    }
  }; 
});

app.directive('tooltip', function($timeout){
    return {
		scope:{
			dynamicTitle: '='
		},
        restrict: 'A',
        link: function(scope, element, attrs) {

			scope.$watch('dynamicTitle', function(value) {
				$(element).tooltip('destroy');
				$timeout(function () {

					$(element).tooltip({title: value});
				}, 100);

			});
		  // $(element).tooltip({title:'hey'});
            /*$(element).hover(function(){
                // on mouseenter
                $(element).tooltip('show');
            }, function(){
                // on mouseleave
                $(element).tooltip('hide');
            }); */
        }
    };
});

app.directive('pageHeight', function($timeout){
    return {

        restrict: 'A',
        link: function(scope, element, attrs) {
        		  function setHeight() {
        		    windowHeight = $(window).innerHeight();
        		    $('main').css('min-height', windowHeight-attrs.header);
        		  };
        		  setHeight();

        		  $(window).resize(function() {
        		    setHeight();
        		  });
        }
    };
});


app.directive('knowledgeBase', function($timeout){
    return {

        restrict: 'A',
        link: function(scope, element, attrs) {
					/*
					RightNow.Client.Controller.addComponent(
					{
						div_id: "myKnowledge",
						instance_id: "skw_0",
						module: "KnowledgeSyndication",
						type: 3,
					
					},
					"https://gecorp--tst.widget.custhelp.com/ci/ws/get"
					);
					*/
					
					RightNow.Client.Controller.addComponent(
						{
							div_id: "myKnowledge",
							display_answers_in_overlay: true,
							hide_initial_answers: true,
							number_answers: 5,
							label_search_button: "search",
							instance_id: "skw_0",
							module: "KnowledgeSyndication",
							type: 3
						},
						"https://gecorp--tst.widget.custhelp.com/ci/ws/get"
					);
									

        }
    };
});

app.directive('navChange', function($timeout, $interval) {
    return {

        restrict: 'A',
        link: function(scope, element, attrs) {
				console.log($('#myChatLinkInfo')[0]==undefined)
				console.log('nave change')

				//if($('#myChatLinkInfo')[0]==undefined) {

						/*
					RightNow.Client.Controller.addComponent(
					{
						div_id: "myDiv",
						instance_id: "skw_0",
						module: "KnowledgeSyndication",
						type: 3
					},
					"https://gecorp--tst.widget.custhelp.com/ci/ws/get"
					); */

					RightNow.Client.Controller.addComponent(
						{
							chat_login_page: "/app/supplierconnect/chat/chat_launch",
							container_element_id: "myChatLinkContainer",
							enable_availability_check: false,
							enable_polling: false,
							info_element_id: "myChatLinkInfo",
							label_default: "",
							link_element_id: "myChatLink",
							instance_id: "sccl_0",
							module: "ConditionalChatLink",
							type: 7
						
						},
						"//gecorp--tst.widget.custhelp.com/ci/ws/get"
					);
					/*
					RightNow.Client.Controller.addComponent(
						{
							c: "2378,3943",  //these ids should not be changed to fetch alerts
							description: false,
							display_answers_in_overlay: false,
							div_id: "myAlertDiv",
							search_box: false,
							instance_id: "skw_0",
							module: "KnowledgeSyndication",
							type: 3
						},
						"https://gecorp--tst.widget.custhelp.com/ci/ws/get"
					); 
					*/
					$interval(function() {
						console.log('Refresh alerts');
						$('#myAlertDiv .KnowledgeSyndication').remove();
						RightNow.Client.Controller.addComponent(
							{
								c: "2378,5131",  //these ids should not be changed to fetch alerts
								truncate_size: 10000,
								display_answers_in_overlay: false,
								div_id: "myAlertDiv",
								search_box: false,
								instance_id: "skw_0",
								module: "KnowledgeSyndication",
								type: 3
							},
							"https://gecorp--tst.widget.custhelp.com/ci/ws/get"
						)
					}, 5*60000);
					  
					  
					RightNow.Client.Controller.addComponent(
						{
							c: "2378,5131",  //these ids should not be changed to fetch alerts
							truncate_size: 10000,
							display_answers_in_overlay: false,
							div_id: "myAlertDiv",
							search_box: false,
							instance_id: "skw_0",
							module: "KnowledgeSyndication",
							type: 3
						},
						"https://gecorp--tst.widget.custhelp.com/ci/ws/get"
					)
					


				//}

        }
    };
});





app.directive('spPopover', function ($timeout) {
    return {
		scope:{
			dynamicTitle: '='
		},
        restrict: 'A',
        //template: '<span>{{label}}</span>',
        link: function (scope, el, attrs) {
            scope.label = attrs.popoverLabel;
			scope.$watch('dynamicTitle', function(value) {

				$(el).popover("destroy");
				$timeout(function () {
					$(el).popover("destroy").popover({
						trigger: 'hover',
						html: true,
						content: value,
						placement: attrs.popoverPlacement

					});
				}, 200);


			});



        }
    };
});


app.directive('spPopoverStatic', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, el, attrs) {

			$timeout(function () {
				$(el).popover({
					trigger: 'hover',
					html: true,
					content: attrs.popTitle,
					placement: attrs.popoverPlacement

				});
			});
        }
    };
});


app.directive('spCollapse', function ($timeout) {
    return {

        restrict: 'A',
        link: function (scope, el, attrs) {
			var $icon = $(el).find('i');
			if(attrs.mode=='closed'){
				$(el).closest('.review-head').next('.review-main').slideUp();
				$icon.removeClass('fa-chevron-right');
				$icon.addClass('fa-chevron-down');
			}
			$(el).click(function(){

					if($icon.hasClass('fa-chevron-right')){
						$icon.removeClass('fa-chevron-right');
						$icon.addClass('fa-chevron-down');
					}else {
						$icon.removeClass('fa-chevron-down');
						$icon.addClass('fa-chevron-right');
					}

					$(el).closest('.review-head').next('.review-main').slideToggle();
			});

        }
    };
});


app.directive('spCollapse1', function ($timeout) {
    return {

        restrict: 'A',
        link: function (scope, el, attrs) {
			var $icon = $(el).find('i');
			if(!attrs.mode){
				$(el).closest('.review-head').next('.review-main').slideUp();

			}
			$(el).hover(function(){
				$(this).closest('.review-head').css( 'cursor', 'pointer' );
			});
			$(el).click(function(){
				$(this).attr("mode","open");
				if($(this).attr("mode")=="open"){
					debugger;
					console.log($(this).find('input:radio').val());
					scope.getNewEmailTemplate($(this).find('input:radio').val());
					$(this).find('input:radio').prop('checked', true);
					$(el).closest('.review-head').next('.review-main').slideDown();
				}



					if($icon.hasClass('fa-chevron-right')){
						$icon.removeClass('fa-chevron-right');
						$(this).find('input:radio').prop('checked', true);
						$icon.addClass('fa-chevron-down');
					}else {
						$(this).attr( "mode","close" )
						$(this).find('input:radio').prop('checked', false);
						$(el).closest('.review-head').next('.review-main').slideUp();
						$icon.removeClass('fa-chevron-down');
						$icon.addClass('fa-chevron-right');
					}

			});

        }
    };
});



app.directive('spDatepicker', function ($timeout, $parse) {
    return {
		require: 'ngModel',
        restrict: 'A',
        //template: '<span>{{label}}</span>',
        link: function (scope, el, attrs, ctrl) {
			var date = new Date();
			var currentMonth = date.getMonth();
			var currentDate = date.getDate();
			var currentYear = date.getFullYear();
			scope.ngModel = 'ddd';
			$(el).datepicker({
				 onSelect: function(dateText, inst) {					
					ctrl.$setViewValue(dateText);
					ctrl.$render();
					scope.$apply();
				 },

				minDate: new Date(currentYear, currentMonth, currentDate),
				dateFormat: 'yy-mm-dd'
			});

        }
    };
});


app.directive('spDragDrop', function ($timeout, $parse, constants, $cookieStore, $http, toaster) {
    return {
        restrict: 'A',
        //template: '<span>{{label}}</span>',
        link: function (scope, el, attrs) {
					//scope.dddd ='xx';
					console.log(scope.diversities.data[attrs.count]);

			//scope.diversities.data[attrs.count].UploadUrl ='dsfsdf';
			scope.eventId = 'diversityDoc_'+attrs.count;
			scope.getCurrentIdFound = "";
			var eventIdTrack;
			var currentId;
			var dropbox1 = $(el).find('.drop-file')[0];

			function dragEnterLeave(evt) {
				$("#uploadFile").trigger('change');
				evt.stopPropagation()
				evt.preventDefault()
				scope.$apply(function(){
					scope.dropText = 'Drop files here...'
					scope.dropClass = ''
				})
			}
			dropbox1.addEventListener("dragenter", dragEnterLeave, false)
			dropbox1.addEventListener("dragleave", dragEnterLeave, false)
			dropbox1.addEventListener("dragover", function(evt) {
				$($scope.getCurrentIdFound).css("background-color","#eaf1f8");
				currentId = evt.currentTarget.id;
				scope.getCurrentIdFound = "#"+currentId;
				eventIdTrack = evt.currentTarget.id.split('_');
				$($scope.getCurrentIdFound).css("background-color","orange");
				scope.eventId = eventIdTrack[1];
				evt.stopPropagation()
				evt.preventDefault()
				var clazz = 'not-available'
				var ok = evt.dataTransfer && evt.dataTransfer.types && evt.dataTransfer.types.indexOf('Files') >= 0
				scope.$apply(function(){
					scope.dropText = ok ? 'Drop files here...' : 'Only files are allowed!'
					scope.dropClass = ok ? 'over' : 'not-available'
				})
			}, false)

			dropbox1.addEventListener("drop", function(evt) {
				evt.stopPropagation()
				evt.preventDefault()
				scope.$apply(function(){
					scope.dropText = 'Drop files here...'
					scope.dropClass = ''
				})
				var files = evt.dataTransfer.files
				if (files.length > 0) {
					scope.$apply(function(){
						scope.files = []
						for (var i = 0; i < files.length; i++) {
							scope.files.push(files[i])
							 uploadFileSend($scope.files[0]);
						}
					})
				}
			}, false);

			scope.setFiles = function(element) {
				var getElementId=element.id.split('_');
				//scope.eventId = getElementId[1];
				scope.$apply(function($scope) {
				scope.files = []
				for (var i = 0; i < element.files.length; i++) {
				  scope.files.push(element.files[i]);
				  uploadFileSend($scope.files[0])
				}
			  });
			};

			function uploadFileSend(file){
				scope.loader=true;
				$(scope.getCurrentIdFound).css("background-color","#eaf1f8");
				console.log("supplierApiUrl",constants.SUPPLIER_API_URL);
				console.log("file",file);
				scope.preloader=true;
				scope.fileName=file.name;
				var formData = new FormData();
				formData.append('file', file);
				formData.append('SUPPLIERID', localStorage.getItem("userId"));
				console.log("formData",formData)
				 var req = {
							method : 'POST',
							url :constants.FILE_UPLOAD+scope.eventId ,
							transformRequest: angular.identity,
							headers : {
								'Content-Type': undefined,
								'Authorization' : $cookieStore.get("sc_token")
							},
								data: formData,
								cache: false,
								contentType: false,
								processData: false
						};
						$http(req).then(function(data) {
							var divAttribute;
							var downloadUrl;
							var userId=localStorage.getItem("userId");
							scope.getCurrentIdFound = "";
							scope.eventId = "";
							scope.preloader=false;
							var pJson=data.data;
							var finalUrlData=pJson.key;
							var dataFile=finalUrlData.split('/');
							var docName=data.data.docType;
							var specificFileName=dataFile[2];
							//var downloadUrl=constants.SUPPLIER_API_URL+"supplier/document/pull?SUPPLIERID="+localStorage.getItem("userId")+"&filename="+dataFile[2];
							//$("#downloadUrlForFile").attr("href", downloadUrl)
							scope.loader=false;
							toaster.pop('success', "Document Upload", "Document had been uploaded successfully");

								scope.diversities.data[attrs.count].fileDownload=true;
								scope.fileNameDiversity=dataFile[2];
								scope.diversities.data[attrs.count].fileName = scope.fileNameDiversity;
								//scope.supplierinfo.fileNameDiversity=dataFile[2];
								//scope.supplierInfo.diversityFilePath=data.data.filePath;
								scope.diversities.data[attrs.count].uploadUrl = data.data.filePath;
								//downloadUrl=data.data.filePath;
								//divAttribute = document.getElementById('downloadUrlForFile_Diversity');
								//divAttribute.href = downloadUrl;

						}, function() {
							scope.diversities.data[attrs.count].fileDownload=false;
							scope.loader=false;
							toaster.pop('error', "Document Upload", "server not responding");
						});

			}

        }
    };
});

app.directive('ngEnter', function() {
        return function(scope, element, attrs) {
            element.bind("keydown keypress", function(event) {
                if(event.which === 13) {
                        scope.$apply(function(){
                                scope.$eval(attrs.ngEnter);
                        });

                        event.preventDefault();
                }
            });
        };
});

app.directive('ngFileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var model = $parse(attrs.ngFileModel);
            var isMultiple = attrs.multiple;
            var modelSetter = model.assign;
            element.bind('change', function () {
                var values = [];
                angular.forEach(element[0].files, function (item) {
                    var value = {
                       // File Name 
                        name: item.name,
                        //File Size 
                        size: item.size,
                        //File URL to view 
                        url: URL.createObjectURL(item),
                        // File Input Value 
                        _file: item
                    };
                    values.push(value);
                });
                scope.$apply(function () {
                    if (isMultiple) {
                        modelSetter(scope, values);
                    } else {
                        modelSetter(scope, values[0]);
                    }
                });
            });
        }
    };
}]);

app.directive("countryName", function(supplier, $filter) {
  return {
    template: "{{name}}",
    link: function(scope, element, attrs) {

		supplier.getCountryList().then(function(data) {
			//debugger;

			var codeArray = $filter('filter')(data, {'code':attrs.countryid});
			if(codeArray[0]){
			scope.name = codeArray[0].name;
			if(!attrs.countryid){
				scope.name = '';
			}
			}
		}, function() {
			scope.name = attrs.countryid;
		});
    }
  }
});

// app.directive('booststrapDropdown', function () {
//     return {
//         link: function (scope, element, attr) {
//          	element.parent().bind('keypress', function (e) {
// 	            children = element.children();
// 	            children.removeClass("active");
// 	            for (var i = count, len= children.length; i<len; i++) {
// 	                var letter = String.fromCharCode(e.which).toUpperCase();
// 	                var charat = children[i].textContent.replace(/\s+/, '').charAt(0);
// 	                if (charat === letter) {
// 	                    children[i].className += " active";
// 	                  	element[0].scrollTop = children[i].offsetTop;
// 	                  	count = i+1;
// 	                  	return;
// 	              	}
// 	              	else if(count < children.length){
// 	              		count = 0;
// 	              	}

// 		        }
// 	       	});
//   		}
//   	}
// });
var idleInterval = setInterval(timerIncrement, 1000);
var idleTime = 0;
var j=0;
var tempstr="";
app.directive('booststrapDropdown',
function () {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
        	element.parent().bind('keypress', function (e) {
	            children = element.children();
	            children.removeClass("active");
				idleTime = 0;

	            var letter = String.fromCharCode(e.which).toUpperCase();
	            if (tempstr != letter) {
	            	currentStr = currentStr + letter;
	            	j = 0;
	            }
	            tempstr=letter;
	            for (var i = j, len= children.length; i<len; i++) {
	                var letter = String.fromCharCode(e.which).toUpperCase();
	                var charat = children[i].textContent.replace(/\s+/, '').substring(0,currentStr.length).toUpperCase();
	                if (charat.indexOf(currentStr, 0) != -1) {
                        children[i].className += " active";
                        element[0].scrollTop = children[i].offsetTop;
                        j = i+1;
                        return;
                     }
                     j = i+1;
	            }
	        });
      	}
  	};
});
function timerIncrement() {
    idleTime = idleTime + 1;
    if (idleTime >= 2) { // 2 sec
       currentStr="";
    }
}


app.directive('uiAction', function(Auth, $timeout, $rootScope, toaster){
    return{
        restrict: 'A',
        priority: 100000,
        scope: false,
        compile:  function(element, attr, linker) {
	
			var accessDenied = true; 			
			//var accessDenied = false;	//FOR testing making false		
			if($rootScope.roleActions) {						
				if (Auth.isRoleExists($rootScope.roleActions.authorities , attr.access)){					
					accessDenied = false;
				}			
			}

			if(accessDenied){
				attr.ngClick = function() {
					toaster.pop('error', "Access Denied", "You don't have permission to do this action");
				};					
			}

		
			//attr.ngClick = null;	
			/*if(accessDenied){					
				element.children().remove();				  
				element.remove();    
			}*/							
            return function linkFn(scope, element, attrs) {
                /* Optional */
				/*element.bind('click',function(e){					
					return;
				});*/
            }
        }
    }
});

app.directive('spDragDropDiligence', function ($timeout, $parse, constants, $cookieStore, $http, toaster) {
    return {
        restrict: 'A',
        //template: '<span>{{label}}</span>',
        link: function (scope, el, attrs) {
					//scope.dddd ='xx';


			//scope.diversities.data[attrs.count].UploadUrl ='dsfsdf';
			scope.eventId = 'diligenceDoc_'+attrs.count;
			scope.getCurrentIdFound = "";
			var eventIdTrack;
			var currentId;
			var dropbox1 = $(el).find('.drop-file')[0];

			function dragEnterLeave(evt) {
				$("#uploadFile").trigger('change');
				evt.stopPropagation()
				evt.preventDefault()
				scope.$apply(function(){
					scope.dropText = 'Drop files here...'
					scope.dropClass = ''
				})
			}
			dropbox1.addEventListener("dragenter", dragEnterLeave, false)
			dropbox1.addEventListener("dragleave", dragEnterLeave, false)
			dropbox1.addEventListener("dragover", function(evt) {
				$($scope.getCurrentIdFound).css("background-color","#eaf1f8");
				currentId = evt.currentTarget.id;
				scope.getCurrentIdFound = "#"+currentId;
				eventIdTrack = evt.currentTarget.id.split('_');
				$($scope.getCurrentIdFound).css("background-color","orange");
				scope.eventId = eventIdTrack[1];
				evt.stopPropagation()
				evt.preventDefault()
				var clazz = 'not-available'
				var ok = evt.dataTransfer && evt.dataTransfer.types && evt.dataTransfer.types.indexOf('Files') >= 0
				scope.$apply(function(){
					scope.dropText = ok ? 'Drop files here...' : 'Only files are allowed!'
					scope.dropClass = ok ? 'over' : 'not-available'
				})
			}, false)

			dropbox1.addEventListener("drop", function(evt) {
				evt.stopPropagation()
				evt.preventDefault()
				scope.$apply(function(){
					scope.dropText = 'Drop files here...'
					scope.dropClass = ''
				})
				var files = evt.dataTransfer.files
				if (files.length > 0) {
					scope.$apply(function(){
						scope.files = []
						for (var i = 0; i < files.length; i++) {
							scope.files.push(files[i])
							 uploadFileSend($scope.files[0]);
						}
					})
				}
			}, false);

			scope.setFiles = function(element) {
				var getElementId=element.id.split('_');
				//scope.eventId = getElementId[1];
				scope.$apply(function($scope) {
				scope.files = []
				for (var i = 0; i < element.files.length; i++) {
				  scope.files.push(element.files[i]);
				  uploadFileSend($scope.files[0])
				}
			  });
			};

			function uploadFileSend(file){
				scope.loader=true;
				$(scope.getCurrentIdFound).css("background-color","#eaf1f8");
				console.log("supplierApiUrl",constants.SUPPLIER_API_URL);
				console.log("file",file);
				scope.preloader=true;
				scope.fileName=file.name;
				var formData = new FormData();
				formData.append('file', file);
				formData.append('SUPPLIERID', localStorage.getItem("userId"));
				console.log("formData",formData)
				 var req = {
							method : 'POST',
							url :constants.FILE_UPLOAD+scope.eventId ,
							transformRequest: angular.identity,
							headers : {
								'Content-Type': undefined,
								'Authorization' : $cookieStore.get("sc_token")
							},
								data: formData,
								cache: false,
								contentType: false,
								processData: false
						};
						$http(req).then(function(data) {
							var divAttribute;
							var downloadUrl;
							var userId=localStorage.getItem("userId");
							scope.getCurrentIdFound = "";
							scope.eventId = "";
							scope.preloader=false;
							var pJson=data.data;
							var finalUrlData=pJson.key;
							var dataFile=finalUrlData.split('/');
							var docName=data.data.docType;
							var specificFileName=dataFile[2];
							//var downloadUrl=constants.SUPPLIER_API_URL+"supplier/document/pull?SUPPLIERID="+localStorage.getItem("userId")+"&filename="+dataFile[2];
							//$("#downloadUrlForFile").attr("href", downloadUrl)
							scope.loader=false;
							toaster.pop('success', "Document Upload", "Document had been uploaded successfully");

								scope.fileDownload=true;
								scope.fileNameDiversity=dataFile[2];
								scope.fileName = scope.fileNameDiversity;
								scope.uploadUrl = data.data.filePath;
                        scope.fileId = data.data.fileId;

						}, function() {
							scope.fileDownload=false;
							scope.loader=false;
							toaster.pop('error', "Document Upload", "server not responding");
						});

			}
        }
    };
});
