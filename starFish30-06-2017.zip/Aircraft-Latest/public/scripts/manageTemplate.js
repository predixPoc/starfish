$(document).ready(function () {
	
	$("#uploadTemplateId").hide();

	$("#uploaddataBaseCrendial").hide();
	
	$("#metaDataTemplateId").hide();
	
	$("#sucessdbId").hide();
	
	
	$("input:radio[name=optradio]" ).click(function(){
		
    if($('input:radio[name=optradio]:checked').val() == "template"){
		$("#uploadTemplateId").show();
		$("#uploaddataBaseCrendial").hide();
		
		 $("#metaDataTemplateId").hide();
	$("#sucessdbId").hide();
      
    }else if($('input:radio[name=optradio]:checked').val() == "database"){
		
		$("#uploaddataBaseCrendial").show();
		$("#uploadTemplateId").hide();
	//	$("#metaDataTemplateId").show();
		//$("#sucessdbId").show();
		
		
		
	}
});


var dataSet = [
    ["IDMV_PRSNMSTRDATASYNC", "Non-EC", "GET_SPONSOR", "","NLR","Not Sensitive Data",""],
    ["IDMV_PRSNMSTRDATASYNC", "Non-EC", "PERSON_NUM_SSO", "","NLR","Not Sensitive Data",""],
    ["IDMV_PRSNMSTRDATASYNC", "Non-EC", "FIRST_NAME", "","NLR","Not Sensitive Data",""],
    ["IDMV_PRSNMSTRDATASYNC", "Non-EC", "MIDDLE_NAME", "","NLR","Not Sensitive Data",""],
    ["IDMV_PRSNMSTRDATASYNC", "Non-EC", "LAST_NAME", "","NLR","Not Sensitive Data",""],
    ["IDMV_PRSNMSTRDATASYNC", "Non-EC", "PERSON_TYPE", "","NLR","Not Sensitive Data",""]
	];

    $('#example').DataTable({
        data: dataSet,
        columns: [
            { title: "TABLE_NAME" },
            { title: "TABLE_TAG" },
            { title: "COLUMN_NAME" },
            { title: "COLUMN_DATA_DESC" },
			{ title: "COLUMN_EXPORT_TAG" },
			{ title: "COLUMN_CONTROL_TAG" },
			{ title: "OTHER_REMARKS" },
			
        ]
    });
$('#example_filter').find('label').css({"color": "white"});
$('#example_length').find('label').css({"color": "white"});

$('#example_info').css({"color": "white"});


  $("#buttonId").click(function(){
	  $("#metaDataTemplateId").show();
	$("#sucessdbId").show();
	
  });
	
	 
 });