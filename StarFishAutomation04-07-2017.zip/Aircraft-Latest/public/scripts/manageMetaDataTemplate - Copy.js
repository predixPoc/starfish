var editor; 
	
var dataSet;
$(document).ready(function () {
	
dataSet={
	"data": [
    {
      "id": "1",
      "dataOwner": "Wooley, David",
      "appOwner": "Schwab, Eric",
      "appName": "IDM",
      "host": "atxoltp5.tsg.ge.com",
      "databaseInstance": "adxodsp5",
      "schema": "idmv",
      "port": "1527",
      "dbType": "Oracle",
      "ecNonEc": "non-EC",
	  "1TimeExtWindow": "after 9PM",
      "updateExtWindow": "after 9PM"
    },
	{
      "id": "2",
      "dataOwner": "Wooley, David",
      "appOwner": "Schwab, Eric",
      "appName": "IDM",
      "host": "atxoltp5.tsg.ge.com",
      "databaseInstance": "adxodsp5",
      "schema": "temp1",
      "port": "1527",
      "dbType": "Oracle",
      "ecNonEc": "non-EC",
	  "1TimeExtWindow": "after 9PM",
      "updateExtWindow": "after 9PM"
    },
	{
      "id": "3",
      "dataOwner": "Wooley, David",
      "appOwner": "Schwab, Eric",
      "appName": "IDM",
      "host": "atxoltp5.tsg.ge.com",
      "databaseInstance": "adxodsp5",
      "schema": "temp1",
      "port": "1527",
      "dbType": "Oracle",
      "ecNonEc": "non-EC",
	  "1TimeExtWindow": "after 9PM",
      "updateExtWindow": "after 9PM"
    },
	{
      "id": "4",
      "dataOwner": "Wooley, David",
      "appOwner": "Schwab, Eric",
      "appName": "IDM",
      "host": "atxoltp5.tsg.ge.com",
      "databaseInstance": "adxodsp5",
      "schema": "temp1",
      "port": "1527",
      "dbType": "Oracle",
      "ecNonEc": "non-EC",
	  "1TimeExtWindow": "after 9PM",
      "updateExtWindow": "after 9PM"
    }
	
    
  ],
  "options": [],
  "files": []
}
	
	
	
	editor = new $.fn.dataTable.Editor( {
        data: dataSet.data,
        "table": "#example",
        "idSrc": "id",
        "fields": [ {
                "label": "Data Owner:",
                "name": "dataOwner"
            }, {
                "label": "App Owner:",
                "name": "appOwner"
            }, {
                "label": "App Name:",
                "name": "appName"
            }, {
                "label": "Host:",
                "name": "host"
            }, {
                "label": "Database Instance:",
                "name": "databaseInstance"
            }, {
                "label": "Schema:",
                "name": "schema"
             
            },
			{
                "label": "Port:",
                "name": "port"
             
            },	
			{
                "label": "DB Type:",
                "name": "dbType"
             
            }
        ]
    } );
	
	
	
	
	/*var dataSet = [
    [ 1,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM"
	,"after 9PM"],
    [ 2,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM"
	,"after 9PM"],
   [ 3,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM","after 9PM"],
     [ 4,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM"
	,"after 9PM"],
    [ 5,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM"
	,"after 9PM"],
   [ 6,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM","after 9PM"],
     [ 7,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM"
	,"after 9PM"],
    [ 8,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM"
	,"after 9PM"],
   [ 9,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM","after 9PM"],
     [ 10,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM"
	,"after 9PM"],
    [ 11,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM"
	,"after 9PM"],
   [ 12,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM","after 9PM"]
   
   
 
	];*/
	
	
	
	

  /*  $('#example').DataTable({
        data: dataSet,
		"scrollX": true,
        columns: [
			{ title: "SLNo." },
            { title: "Data Owner" },
            { title: "App Owner" },
            { title: "App Name" },
            { title: "Host" },
            { title: "Database Instance" },
			{ title: "Schema" },
			{ title: "port" },
			{ title: "Db Type" },
			{ title: "EC or Non-Ec" },
			{ title: "1-Time Extraction Window" },
			{ title: "Update Extraction Window" },
			{
				
                data: null,
				//defaultContent:'<button class="btn1 btn-primary1 btn-xs1" data-title="Edit" data-toggle="modal" data-target="#edit"><span class="glyphicon glyphicon-pencil"></span></button><button class="btn1 btn-danger1 btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete"><span class="glyphicon glyphicon-trash"></span></button>'
				defaultContent: '<a href="" class="editor_edit">Edit</a> / <a href="" class="editor_remove">Delete</a>'
            }
        ]
    });*/
	$('#example').DataTable({
	    data: dataSet.data,
        columns: [
            { data: "dataOwner" },
            { data: "appOwner" },
            { data: "appName" },
            { data: "host" },
			 { data: "databaseInstance" },
			  { data: "schema" },
			   { data: "port" },
			   { data: "dbType" },
			   { data: "ecNonEc" },
			    { data: "1TimeExtWindow" },
				 { data: "updateExtWindow" },
            {
                data: null,
                className: "center",
                defaultContent: '<a href="" class="editor_edit">Edit</a> / <a href="" class="editor_remove">Delete</a>'
            }
        ]
    });

	
	$('#example').on('click', 'a.editor_edit', function (e) {
        e.preventDefault();
 
        editor.edit( $(this).closest('tr'), {
            title: 'Edit record',
            buttons: 'Update'
        } );
    } );
	
	// Delete a record
    $('#example').on('click', 'a.editor_remove', function (e) {
        e.preventDefault();
 
        editor.remove( $(this).closest('tr'), {
            title: 'Delete record',
            message: 'Are you sure you wish to remove this record?',
            buttons: 'Delete'
        } );
    } );
 
	 
 });