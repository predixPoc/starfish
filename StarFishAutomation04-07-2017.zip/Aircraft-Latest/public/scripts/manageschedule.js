var editor; 
	
var dataSet;
$(document).ready(function () {
	
dataSet={
	"data": [
    {
      "id": "1",
      "environment": "Non EC QA",
      "functionName": "Function1",
      "scheduleType": "Daily",
      "scheduleTime": "12:10:30 PM",
      "lastRunDate": "2017/06/14"
    },
	{
      "id": "2",
      "environment": "Non EC Discovery",
      "functionName": "Function2",
      "scheduleType": "Daily",
      "scheduleTime": "12:10:30 PM",
      "lastRunDate": "2017/06/14"
    },
	{
      "id": "3",
      "environment": "Non EC Discovery",
      "functionName": "Function3",
      "scheduleType": "Weekly",
      "scheduleTime": "12:10:30 PM",
      "lastRunDate": "2017/06/14"
    },
	{
      "id": "4",
      "environment": "Non EC Discovery",
      "functionName": "Function4",
      "scheduleType": "Daily",
      "scheduleTime": "12:10:30 PM",
      "lastRunDate": "2017/06/14"
    },
	{
      "id": "3",
      "environment": "Non EC Discovery",
      "functionName": "Function2",
      "scheduleType": "Weekly",
      "scheduleTime": "12:10:30 PM",
      "lastRunDate": "2017/06/14"
    },
	{
      "id": "3",
      "environment": "Non EC Discovery",
      "functionName": "Function3",
      "scheduleType": "Weekly",
      "scheduleTime": "12:10:30 PM",
      "lastRunDate": "2017/06/14"
    },
	{
      "id": "4",
      "environment": "Non EC Discovery",
      "functionName": "Function1",
      "scheduleType": "Weekly",
      "scheduleTime": "12:10:30 PM",
      "lastRunDate": "2017/06/14"
    },
	
    
  ],
  "options": [],
  "files": []
}
	
	
	
	editor = new $.fn.dataTable.Editor( {
        data: dataSet.data,
        "table": "#example",
        "idSrc": "id",
        "fields": [ {
                "label": "Environment:",
                "name": "environment"
            }, {
                "label": "Function Name:",
                "name": "functionName"
            }, {
                "label": "scheduleType:",
                "name": "scheduleType"
            }, {
                "label": "scheduleTime:",
                "name": "scheduleTime"
            }, {
                "label": "Last Run Date:",
                "name": "lastRunDate"
            }
        ]
    } );
	
	
	
	
	/*var dataSet = [
    [ 1,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM"
	,"after 9PM"],
    [ 2,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM"
	,"after 9PM"],
   [ 3,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM","after 9PM"],
     [ 4,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM"
	,"after 9PM"],
    [ 5,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM"
	,"after 9PM"],
   [ 6,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM","after 9PM"],
     [ 7,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM"
	,"after 9PM"],
    [ 8,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM"
	,"after 9PM"],
   [ 9,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM","after 9PM"],
     [ 10,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM"
	,"after 9PM"],
    [ 11,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM"
	,"after 9PM"],
   [ 12,"Wooley, David", "Schwab, Eric", "IDM", "atxoltp5.tsg.ge.com","adxodsp5","idmv","1527","Oracle","non-EC","after 9PM","after 9PM"]
   
   
 
	];*/
	
	
	
	

  /*  $('#example').DataTable({
        data: dataSet,
		"scrollX": true,
        columns: [
			{ title: "SLNo." },
            { title: "Data Owner" },
            { title: "App Owner" },
            { title: "App Name" },
            { title: "Host" },
            { title: "Database Instance" },
			{ title: "Schema" },
			{ title: "port" },
			{ title: "Db Type" },
			{ title: "EC or Non-Ec" },
			{ title: "1-Time Extraction Window" },
			{ title: "Update Extraction Window" },
			{
				
                data: null,
				//defaultContent:'<button class="btn1 btn-primary1 btn-xs1" data-title="Edit" data-toggle="modal" data-target="#edit"><span class="glyphicon glyphicon-pencil"></span></button><button class="btn1 btn-danger1 btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete"><span class="glyphicon glyphicon-trash"></span></button>'
				defaultContent: '<a href="" class="editor_edit">Edit</a> / <a href="" class="editor_remove">Delete</a>'
            }
        ]
    });*/
	$('#example').DataTable({
	    data: dataSet.data,
        columns: [
            { data: "environment" },
            { data: "functionName" },
            { data: "scheduleType" },
            { data: "scheduleTime" },
			{ data: "lastRunDate" },
		
            {
                data: null,
                className: "center",
                defaultContent: '<a href="" class="editor_edit">Edit</a> / <a href="" class="editor_remove">Delete</a>'
            }
        ]
    });

	
	$('#example').on('click', 'a.editor_edit', function (e) {
        e.preventDefault();
 
        editor.edit( $(this).closest('tr'), {
            title: 'Edit record',
            buttons: 'Update'
        } );
    } );
	
	// Delete a record
    $('#example').on('click', 'a.editor_remove', function (e) {
        e.preventDefault();
 
        editor.remove( $(this).closest('tr'), {
            title: 'Delete record',
            message: 'Are you sure you wish to remove this record?',
            buttons: 'Delete'
        } );
    } );
 
	 
 });