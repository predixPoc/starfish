$(document).ready(function () {
$("#managemetaDataTemplatethirdTable").hide();
$("#managemetaDataTemplatesecondTable").hide();
	
	$('#example').DataTable( {
        columnDefs: [ {
            orderable: false,
            className: 'select-checkbox',
            targets:   0
        } ],
        select: {
            style:    'os',
            selector: 'td:first-child'
        },
        order: [[ 1, 'asc' ]]
    } );
	
	
	$("#editor_edit1").click(function(){
	$("#managemetaDataTemplatethirdTable").show();
	$("#managemetaDataTemplatesecondTable").show();
	
	});  
$("#editor_edit2").click(function(){
	$("#managemetaDataTemplatethirdTable").show();
	$("#managemetaDataTemplatesecondTable").show();
	
	}); 
$("#editor_edit3").click(function(){
	$("#managemetaDataTemplatethirdTable").show();
	$("#managemetaDataTemplatesecondTable").show();
	
	}); 
$("#editor_edit4").click(function(){
	$("#managemetaDataTemplatethirdTable").show();
	$("#managemetaDataTemplatesecondTable").show();
	
	}); 	
	
	
});