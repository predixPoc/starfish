$(document).ready(function () {
	
	
	$("#schduleTableId").hide();
	
	$("#submitButtonId").hide();
	
	$("#schduleTimeId").hide();
	
	 $(".btn").css("padding", '6px,12px');
	$("[data-toggle=tooltip]").tooltip();

	  var availableTags = [
      "Function1",
	  "Function2",
      "Function3"
	
     
    ];
    $( "#functionId" ).autocomplete({
      source: availableTags
    });
	
	
	$( "#functionId" ).on( "autocompleteselect", function( event, ui ) {
		
		
		var dataitem=ui.item.label ;
		
		if(dataitem=='Function1'){
			$('#myModal').modal('show');
		}
		
		if(dataitem=='Function2'){
			$('#myModal1').modal('show');
		}
		

	  
	
    //event.preventDefault();
    });
	
	
	
	$("#aftermodalidClick").click(function () {
	  $("#schduleTableId").show();
	$("#submitButtonId").show();
	$("#schduleTimeId").show();
	});
	$("#aftermodalidClick1").click(function () {
	  $("#schduleTableId").show();
	$("#submitButtonId").show();
	$("#schduleTimeId").show();
	});
	
	
	
	$("#environmentId").change(function () {
		
		$("#schemaId").val('geagp_schema1');
	});
	
	
	
	var dataSet = [
    [ "Non EC QA", "Function1", "Daily", "12:10:30 PM", "2017/04/25"],
    [ "Non EC Discovery", "Function1", "Daily", "12:10:30 PM", "2017/07/25"],
    [ "Non EC Discovery", "Function1", "Daily", "12:10:30 PM", "2017/01/12"],
    [ "Non EC Discovery", "Function1", "Daily", "12:10:30 PM", "2017/03/29"],
    [ "Non EC Enterprise", "Function2", "Daily", "12:10:30 PM", "2017/05/28"],
    [ "Non EC Enterprise", "Function2", "Daily", "12:10:30 PM", "2017/05/02"],
    [ "EC QA","Function3", "Daily", "12:10:30 PM","2017/06/02"],
    [ "EC Prod", "Function3", "Daily", "12:10:30 PM", "2017/06/14"]
	];

    $('#example').DataTable({
        data: dataSet,
        columns: [
            { title: "Environment" },
            { title: "FunctionName" },
            { title: "ScheduleType" },
            { title: "ScheduleTime" },
            { title: "Last Run Date" },
			{
				
                data: null,
                //defaultContent: '<a href="" class="editor_edit">Edit</a> / <a href="" class="editor_remove">Delete</a>'
				
				defaultContent:'<button class="btn1 btn-primary1 btn-xs1" data-title="Edit" data-toggle="modal" data-target="#edit"><span class="glyphicon glyphicon-pencil"></span></button> <button class="btn1 btn-danger1 btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete"><span class="glyphicon glyphicon-trash"></span></button>'
            }
        ]
    });

	
	
	 
 });