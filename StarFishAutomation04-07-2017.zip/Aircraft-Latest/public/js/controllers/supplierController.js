app.controller('supplierController', function($scope, $filter, $http, $rootScope,$state,supplier,$timeout,toaster,$cookies,$cookieStore, WorkFlow,constants,Auth) {		
	$scope.loader=false;
	$rootScope.supplierInfoDone = false; 
	$rootScope.poSettingsDone = false;
	$rootScope.complianceDone = false;  
	$rootScope.businessInfoDone = false;
	$rootScope.invitationDone = false;

	Auth.getRoles().then(function(roles){ 
    	if(!WorkFlow.getRequestId()){

    		toaster.pop('error', "No Open Task found !", "Request Id is retrieving as null");
			
			if (Auth.isSupplierRole(roles.roles)){
	       		$state.go('supplierHome');
	    	}else{
	        	$state.go('homePage');
	    	}
	    	return;
	    }

	    if (Auth.isSupplierRole(roles.roles)){
	       	$state.go('supplierHome');
	    }

	}, function(data){
    	$scope.loader=false;
    });

    
	supplier.getCountryList().then(function(data) {
		$scope.chooseCountries = data;
		//$scope.supplierInfo.country = $scope.chooseCountries[0];
	}, function() {
		toaster.pop('error', "Country list", "server not responding");
	});
	$scope.supplierInfo = {};
	$scope.onCountryChangeCode=function(code){
		$scope.loader=true;
		supplier.getCountryById(code).then(function(data){
			$scope.isoA3 = data.isoA3;
			supplier.getPhoneCodes().then(function(data){
				$scope.phoneCodes = data;
				angular.forEach($scope.phoneCodes, function(value, key){
					if(value.isoA3 === $scope.isoA3){
						$scope.supplierInfo.phoneCode=value.phoneCode;
						$scope.supplierInfo.phoneShortCode=value.code;
						$scope.loader=false;
					}
				})
			}, function() {
				$scope.loader=false;
				toaster.pop('error', "Phone list", "server not responding");

			});
		}, function() {
			$scope.loader=false;
			toaster.pop('error', "Country list", "server not responding");
		});
	}
//	$scope.PhoneCodeChange=function(name){
//		console.log(name)
//		   angular.forEach($scope.phoneCodes, function(value, key){
//			   if(value.name==name){
//				   $scope.supplierInfo.phoneCode=value.name +" + "+value.phoneCode;
//			   }
//              
//           });
//	}

	// $scope.isDisabled = false;
	supplier.getPhoneCodes().then(function(data){
		$scope.phoneCodes = data;
	}, function() {
		toaster.pop('error', "Phone list", "server not responding");
	});
	
	//Find duplicate name
	// var timer;
	// $scope.duplicateNameChange = function() {
	// 	$timeout.cancel(timer);
	// 	timer = $timeout(function(){				
	// 			supplier.getDuplicateName($scope.supplierInfo.name).then(function(data){					
	// 				$scope.duplicatename = data.data;
	// 				$scope.hideDropOver = true;
	// 			});				
	// 	}, 1000);		
	// };
	// $scope.filteredData=[];
	
	// $scope.hideDropBox = function(){
	// 	$scope.hideDropOver = false;
	// };

	
	$scope.emailRuleCheck=function(d){
		$scope.dCheck=false;
		supplier.getdRuleCheck(d).then(function(data) {
			if(data.data=="true"){
				$scope.dCheck=true;
			}
			else{
				$scope.dCheck=false;
				// toaster.pop('error', "d", "d validation is incorrect");
				// return;
			}
		}, function() {
			
		});
		
	}
	$scope.save = function(supplierInfo, next, supplierForm) {

		$scope.submitted = true;
		var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      
		//if(supplierForm.$invalid || !supplierInfo.country || supplierInfo.phoneCode==null) {
		if(supplierForm.$invalid || !supplierInfo.country ||!supplierInfo.phoneShortCode ) {
			toaster.pop('error', "", "Please fill all mandatory fields");	
			return;
		}
		else if(!re.test(supplierInfo.contactEmail)){
			toaster.pop('error', "Email", "Email validation is incorrect");	
			return;
		}
		else{
			$scope.loader=true;
			
			$cookieStore.put("email",supplierInfo.contactEmail);
			$cookieStore.put("supplierName", supplierInfo.name);
			$cookieStore.put("supplierFirstName",supplierInfo.contactFirstName);
			$cookieStore.put("supplierLastName",supplierInfo.contactLastName);
			supplierInfo.contactBusinessPhone='+'+supplierInfo.phoneCode+supplierInfo.phone;
			supplierInfo.userId=supplierInfo.contactEmail;
			
			/*WorkFlow.setVariables(WorkFlow.prepareVariables(supplierInfo, 'supplierInfo'), WorkFlow.getInstance()).then(function(data){
				toaster.pop('success', "Saved successfully");	
				
			},function(data){}); */
			/*
			var obj = { 
			  'supplier': {
				'countryId': supplierInfo.country,
				'legalName': supplierInfo.name,
				'registrationId': supplierInfo.taxId				
			  },			  	
				'onboardingContact': {
					'firstName': supplierInfo.contactFirstName,
					'lastName': supplierInfo.contactLastName,
					'email': supplierInfo.contactEmail,
					'businessPhoneCountryId': supplierInfo.phoneCode,
					'businessPhoneNumber': supplierInfo.phone,
					'uaaId': 'GE_SSO',
					'userId': localStorage.getItem("userId"),
					'contactType': 'ACCOUNTS_RECEIVABLE',
					'preferredContact': 'BUSINESS_PHONE'
				},
			}*/			
			
			WfModel.supplier = (WfModel.supplier==null)?{}:WfModel.supplier;			
			WfModel.supplier.countryId = supplierInfo.country;
			WfModel.supplier.legalName = supplierInfo.name;
			//WfModel.supplier.taxId = supplierInfo.taxId; 
			WfModel.supplier.legalTax = (WfModel.supplier.legalTax==null)?{}:WfModel.supplier.legalTax;
			WfModel.supplier.legalTax.taxRegistrationNumber  = supplierInfo.taxId;
			WfModel.supplier.isGovernmentEntity = supplierInfo.isGovernmentEntity;
			WfModel.onboardingContact = (WfModel.onboardingContact==null)?{}:WfModel.onboardingContact;
			WfModel.onboardingContact.firstName = supplierInfo.contactFirstName;
			WfModel.onboardingContact.lastName = supplierInfo.contactLastName;
			WfModel.onboardingContact.email = supplierInfo.contactEmail;
			WfModel.onboardingContact.businessPhoneCountryId = supplierInfo.phoneShortCode;
			WfModel.onboardingContact.businessPhoneNumber = supplierInfo.phone;
			WfModel.onboardingContact.uaaId = 'GE_SSO';
			WfModel.onboardingContact.userId = supplierInfo.contactEmail; 
			WfModel.onboardingContact.contactType = 'ACCOUNTS_RECEIVABLE';
			WfModel.onboardingContact.preferredContact = 'BUSINESS_PHONE';
			
			WfModel.dueDiligence = (WfModel.dueDiligence==null)?{}:WfModel.dueDiligence;
			WfModel.dueDiligence.ndaAlreadySigned = supplierInfo.ndaAlreadySigned;
			WfModel.supplier.alternateId = [
				{ "type":"DBA",
				"value":supplierInfo.alternateId}
			];
			
			
			$rootScope.supplierInfoDone = true; 
			WorkFlow.setVariablesV2(WfModel).then(function(data){
				toaster.pop('success', "Saved successfully");
				$scope.loader=false;
				if(next){
					$scope.loader=false;
					$state.go('businessInfo');
				}
				
			},function(data){
				$scope.loader=false;
				toaster.pop('error','Workflow API', "Server not responding");
			});
			
		}
	}		
	
	$scope.cancel = function() {	
		WorkFlow.cancelWorkflowV2(WorkFlow.getTask()).then(function(data) {
			$state.go('homePage');			
			toaster.pop('success', "WorkFlow cancelled successfully");
			$rootScope.businessTableList = [];
			$scope.loader=false;

		}, function(data) {
			toaster.pop('success', "WorkFlow cannot be cancelled", "Server not responding");
		});
	}
	
	
	
	
	//$scope.supplierInfo.phoneCode =1;
	//$scope.supplierInfo.phoneShortCode ='US';
	$scope.supplierInfo.phone ='';
	/*WorkFlow.getHistory(WorkFlow.getInstance()).then(function(workflowData) {
		if(workflowData.data.length>0){		
			console.log(workflowData.data[0].variables);
			$scope.supplierInfo = WorkFlow.makeModel(workflowData.data[0].variables);
			console.log($scope.supplierInfo);		
		}

	}, function(data) {
	});*/
	
	
	var WfModel = {};
	if(WorkFlow.getRequestId()){			
		WorkFlow.getVariablesV2().then(function(workflowData) {	
			WfModel = workflowData.data;
			if(workflowData.data.supplier){	
				$scope.supplierInfo.country = (workflowData.data.supplier)?parseInt(workflowData.data.supplier.countryId):null; 
				$scope.supplierInfo.name = (workflowData.data.supplier)?workflowData.data.supplier.legalName:null; 
				$scope.supplierInfo.taxId = (workflowData.data.supplier.legalTax)?workflowData.data.supplier.legalTax.taxRegistrationNumber:null; 
				$scope.supplierInfo.isGovernmentEntity = (workflowData.data.supplier)?workflowData.data.supplier.isGovernmentEntity:null;
				supplier.getPhoneCodes().then(function(data){
					$scope.loader=true;
					$scope.phoneCodes = data;
					angular.forEach($scope.phoneCodes, function(value, key){
						if(workflowData.data.onboardingContact.businessPhoneCountryId){
						if(workflowData.data.onboardingContact.businessPhoneCountryId==value.code){
							$scope.supplierInfo.phoneCode=value.phoneCode;
							$scope.supplierInfo.phoneShortCode=value.code;
							$scope.loader=false;
						}
						}
					});
				}, function() {
					$scope.loader=false;
					toaster.pop('error', "Phone list", "server not responding");
				});

				$scope.supplierInfo.phoneShortCode = workflowData.data.onboardingContact.businessPhoneCountryId; 
				$scope.supplierInfo.phone = workflowData.data.onboardingContact.businessPhoneNumber; 
				$scope.supplierInfo.contactFirstName = workflowData.data.onboardingContact.firstName; 
				$scope.supplierInfo.contactLastName = workflowData.data.onboardingContact.lastName; 
				$scope.supplierInfo.contactEmail = workflowData.data.onboardingContact.email; 
				$scope.supplierInfo.alternateId = (workflowData.data.supplier.alternateId[0])?workflowData.data.supplier.alternateId[0].value:null; 				
				$scope.supplierInfo.ndaAlreadySigned = workflowData.data.dueDiligence.ndaAlreadySigned;				
				$rootScope.supplierInfoDone = true;
				$scope.loader=false;
			}
		}, function(data) {
			$scope.loader=false;
			$rootScope.supplierInfoDone = false;
		});
	}	
});
